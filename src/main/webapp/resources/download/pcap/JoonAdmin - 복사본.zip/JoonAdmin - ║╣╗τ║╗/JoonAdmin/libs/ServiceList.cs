﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parse;

namespace JoonLib
{
    class ServiceServer : RestServer
    {

        public RestServer adminServer;
        public string serverQueryClass;

        public ServiceServer(String name, String appId, String appKey, String restKey, String masterKey,
                             RestServer adminServer = null,
                             string serverQueryClass = null)
            : base(name, appId, appKey, restKey, masterKey)
        {
            this.adminServer = adminServer;
            this.serverQueryClass = serverQueryClass;
        }
    };


    class ServiceList
    {
        public static ServiceServer current;

        public static ServiceServer[] list = null;
        public static RestServer serverListQueryServer = null;

        static Dictionary<string, RestServer> serverList = new Dictionary<string, RestServer>();


        public static async Task<List<RestServer>> getServerWithType(string type)
        {
            List<RestServer> serverList = new List<RestServer>();
            RestQuery query = new RestQuery();
            query.equalTo("type", type);

            if (serverListQueryServer != null)
            {
                List<ParseObject> results = await RestAPI.get(current.serverQueryClass, query, true, true, serverListQueryServer);
                foreach (ParseObject parseServer in results)
                {
                    RestServer restServer = new RestServer(parseServer);
                    serverList.Add(restServer);
                }
            }
            return serverList;
        }


        public static async Task<RestServer> getServerWithId(string serverId)
        {
            if (serverList.ContainsKey(serverId))
                return serverList[serverId];

            RestQuery query = new RestQuery();
            query.equalTo("objectId", serverId);

            if (serverListQueryServer != null)
            {
                List<ParseObject> results = await RestAPI.get(current.serverQueryClass, query, true, true, serverListQueryServer);
                RestServer server = new RestServer(results[0]);
                serverList[serverId] = server;
                return server;
            }
            else
            {
                return null;
            }
        }

        public static RestServer getServerWithName(string name)
        {
            foreach (RestServer server in list)
            {
                if (server.name == name)
                    return server;
            }
            return null;
        }
    }
}
