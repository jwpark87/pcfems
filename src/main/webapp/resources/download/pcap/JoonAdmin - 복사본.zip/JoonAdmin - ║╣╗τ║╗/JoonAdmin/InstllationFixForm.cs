﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using JoonLib;
using Parse;
namespace JoonAdmin
{
    public partial class InstallationFixForm : Form
    {
        protected DateTime _lastDate;
        protected string _lastObjectId;
        protected Dictionary<string, object> _pushData;
        protected RestServer _server;
        protected bool _isStop;

        public InstallationFixForm()
        {
            InitializeComponent();
            listDeviceType.Text = "All";
            listTextType.Text = "Text";
            _server = ServiceList.current;
            // _server = new RestServer("dev", "T1XctG6y8gEPTNFhHlDDpuN3K7f5frVNRy5ML40s", "d4Kr6VeBcwPO1k9lKF0vPXNHdJ3rrWPFCxtxMx97", "ihOK87krWpUDqMFgZ6OFHqHk9hwwu0QkwCDLGn9f", "XHy6fzNmF0z9wUHwpmCGhIkvQiuC3WtMycv2F2p1");
            readLastDate();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _isStop = true;
        }

        async private void btnStart_Click(object sender, EventArgs e)
        {
            _isStop = false;
            btnStart.Enabled = false;
            if (listTextType.Text == "Text")
            {
                _pushData = new Dictionary<string, object>();
                _pushData.Add("alert", textPushData.Text);
            }
            else
            {
                Dictionary<object, object> json = JsonDeserializer.parse(textPushData.Text);
                _pushData = new Dictionary<string, object>();
                foreach(KeyValuePair<object, object> keyValue in json)
                {
                    _pushData.Add(keyValue.Key.ToString(), keyValue.Value);
                }
            }
            while (!_isStop)
            {
                try {
                    writeLog("user query - " + _lastDate);
                    writeLog(DateTime.Now.ToLongTimeString());
                    RestQuery query = nextUserQuery();
                    List<ParseObject> userList = await RestAPI.get(query, true, _server);
                    writeLog("user list - " + userList.Count);
                    if (userList.Count > 0)
                    {
                        writeLastDate(userList.Last());
                    }
                    else
                    {
                        break;
                    }

                    foreach (ParseObject user in userList)
                    {
                        string phoneNumber = user.GetString("phoneNumber");
                        writeLog("search " + phoneNumber);
                        if (phoneNumber.Length <= 4)
                            continue;
                        string channelNumber = phoneNumber.Substring(phoneNumber.Length - 4, 4);
                        List<ParseObject> installations = await RestAPI.get(userInstallationQuery(user), true, _server);
                        if (installations.Count > 0 && !installations[0].ContainsKey("channelNumber"))
                        {
                            writeLog("update " + channelNumber);
                            installations[0].Add("channelNumber", int.Parse(channelNumber));
                            await RestAPI.update(installations[0], new Dictionary<string, object> { { "channelNumber", int.Parse(channelNumber) } }.ToList(), _server);
                        }
                        /*
                        for (int i = 1; i < installations.Count; ++i)
                        {
                            await RestAPI.deleteObject(installations[i], _server);
                        }
                        */
                        if (_isStop)
                            break;
                    }
                }
                catch (Exception exp)
                {
                    writeLog(exp.Message);
                }
                writeLog(DateTime.Now.ToLongTimeString());
            }
            _isStop = true;
            btnStart.Enabled = true;
        }


        void readLastDate()
        {
            string textLastDate = "";
            try {
                textLastDate = File.ReadAllText("push_lastdate.txt");
            } catch (Exception exp)
            {

            }
            string[] components = textLastDate.Split(',');
            if (components.Length == 2)
            {
                _lastDate = new DateTime(long.Parse(components[0]));
                _lastObjectId = components[1];
            }
            else
            {
                _lastDate = new DateTime(2014, 1, 1);
                _lastObjectId = null;
            }
        }


        void writeLastDate(ParseObject lastObject)
        {
            _lastDate = lastObject.Get<DateTime>("createdAt");
            _lastObjectId = lastObject.ObjectId;
            File.WriteAllText("push_lastdate.txt", "" + _lastDate.Ticks + "," + _lastObjectId);
        }

        RestQuery nextUserQuery() {
            RestQuery query = new RestQuery("_User");
            query.equalTo("type", "manager");
            if (textPhoneNumbers.Text.Length > 0)
                query.containedIn("phoneNumber", textPhoneNumbers.Text.Split(','));
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            if (_lastObjectId != null)
                query.notEqualTo("objectId", _lastObjectId);
            query.limit(100);
            return query;
        }

        RestQuery userInstallationQuery(ParseObject user)
        {
            List<Dictionary<string, object>> orQueries = new List<Dictionary<string, object>>();
            RestQuery query = new RestQuery("_Installation");
            query.equalTo("user", user);
            query.orderTo("-createdAt");
            query.limit(100);
            if (listDeviceType.Text != "All")
                query.equalTo("deviceType", listDeviceType.Text);
            return query;
        }


        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _lastDate = new DateTime(2014, 1, 1);
            _lastObjectId = null;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
