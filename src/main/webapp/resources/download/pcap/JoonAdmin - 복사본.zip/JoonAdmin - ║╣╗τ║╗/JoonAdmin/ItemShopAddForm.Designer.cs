﻿namespace JoonAdmin
{
    partial class ItemShopAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listTypes = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnThumbnail = new System.Windows.Forms.Button();
            this.lblThumbnailStatus = new System.Windows.Forms.Label();
            this.lblFileStatus = new System.Windows.Forms.Label();
            this.btnFile = new System.Windows.Forms.Button();
            this.textTitle = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // listTypes
            // 
            this.listTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listTypes.FormattingEnabled = true;
            this.listTypes.Items.AddRange(new object[] {
            "배경화면",
            "사운드"});
            this.listTypes.Location = new System.Drawing.Point(74, 22);
            this.listTypes.Name = "listTypes";
            this.listTypes.Size = new System.Drawing.Size(362, 20);
            this.listTypes.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "타입:";
            // 
            // btnThumbnail
            // 
            this.btnThumbnail.Location = new System.Drawing.Point(74, 74);
            this.btnThumbnail.Name = "btnThumbnail";
            this.btnThumbnail.Size = new System.Drawing.Size(110, 33);
            this.btnThumbnail.TabIndex = 2;
            this.btnThumbnail.Text = "Thumbnail...";
            this.btnThumbnail.UseVisualStyleBackColor = true;
            this.btnThumbnail.Click += new System.EventHandler(this.btnThumbnail_Click);
            // 
            // lblThumbnailStatus
            // 
            this.lblThumbnailStatus.AutoSize = true;
            this.lblThumbnailStatus.Location = new System.Drawing.Point(190, 84);
            this.lblThumbnailStatus.Name = "lblThumbnailStatus";
            this.lblThumbnailStatus.Size = new System.Drawing.Size(0, 12);
            this.lblThumbnailStatus.TabIndex = 3;
            // 
            // lblFileStatus
            // 
            this.lblFileStatus.AutoSize = true;
            this.lblFileStatus.Location = new System.Drawing.Point(190, 123);
            this.lblFileStatus.Name = "lblFileStatus";
            this.lblFileStatus.Size = new System.Drawing.Size(0, 12);
            this.lblFileStatus.TabIndex = 5;
            // 
            // btnFile
            // 
            this.btnFile.Location = new System.Drawing.Point(74, 113);
            this.btnFile.Name = "btnFile";
            this.btnFile.Size = new System.Drawing.Size(110, 33);
            this.btnFile.TabIndex = 4;
            this.btnFile.Text = "File...";
            this.btnFile.UseVisualStyleBackColor = true;
            this.btnFile.Click += new System.EventHandler(this.btnFile_Click);
            // 
            // textTitle
            // 
            this.textTitle.Location = new System.Drawing.Point(72, 47);
            this.textTitle.Name = "textTitle";
            this.textTitle.Size = new System.Drawing.Size(363, 21);
            this.textTitle.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "타이틀:";
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(325, 159);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(110, 33);
            this.btnOk.TabIndex = 8;
            this.btnOk.Text = "추가";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(209, 159);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(110, 33);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "취소";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            this.openFileDialog.Filter = "\"Media Files|*.jpg;*.png;*.mp3|모든파일|*.*";
            // 
            // ItemShopAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 204);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textTitle);
            this.Controls.Add(this.lblFileStatus);
            this.Controls.Add(this.btnFile);
            this.Controls.Add(this.lblThumbnailStatus);
            this.Controls.Add(this.btnThumbnail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listTypes);
            this.Name = "ItemShopAddForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "아이템 샵 추가";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox listTypes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThumbnail;
        private System.Windows.Forms.Label lblThumbnailStatus;
        private System.Windows.Forms.Label lblFileStatus;
        private System.Windows.Forms.Button btnFile;
        private System.Windows.Forms.TextBox textTitle;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}