﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parse;

namespace JoonLib
{
    class JoonParseObject : ParseObject
    {
        public JoonParseObject(string className, string objectId) : base(className)
        {
            this.ObjectId = objectId;
        }

        public void AddValue(string key, object value)
        {
            try
            {
                this.Add(key, value);
            }
            catch (Exception exp) {

            }
        }
    }
}
