﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;

namespace JoonAdmin
{
    public partial class CheckTalkSessionForm : Form
    {
        string _devicePhoneNumber;
        ParseObject _session;
        public CheckTalkSessionForm(string devicePhoneNumber, ParseObject session)
        {
            _devicePhoneNumber = devicePhoneNumber;
            _session = session;
            InitializeComponent();
            lblSession.Text = _session.ObjectId;
            loadSessionUsers();
        }

        private async void btnFix_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> user = null;
            if (listUser.SelectedItems.Count > 0)
            {
                user = (Dictionary<string, object>)listUser.SelectedItems[0].Tag;
            }
            else
            {
                Array users = _session.Get<Array>("users");
                foreach (Dictionary<string, object> findUser in users)
                {
                    if ((string)findUser["receiveType"] == "sms")
                    {
                        user = findUser;
                        break;
                    }
                }
            }
            if (user == null)
                return;

            if ( DialogResult.OK == MessageBox.Show(string.Format("{0}를 {1}로 변경하시겠습니까?", user["phoneNumber"], _devicePhoneNumber), "변경", MessageBoxButtons.OKCancel)) {
                ActivityIndicator.show("변경 중입니다.");
                RestQuery query = new RestQuery("_User");
                query.equalTo("phoneNumber", _devicePhoneNumber);
                query.orderTo("-updatedAt");
                List<RestServer> talkMainServers = await ServiceList.getServerWithType("talk");
                List<ParseObject> findDeviceUsers = await RestAPI.get(query, true, talkMainServers[0]);
                ParseObject deviceUser = findDeviceUsers[0];

                List<Dictionary<string, object>> newUsers = new List<Dictionary<string, object>>();
                Array users = _session.Get<Array>("users");
                foreach (Dictionary<string, object> oldUser in users)
                {
                    if (user != oldUser)
                    {
                        newUsers.Add(oldUser);
                    }
                    else
                    {
                        newUsers.Add(new Dictionary<string, object>
                        {
                            { "id", deviceUser.ObjectId },
                            { "phoneNumber", _devicePhoneNumber },
                            {  "receiveType", "sms" }
                        });
                    }
                }

                _session["users"] = newUsers.ToArray();
                RestServer sessionServer = TalkServerList.serverWithName((string)_session["server"]);
                await RestAPI.update(_session, new Dictionary<string, object> { { "users", _session.Get<Array>("users") } }.ToList(), sessionServer);
                ActivityIndicator.hide();
                MessageBox.Show("완료되었습니다.");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void loadSessionUsers()
        {
            listUser.Items.Clear();
            Array users = _session.Get<Array>("users");
            foreach (Dictionary<string, object> user in users)
            {
                listUser.AddProp(user["id"],
                                 user["phoneNumber"],
                                 user["receiveType"]).Tag = user;
            }
        }

        private void lblSession_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Clipboard.SetText(lblSession.Text);
        }
    }
}
