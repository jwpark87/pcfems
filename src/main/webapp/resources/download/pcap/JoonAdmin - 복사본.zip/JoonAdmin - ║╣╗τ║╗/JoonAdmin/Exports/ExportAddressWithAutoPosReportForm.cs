﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;

namespace JoonAdmin.Exports
{
    class ExportAddressWithAutoPosReportForm : ExportToForm
    {
        int _rowIndex;

        protected override string getFilePath()
        {
            return Application.StartupPath + "\\addresswithautoposreport.xlsx";
        }

        protected override void didStartExport()
        {
            _rowIndex = _writeRowIndex;
        }

        protected override RestQuery getQuery()
        {
            RestQuery query = new RestQuery("JooNAddress2");
            query.includeKey("device");
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            query.limit(1000);
            return query;
        }

        protected override void didGetParseObject(ParseObject pfObject)
        {
            ParseObject device = (ParseObject)pfObject["device"];
            if (!device.ContainsKey("autoPosReport"))
                return;
            Dictionary<string, object> autoPosReport = device.Get<Dictionary<string, object>>("autoPosReport");
            if ((long)autoPosReport["interval"] == 0)
                return;

            writeLog(pfObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + device.Get<string>("phoneNumber"));

            _xlWorkSheet.Cells[_rowIndex, 1].Value2 = pfObject.Get<DateTime>("createdAt").ToLocalTime().ToString();
            _xlWorkSheet.Cells[_rowIndex, 2].NumberFormat = "@";
            _xlWorkSheet.Cells[_rowIndex, 2].Value2 = device.Get<string>("phoneNumber");
            switch (pfObject.Get<int>("placeType"))
            {
                case DeviceAddress.kAddressPlaceType_Home:
                case DeviceAddress.kAddressPlaceType_HomeApply:
                    _xlWorkSheet.Cells[_rowIndex, 3].Value2 = "집";
                    break;

                case DeviceAddress.kAddressPlaceType_School:
                case DeviceAddress.kAddressPlaceType_SchoolApply:
                    _xlWorkSheet.Cells[_rowIndex, 3].Value2 = "학교/유치원";
                    break;

                case DeviceAddress.kAddressPlaceType_Institute:
                case DeviceAddress.kAddressPlaceType_InstituteApply:
                    _xlWorkSheet.Cells[_rowIndex, 3].Value2 = "학원";
                    break;

                case DeviceAddress.kAddressPlaceType_Etc:
                case DeviceAddress.kAddressPlaceType_EtcApply:
                    _xlWorkSheet.Cells[_rowIndex, 3].Value2 = "기타";
                    break;
            }
            string encKey = device.ObjectId.Substring(0, 8);
            encKey = encKey + encKey + encKey + encKey;
            _xlWorkSheet.Cells[_rowIndex, 4].Value2 = (new AES256Cipher()).AES_decrypt(pfObject.Get<string>("address"), encKey);
            ++_rowIndex;
        }
    }
}
