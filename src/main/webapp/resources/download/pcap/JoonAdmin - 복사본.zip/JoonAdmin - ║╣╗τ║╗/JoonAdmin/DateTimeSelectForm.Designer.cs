﻿namespace JoonAdmin
{
    partial class DateTimeSelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startTime = new System.Windows.Forms.DateTimePicker();
            this.btnOk = new System.Windows.Forms.Button();
            this.endTime = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // startTime
            // 
            this.startTime.Location = new System.Drawing.Point(12, 12);
            this.startTime.Name = "startTime";
            this.startTime.Size = new System.Drawing.Size(200, 21);
            this.startTime.TabIndex = 0;
            this.startTime.ValueChanged += new System.EventHandler(this.startTime_ValueChanged);
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(139, 76);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 34);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "선택";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // endTime
            // 
            this.endTime.Location = new System.Drawing.Point(12, 39);
            this.endTime.Name = "endTime";
            this.endTime.Size = new System.Drawing.Size(200, 21);
            this.endTime.TabIndex = 2;
            // 
            // DateTimeSelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(226, 123);
            this.Controls.Add(this.endTime);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.startTime);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DateTimeSelectForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "날짜선택";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker startTime;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.DateTimePicker endTime;
    }
}