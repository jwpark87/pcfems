﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using JoonLib;

namespace JoonAdmin
{

    public class TalkServerList
    {
        static List<RestServer> _talkServers = null;
        public static async Task<List<RestServer>> getList()
        {
            if (_talkServers != null)
                return _talkServers;
            _talkServers = await ServiceList.getServerWithType("talksession");
            foreach(RestServer server in _talkServers)
            {
                // NOTE : 보안 때문에 TalkServer 의 master key 를 서버에 노출시키지 않았음
                if (server.appId == "unIufRGS6XfKOea05U5T3dRLjayMSN0W5D7SXDGy")
                    server.masterKey = "yyFZ6zt7cp83BCId8DZh5A5arSsrocCOn6q89rcq";
                else if (server.appId == "DuFa2Mp0aQTG4bwHU8beiEm0CIGfxerK27pVfRFR")
                    server.masterKey = "BNGb9pJZjKy2DfmjMn4jr8YbTu5HW0tGMGfFZcrv";

            }
            return _talkServers;
        }

        public static RestServer serverWithName(string name)
        {
            foreach (RestServer server in _talkServers)
            {
                if (server.name == name)
                    return server;

            }
            return null;
        }

    }

    class DataView
    {
        protected ListView listView;
        protected bool _isLoaded;

        public DataView()
        {

        }

        public DataView(ListView listView)
        {
            this.listView = listView;
        }

        public ListView getListView()
        {
            return listView;
        }

        public virtual DataView initWithDataView(ListView listView)
        {
            this.listView = listView;
            return this;
        }

        public void viewDidAppear(ParseObject deviceUser, Form parent)
        {
            if (!_isLoaded)
            {
                loadData(deviceUser, parent);
            }
        }


        public void clear()
        {
            _isLoaded = false;
            listView.Items.Clear();
        }


        public void reload(ParseObject deviceUser, Form parent)
        {
            clear();
            loadData(deviceUser, parent);
        }


        public virtual async Task<bool> loadData(ParseObject deviceUser, Form parent)
        {
            try
            {
                ActivityIndicator.show("데이터 로딩 중입니다.");
                listView.BeginUpdate();
                await loadDataFromServer(deviceUser);
                _isLoaded = true;
                return _isLoaded;
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "불러오기에 실패하였습니다.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                listView.EndUpdate();
                ActivityIndicator.hide();
            }
        }

        protected virtual async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            return false;
        }

        public bool isLoaded()
        {
            return _isLoaded;
        }
    }


    class DeviceDataView : DataView
    {

        public static string getModelName(string modelName)
        {
            if (modelName.Length == 0)
                return "joon1";
            return modelName;
        }

        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("_User");
            query.equalTo("objectId", deviceUser.ObjectId);
            query.includeKey("device");
            List<ParseObject> results = await RestAPI.get(query);
            deviceUser = results[0];
            listView.AddProp("전화번호", deviceUser.GetString("phoneNumber").ToPhoneNumber());
            listView.AddProp("IMEI", deviceUser.GetString("imei").ToIMEI());
            listView.AddProp("시리얼번호", deviceUser.GetString("serialNumber"));

            ParseObject device = deviceUser.GetObject("device");
            if (device != null)
            {
                string model = getModelName(device.GetString("model"));

                string version = device.GetString("version");
                if (version.Length == 0)
                    version = deviceUser.GetString("version");

                string revision = device.GetString("revision");
                if (revision.Length == 0)
                    revision = deviceUser.GetString("revision");

                listView.AddProp("모델", model);
                listView.AddProp("버전", version);
                listView.AddProp("리비전", revision);

                listView.AddProp("이름", deviceUser.GetString("nickname"));
                listView.AddProp("가입일", deviceUser.Get<DateTime>("createdAt"));
            }
            else
            {
                if (DialogResult.Yes == MessageBox.Show("디바이스 정보가 존재하지 않습니다. 잘못된 User 를 삭제하시겠습니까?", "디바이스 정보 오류", MessageBoxButtons.YesNo))
                {
                    try {
                        await RestAPI.deleteObject(deviceUser);
                        MessageBox.Show("삭제 하였습니다. 번호를 재 검색 하세요.", "삭제", MessageBoxButtons.OK);
                    }
                    catch (Exception exp)
                    {
                        MessageBox.Show("삭제에 실패하였습니다.", "삭제", MessageBoxButtons.OK);
                    }
                }
            }
            return true;
        }
    }


    class ManagerDataView : DataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("Manager");
            query.equalTo("device", deviceUser.Get<ParseObject>("device"));
            List<ParseObject> managers = await RestAPI.get(query);
            foreach (ParseObject manager in managers)
            {
                listView.AddProp(manager.GetString("nickname"),
                                     manager.GetString("phoneNumber").ToPhoneNumber(),
                                     manager.Get<DateTime>("createdAt")).Tag = manager;
            }
            return true;
        }
    }


    class ContactDataView : DataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("Contact");
            query.equalTo("device", deviceUser.Get<ParseObject>("device"));
            List<ParseObject> contacts = await RestAPI.get(query);
            foreach (ParseObject contact in contacts)
            {
                listView.AddProp(contact.GetString("nickname"),
                                     contact.GetString("phoneNumber").ToPhoneNumber(),
                                     contact.Get<bool>("joon") ? (contact.GetString("model") == "" ? "joon1" : contact.GetString("model")) : "",
                                     contact.Get<DateTime>("createdAt"));
            }
            return true;
        }
    }



    class TalkDataView : DataView
    {
        protected string getTalkTypeString(int type)
        {
            switch (type)
            {
                case 1: return "그룹톡";
                case 2: return "고스트톡";
            }
            return "";
        }

        protected string getMessageTypeString(int type)
        {
            switch (type)
            {
                case 0: return "상용구";
                case 1: return "음성";
                case 2: return "사운드콘";
            }
            return "";
        }

        protected string getTalkTypeString(ParseObject sendLog)
        {
            if (sendLog.ContainsKey("sessionType"))
                return getTalkTypeString(sendLog.Get<int>("sessionType"));
            return getTalkTypeString(0);
        }

        protected string getMessageTypeString(ParseObject sendLog)
        {
            if (sendLog.ContainsKey("message"))
            {
                ParseObject message = sendLog.Get<ParseObject>("message");
                if (message.ContainsKey("type"))
                    return getMessageTypeString(message.Get<int>("type"));
            }
            return getMessageTypeString(0);
        }
    }


    class RecvTalkDataView : TalkDataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("SendLog2");
            query.equalTo("toNumber", deviceUser.GetString("phoneNumber"));
            query.orderTo("-createdAt");
            query.includeKey("message");
            query.includeKey("message.session");

            List<RestServer> talkServers = await TalkServerList.getList();
            foreach (RestServer server in talkServers)
            {
                List<ParseObject> sendLogs = await RestAPI.get(query, true, server);
                foreach (ParseObject sendLog in sendLogs)
                {
                    try {
                        ParseObject session = sendLog.Get<ParseObject>("message").Get<ParseObject>("session");
                        session["server"] = server.name;

                        listView.AddProp(sendLog.Get<DateTime>("createdAt"),
                                            sendLog.GetString("fromNumber").ToPhoneNumber(),
                                            getTalkTypeString(sendLog),
                                            getMessageTypeString(sendLog),
                                            session.ObjectId,
                                            session.GetString("serverId")
                                            );
                    }
                    catch(Exception exp)
                    {

                    }
                }
            }
            return true;
        }
    }


    class SendTalkDataView : TalkDataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("SendLog2");
            query.equalTo("fromNumber", deviceUser.GetString("phoneNumber"));
            query.orderTo("-createdAt");
            query.includeKey("message");
            query.includeKey("message.session");

            List<RestServer> talkServers = await TalkServerList.getList();
            foreach (RestServer server in talkServers)
            {
                List<ParseObject> sendLogs = await RestAPI.get(query, true, server);
                foreach (ParseObject sendLog in sendLogs)
                {
                    try {
                        ParseObject session = sendLog.Get<ParseObject>("message").Get<ParseObject>("session");
                        session["server"] = server.name;
                        Array users = session.Get<Array>("users");
                        string sessionUserInfo = session.ObjectId;
                        bool isValidSession = false;
                        foreach (Dictionary<string, object> user in users)
                        {
                            if ((string)user["phoneNumber"] == deviceUser.GetString("phoneNumber"))
                            {
                                isValidSession = true;
                            }
                            // sessionUserInfo += string.Format(", {0},{1},{2}", user["id"], user["phoneNumber"], user["receiveType"]);
                        }
                        listView.AddProp(sendLog.Get<DateTime>("createdAt"),
                                            sendLog.GetString("toNumber").ToPhoneNumber(),
                                            getTalkTypeString(sendLog),
                                            getMessageTypeString(sendLog),
                                            sendLog.GetString("type"),
                                            isValidSession ? "" : "이상",
                                            session.ObjectId,
                                            session.GetString("serverId")
                                            ).Tag = session;
                    }
                    catch (Exception exp)
                    {

                    }
                }
            }
            return true;
        }
    }


    class SafeZoneDataView : DataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("SafeZone");
            query.equalTo("device", deviceUser.Get<ParseObject>("device"));
            List<ParseObject> safeZones = await RestAPI.get(query);
            foreach (ParseObject safeZone in safeZones)
            {
                listView.AddProp(safeZone.GetString("name"),
                                     safeZone.ContainsKey("disable") ? safeZone.Get<bool>("disable") : false,
                                     safeZone.Get<double>("rangekm"));
            }
            return true;
        }
    }



    class TrackingDataView : DataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestServer trackingServer = ServiceList.current;
            if (deviceUser.ContainsKey("trackingServer"))
            {
                Dictionary<string, object> dicTrackingServer = deviceUser.Get<Dictionary<string, object>>("trackingServer");
                if (dicTrackingServer != null)
                {
                    if (dicTrackingServer.ContainsKey("serverId"))
                    {
                        trackingServer = await ServiceList.getServerWithId((string)dicTrackingServer["serverId"]);
                    }
                    else
                    {
                        trackingServer = new RestServer(null, (string)dicTrackingServer["id"], null,
                                                              (string)dicTrackingServer["key"], null);
                    }
                }
            }


            RestQuery query = new RestQuery("Tracking");
            query.equalTo("device", deviceUser.Get<ParseObject>("device"));
            query.orderTo("-createdAt");
            query.limit(500);
            List<ParseObject> trackings = await RestAPI.get(query, true, trackingServer);
            foreach (ParseObject tracking in trackings)
            {
                string decGeoPoint = "";
                if (LoginInfo.user.GetString("level") == "admin")
                {
                    string encGeoPoint = tracking.GetString("geoPoint");
                    AES256Cipher cipher = new AES256Cipher();
                    decGeoPoint = cipher.AES_decrypt(encGeoPoint, "ppxr2Uh4qzkfaFzjfFEHsB1uggZWrBVq");
                }

                string strCause = "알수없음";
                switch (tracking.Get<int>("type"))
                {
                    case 0: strCause = "전원켜짐"; break;
                    case 1: strCause = "전원꺼짐"; break;
                    case 2: strCause = "충전알림"; break;
                    case 3: strCause = "SOS"; break;
                    case 4: strCause = "현위치요청"; break;
                    case 5: strCause = "Going Now"; break;
                    case 6: strCause = "자동측위"; break;
                    case 7: strCause = "스케줄알림"; break;
                }

                string strGpsType = "알수없음";
                switch (tracking.Get<int>("gpsType"))
                {
                    case 1: strGpsType = "GPS"; break;
                    case 6: strGpsType = "WiFi 측위실패"; break;
                    case 7:
                        strGpsType = "WiFi";
                        if (tracking.GetInt("gpsSubType") == 10)
                        {
                            strGpsType = "WiFi (Building)";
                        }
                        break;
                    case 8: strGpsType = "P Cell"; break;
                    case 9: strGpsType = "Cell"; break;
                }


                string strSafeZoneEvent = "";
                switch (tracking.Get<int>("safeZoneEvent"))
                {
                    case 2: strSafeZoneEvent = "진입알림"; break;
                    case 3: strSafeZoneEvent = "이탈알림"; break;
                }
                listView.AddProp(tracking.Get<DateTime>("createdAt"),
                                     strGpsType, strCause, strSafeZoneEvent, decGeoPoint);
            }
            return true;
        }
    }



    class ToyDataView : DataView
    {
        TextBox _editBox;
        ListViewItem _editItem;
        ListViewItem.ListViewSubItem _editSubItem;
        RestServer _toyServer;

        public override DataView initWithDataView(ListView listView)
        {
            base.initWithDataView(listView);
            listView.KeyDown += listView_KeyDown;
            listView.MouseDoubleClick += listView_MouseDoubleClick;
            listView.SelectedIndexChanged += listView_SelectedIndexChanged;

            _editBox = new TextBox();
            _editBox.Hide();
            listView.Controls.Add(_editBox);
            _editBox.KeyPress += _editBox_KeyPress;
            return this;
        }



        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            if (_toyServer == null)
                _toyServer = (await ServiceList.getServerWithType("toy"))[0];

            RestQuery query = new RestQuery("MyBadge");
            query.equalTo("device", deviceUser.Get<ParseObject>("device"));
            query.orderTo("-updatedAt");

            List<ParseObject> results = await RestAPI.get(query, true, _toyServer);
            if (results.Count > 0) {
                ParseObject myBadge = results[0];
                listView.AddProp("코인 수", myBadge.GetInt("valueCount")).Tag = myBadge;
            }
            else
            {
                listView.AddProp("코인 수", "단말에서 문제를 푼 기록이 없습니다.");
            }


            query = new RestQuery("MyCharacter");
            query.equalTo("device", deviceUser.Get<ParseObject>("device"));
            query.orderTo("characterPack");
            query.includeKey("characterPack");
            List<ParseObject> characterList = await RestAPI.get(query, true, _toyServer);
            foreach (ParseObject myCharacter in characterList)
            {
                if (myCharacter.ContainsKey("characterPack"))
                {
                    ParseObject characterPack = myCharacter.Get<ParseObject>("characterPack");
                    listView.AddProp(characterPack.GetString("name"), myCharacter.GetInt("level")).Tag = myCharacter;
                }
                else
                {
                    listView.AddProp("invalid character pack").Tag = myCharacter;
                }
            }

            return true;
        }

        public void listView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListViewItem curItem = listView.GetItemAt(e.Location.X, e.Location.Y);
            if (curItem != null && curItem.Tag != null)
            {
                if (((ParseObject)curItem.Tag).ClassName == "MyBadge")
                {
                    ListViewItem.ListViewSubItem subItem = curItem.GetSubItemAt(e.Location.X, e.Location.Y);
                    if (subItem != null)
                    {
                        _editItem = curItem;
                        _editSubItem = subItem;
                        _editBox.Bounds = subItem.Bounds;
                        _editBox.Text = subItem.Text;
                        _editBox.Show();
                        _editBox.Focus();
                    }
                }
                else if (((ParseObject)curItem.Tag).ClassName == "MyCharacter")
                {
                    if (MessageBox.Show("캐릭터 삭제", "삭제하시겠습니까?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        RestAPI.deleteObject((ParseObject)curItem.Tag, _toyServer);
                        listView.Items.Remove(curItem);
                    }
                }
            }
        }

        public void listView_KeyDown(object sender, KeyEventArgs e)
        {

        }

        async void _editBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                if (_editItem == null)
                    return;

                _editSubItem.Text = _editBox.Text;
                _editBox.Hide();

                switch(_editItem.Index)
                {
                    case 0:
                        {
                            ParseObject myBadge = (ParseObject)_editItem.Tag;
                            myBadge["valueCount"] = Int32.Parse(_editSubItem.Text);
                            await RestAPI.update(myBadge, new Dictionary<string, object> { { "valueCount", Int32.Parse(_editSubItem.Text) } }.ToList(), _toyServer);
                        }
                        break;
                }

                _editItem = null;
                _editSubItem = null;
            }
            else if (e.KeyChar == (char)Keys.Escape)
            {
                _editBox.Hide();
                _editItem = null;
                _editSubItem = null;
            }
        }

        void listView_SelectedIndexChanged(object sender, EventArgs e)
        {
            _editBox.Hide();
            _editItem = null;
            _editSubItem = null;
        }
    }


    class UserVoiceHistoryView : DataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("UVHistory");
            query.orderTo("-updatedAt");
            List<ParseObject> logs = await RestAPI.get(query, true, ServiceList.current.adminServer);
            foreach (ParseObject log in logs)
            {
                listView.AddProp(log.GetString("searchNumber").ToPhoneNumber(),
                                 log.Get<DateTime>("updatedAt")).Tag = log;
            }
            return true;
        }
    }


    class DeviceHistoryView : DataView
    {
        protected override async Task<bool> loadDataFromServer(ParseObject deviceUser)
        {
            RestQuery query = new RestQuery("_User");
            query.orderTo("-createdAt");
            query.equalTo("phoneNumber", deviceUser.GetString("phoneNumber"));
            query.includeKey("device");
            List<ParseObject> results = await RestAPI.get(query);
            foreach (ParseObject user in results)
            {
                ParseObject device = user.Get<ParseObject>("device");
                listView.AddProp((user.ObjectId == deviceUser.ObjectId ? "(현재)" : ""),
                                 user.Get<DateTime>("createdAt"),
                                 user.Get<DateTime>("updatedAt"),
                                 user.GetString("imei").ToIMEI(),
                                 user.GetString("serialNumber"),
                                 DeviceDataView.getModelName(user.GetString("model")),
                                 DeviceDataView.getModelName(device.GetString("model")),
                                 user.GetString("version"),
                                 device.GetString("version")).Tag = user;
                    
            }
            return true;
        }
    }

}
