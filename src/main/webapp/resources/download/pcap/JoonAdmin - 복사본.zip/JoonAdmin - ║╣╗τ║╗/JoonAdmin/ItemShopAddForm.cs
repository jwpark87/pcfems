﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using System.IO;

namespace JoonAdmin
{
    public partial class ItemShopAddForm : Form
    {
        ParseFile thumbnailFile;
        ParseFile mediaFile;

        public ItemShopAddForm()
        {
            InitializeComponent();
        }

        private async void btnThumbnail_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == openFileDialog.ShowDialog())
            {
                thumbnailFile = new ParseFile("thumbnail" + Path.GetExtension(openFileDialog.FileName), File.ReadAllBytes(openFileDialog.FileName));
                await thumbnailFile.SaveAsync();
                lblThumbnailStatus.Text = "업로드 완료";
            }
        }

        private async void btnFile_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == openFileDialog.ShowDialog())
            {
                mediaFile = new ParseFile("media" + Path.GetExtension(openFileDialog.FileName), File.ReadAllBytes(openFileDialog.FileName));
                await mediaFile.SaveAsync();
                lblFileStatus.Text = "업로드 완료";
            }
        }

        private async void btnOk_Click(object sender, EventArgs e)
        {
            try {
                int type = listTypes.SelectedIndex;
                ParseObject funItem = new ParseObject("FunItem");
                funItem["type"] = type;
                funItem["hidden"] = false;
                if (type == 0)
                    funItem["image"] = mediaFile;
                else if (type == 1)
                    funItem["sound"] = mediaFile;
                funItem["order"] = 0;
                funItem["title"] = textTitle.Text;
                funItem["thumbnail"] = thumbnailFile;
                await funItem.SaveAsync();
                MessageBox.Show("저장하였습니다.");

                lblThumbnailStatus.Text = "";
                lblFileStatus.Text = "";
                thumbnailFile = null;
                mediaFile = null;
                textTitle.Text = "";
            }
            catch(Exception exp)
            {
                MessageBox.Show("저장 오류 발생." + exp.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
