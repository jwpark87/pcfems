﻿namespace JoonAdmin
{
    partial class PushEventForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStop = new System.Windows.Forms.Button();
            this.textLog = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.listDeviceType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listTextType = new System.Windows.Forms.ComboBox();
            this.textPushData = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textPhoneNumbers = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(531, 450);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(88, 28);
            this.btnStop.TabIndex = 4;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // textLog
            // 
            this.textLog.Location = new System.Drawing.Point(11, 278);
            this.textLog.Multiline = true;
            this.textLog.Name = "textLog";
            this.textLog.ReadOnly = true;
            this.textLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textLog.Size = new System.Drawing.Size(608, 166);
            this.textLog.TabIndex = 3;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(437, 450);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(88, 28);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // listDeviceType
            // 
            this.listDeviceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listDeviceType.FormattingEnabled = true;
            this.listDeviceType.Items.AddRange(new object[] {
            "All",
            "Android",
            "iOS"});
            this.listDeviceType.Location = new System.Drawing.Point(114, 25);
            this.listDeviceType.Name = "listDeviceType";
            this.listDeviceType.Size = new System.Drawing.Size(159, 20);
            this.listDeviceType.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Device Type";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Text Type";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // listTextType
            // 
            this.listTextType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listTextType.FormattingEnabled = true;
            this.listTextType.Items.AddRange(new object[] {
            "Text",
            "Json"});
            this.listTextType.Location = new System.Drawing.Point(114, 62);
            this.listTextType.Name = "listTextType";
            this.listTextType.Size = new System.Drawing.Size(159, 20);
            this.listTextType.TabIndex = 9;
            // 
            // textPushData
            // 
            this.textPushData.Location = new System.Drawing.Point(11, 149);
            this.textPushData.Multiline = true;
            this.textPushData.Name = "textPushData";
            this.textPushData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textPushData.Size = new System.Drawing.Size(608, 106);
            this.textPushData.TabIndex = 10;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(11, 450);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(88, 28);
            this.btnReset.TabIndex = 11;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "PhoneNumber";
            // 
            // textPhoneNumbers
            // 
            this.textPhoneNumbers.Location = new System.Drawing.Point(114, 99);
            this.textPhoneNumbers.Name = "textPhoneNumbers";
            this.textPhoneNumbers.Size = new System.Drawing.Size(505, 21);
            this.textPhoneNumbers.TabIndex = 13;
            // 
            // PushEventForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 501);
            this.Controls.Add(this.textPhoneNumbers);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.textPushData);
            this.Controls.Add(this.listTextType);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listDeviceType);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.textLog);
            this.Name = "PushEventForm";
            this.Text = "PushEventForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TextBox textLog;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox listDeviceType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox listTextType;
        private System.Windows.Forms.TextBox textPushData;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textPhoneNumbers;
    }
}