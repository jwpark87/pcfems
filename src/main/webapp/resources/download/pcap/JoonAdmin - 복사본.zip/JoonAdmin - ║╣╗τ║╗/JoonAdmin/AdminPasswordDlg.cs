﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoonAdmin
{
    public partial class AdminPasswordDlg : Form
    {

        Form m_mainForm;
        Type m_createClass;

        public AdminPasswordDlg(Form mainForm, Type createClass)
        {
            InitializeComponent();
            m_mainForm = mainForm;
            m_createClass = createClass;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (textPassword.Text == "rlaruddnjs2015")
            {
                Form childForm = (Form)Activator.CreateInstance(m_createClass);
                childForm.MdiParent = m_mainForm;
                childForm.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("잘못된 비밀번호 입니다. 승인된 관리자만 이용하실 수 있습니다.");
                this.Close();
            }
        }
    }
}
