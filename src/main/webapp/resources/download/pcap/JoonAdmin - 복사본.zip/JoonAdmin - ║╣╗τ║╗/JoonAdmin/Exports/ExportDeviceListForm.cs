﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;
using Excel = Microsoft.Office.Interop.Excel;

namespace JoonAdmin.Exports
{
    class ExportDeviceListForm : ExportToForm
    {
        int _colIndex;

        protected override string getFilePath()
        {
            return Application.StartupPath + "\\" + ServiceList.current.name + "_devicelist.xlsx";
        }

        protected override RestQuery getQuery()
        {
            RestQuery query = new RestQuery("_User");
            query.equalTo("type", "device");
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            query.includeKey("device");
            query.limit(1000);
            return query;
        }

        protected override void didGetParseObject(ParseObject pfObject)
        {
            _colIndex = 1;
            writeLog(pfObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + pfObject.Get<string>("phoneNumber"));
            writeCreatedAt(pfObject);
            writePhoneNumber(pfObject);

            String model = null;
            ParseObject device = pfObject.Get<ParseObject>("device");
            if (device != null)
            {
                model = device.GetString("model");
            }
            if (model == null || model.Length == 0)
                model = "joon1";
            writeText(model);

            string version = device.GetString("version");
            if (version.Length == 0)
                version = pfObject.GetString("version");
            writeText(version);
        }

        void writePhoneNumber(ParseObject pfObject)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].NumberFormat = "@";
            writeText(pfObject.GetString("phoneNumber"));
        }

        void writeCreatedAt(ParseObject pfObject)
        {
            writeText(pfObject.Get<DateTime>("createdAt").ToLocalTime().ToString());
        }

        void writeText(String value)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].Value2 = value;
            ++_colIndex;
        }
    }
}

