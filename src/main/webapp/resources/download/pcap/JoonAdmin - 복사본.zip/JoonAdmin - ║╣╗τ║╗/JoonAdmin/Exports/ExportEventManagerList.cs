﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;
using Excel = Microsoft.Office.Interop.Excel;

namespace JoonAdmin.Exports
{
    class ExportEventManagerList : ExportToForm
    {
        DateTime _queryStartDate;
        DateTime _queryEndDate;

        int _colIndex;
        List<String> _devicePhoneNumbers = new List<String>();

        public DateTime QueryDate
        {
            set
            {
                _queryStartDate = value;
                _queryEndDate = value.AddDays(1);
            }
        }

        public void setQueryDate(DateTime startDate, DateTime endDate)
        {
            if (startDate.Equals(endDate))
            {
                _queryStartDate = startDate;
                _queryEndDate = startDate.AddDays(1);
            }
            else
            {
                _queryStartDate = startDate;
                _queryEndDate = endDate.AddDays(1);
            }
        }

        protected override string getFilePath()
        {
            return Application.StartupPath + "\\" + ServiceList.current.name + "_eventmanagerlist_" + _queryStartDate.ToShortDateString() + ".xlsx";
        }

        protected override void didStartExport()
        {
            _colIndex = 1;
            _writeRowIndex = 1;
            _xlWorkSheet.Cells.ClearContents();
            writeText("단말 생성일");
            writeText("단말 전화번호");
            writeText("전체 관리자 수");
            writeText("금일 추가된 관리자 수");
            writeText("추가된 관리자 앱 설치 수");
            for (int i = 0; i < 6; ++i)
            {
                writeText("관리자 생성일");
                writeText("앱 설치 일");
                writeText("관리자 전화번호");
            }
            ++_writeRowIndex;
            _lastDate = _queryStartDate;
        }

        protected override RestQuery getQuery()
        {
            RestQuery query = new RestQuery("Manager");
            query.includeKey("device");
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            query.lessThen("createdAt", _queryEndDate);
            query.limit(1000);
            return query;
        }

        protected override bool shouldInsertNewObject(ParseObject pfObject)
        {
            ParseObject deviceObject = pfObject.Get<ParseObject>("device");
            if (_devicePhoneNumbers.Contains(deviceObject.GetString("phoneNumber")))
                return false;
            return true;
        }

        protected override void didGetParseObject(ParseObject pfObject)
        {
            ParseObject deviceObject = pfObject.Get<ParseObject>("device");
            _colIndex = 1;
            // writeLog(deviceObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + deviceObject.Get<string>("phoneNumber"));
            writeCreatedAt(deviceObject);
            writePhoneNumber(deviceObject);
        }

        protected override async Task<int> didGetParseObjectAsync(ParseObject pfObject)
        {
            RestQuery query = new RestQuery("Manager");
            query.equalTo("device", pfObject.Get<ParseObject>("device"));
            query.orderTo("createdAt");
            query.limit(1000);

            List<ParseObject> managerList = await RestAPI.get(query);
            List<String> managerAppInstallList = new List<String>();

            writeLong(managerList.Count);
            long eventUserCount = 0;
            long eventUserRegisterCount = 0;
            for (int i=0; i<managerList.Count; ++i)
            {
                List<ParseObject> managerUserList = await RestAPI.get(queryForUser(managerList[i]));
                ParseObject managerUser = managerUserList.Count > 0 ? managerUserList[0] : null;
                String appInstallDate = "";
                if (managerUser != null)
                    appInstallDate = managerUser.Get<DateTime>("createdAt").ToLocalTime().ToString();

                if (i > 0)
                {
                    DateTime createdAt = managerList[i].Get<DateTime>("createdAt").ToLocalTime();
                    if (_queryStartDate < createdAt && createdAt < _queryEndDate)
                    {
                         ++eventUserCount;
                        if (managerUser != null)
                        {
                            //DateTime userCreatedAt = managerUser.Get<DateTime>("createdAt").ToLocalTime();
                            //if ( createdAt <= userCreatedAt )
                                ++eventUserRegisterCount;
                        }
                    }
                }
                managerAppInstallList.Add(appInstallDate);
            }
            writeLong(eventUserCount);
            writeLong(eventUserRegisterCount);
            for (int i=-0; i < managerList.Count; ++i)
            {
                ParseObject manager = managerList[i];
                writeCreatedAt(manager);
                writeText(managerAppInstallList[i]);
                writePhoneNumber(manager);
            }
            writeLog(pfObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + pfObject.Get<string>("phoneNumber") + ", " + eventUserCount + "/" + managerList.Count);
            return 1;
        }

        RestQuery queryForUser(ParseObject manager)
        {
            RestQuery query = new RestQuery("_User");
            query.equalTo("type", "manager");
            query.equalTo("phoneNumber", manager.GetString("phoneNumber"));
            return query;
        }


        void writePhoneNumber(ParseObject pfObject)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].NumberFormat = "@";
            writeText(pfObject.GetString("phoneNumber"));
        }

        void writeCreatedAt(ParseObject pfObject)
        {
            writeText(pfObject.Get<DateTime>("createdAt").ToLocalTime().ToString());
        }

        void writeText(String value)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].Value2 = value;
            ++_colIndex;
        }

        void writeLong(long value)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].Value2 = value;
            ++_colIndex;
        }
    }
}

