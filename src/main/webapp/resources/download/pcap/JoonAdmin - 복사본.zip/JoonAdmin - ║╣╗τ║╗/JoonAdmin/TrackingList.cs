﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    public partial class TrackingList : Form
    {
        ParseObject m_device;
        IEnumerable<ParseObject> m_trackingList;

        public delegate void didTrackingSelected(List<ParseObject> trackings);

        didTrackingSelected m_delegate;
        int m_beforeDayCount;

        public TrackingList(ParseObject device, didTrackingSelected receiver, int beforeDayCount = -4)
        {
            m_beforeDayCount = beforeDayCount;
            m_device = device;
            m_delegate = receiver;
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            List<ParseObject> selectList = new List<ParseObject>();
            foreach (ListViewItem i in listTracking.CheckedItems)
            {
                selectList.Add((ParseObject)i.Tag);
            }
            if (m_delegate != null)
                m_delegate(selectList);
            this.Close();
        }


        private string getSafeString(Dictionary<string, object> obj, string key)
        {
            try
            {
                return (string)obj[key];
            }
            catch (Exception)
            {
                return "";
            }
        }


        private async void TrackingList_Shown(object sender, EventArgs e)
        {
            RestServer trackingServer = ServiceList.current;

            if (m_device.ContainsKey("trackingServer"))
            {
                Dictionary<string, object> dicTrackingServer = m_device.Get<Dictionary<string, object>>("trackingServer");
                if (dicTrackingServer != null)
                {
                    string serverId = getSafeString(dicTrackingServer, "serverId");
                    if (serverId.Length > 0)
                    {
                        trackingServer = await ServiceList.getServerWithId(serverId);
                    }
                    else
                    {
                        trackingServer = new RestServer(null, (string)dicTrackingServer["id"], null,
                                                            (string)dicTrackingServer["key"], null);
                    }
                }
            }

            DateTime startDate = DateTime.Now.AddDays(m_beforeDayCount);


            RestQuery query = new RestQuery("Tracking");
            query.equalTo("device", m_device);
            query.orderTo("-createdAt");
            // query.greatherThen("createdAt", startDate);
            //query.limit(100);
            m_trackingList = await RestAPI.get(query, true, trackingServer);
            foreach (ParseObject tracking in m_trackingList)
            {
                string strTime = tracking.Get<DateTime>("createdAt").ToLocalTime().ToString();
                string strCause = "알수없음";
                switch (tracking.Get<int>("type"))
                {
                    case 0: strCause = "전원켜짐"; break;
                    case 1: strCause = "전원꺼짐"; break;
                    case 2: strCause = "충전알림"; break;
                    case 3: strCause = "SOS"; break;
                    case 4: strCause = "현위치요청"; break;
                    case 5: strCause = "Going Now"; break;
                    case 6: strCause = "자동측위"; break;
                    case 7: strCause = "스케줄알림"; break;
                }

                string strGpsType = "알수없음";
                switch(tracking.Get<int>("gpsType")) {
                    case 1: strGpsType = "GPS"; break;
                    case 6: strGpsType = "WiFi 측위실패"; break;
                    case 7: strGpsType = "WiFi";
                        if (tracking.GetInt("gpsSubType") == 10)
                        {
                            strGpsType = "WiFi (Building)";
                        }
                        break;
                    case 8: strGpsType = "P Cell"; break;
                    case 9: strGpsType = "Cell"; break;
                }

                string strPosition = "";

                ListViewItem item = new ListViewItem(strTime);
                item.SubItems.Add(strCause);
                item.SubItems.Add(strGpsType);
                item.SubItems.Add(strPosition);
                item.Tag = tracking;
                listTracking.Items.Add(item);
            }
        }
    }
}
