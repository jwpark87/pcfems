﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;
using Excel = Microsoft.Office.Interop.Excel;

namespace JoonAdmin.Exports
{
    class ExportPushOffUserList : ExportToForm
    {
        int _colIndex;

        protected override string getFilePath()
        {
            return Application.StartupPath + "\\" + ServiceList.current.name + "_user_pushoff.xlsx";
        }

        protected override RestQuery getQuery()
        {
            RestQuery query = new RestQuery("_User");
            query.equalTo("type", "manager");
            query.equalTo("disablePush", true);
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            query.limit(1000);
            return query;
        }

        protected override void didGetParseObject(ParseObject pfObject)
        {
            _colIndex = 1;
            writeLog(pfObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + pfObject.Get<string>("phoneNumber"));
            writeCreatedAt(pfObject);
            writePhoneNumber(pfObject);
        }

        protected override async Task<int> didGetParseObjectAsync(ParseObject pfObject)
        {
            RestQuery query = new RestQuery("Device");
            query.relation("devices", pfObject);
            List<ParseObject> deviceList = await RestAPI.get(query);
            foreach (ParseObject device in deviceList)
            {
                writePhoneNumber(device);
            }
            return 1;
        }

        void writePhoneNumber(ParseObject pfObject)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].NumberFormat = "@";
            writeText(pfObject.GetString("phoneNumber"));
        }

        void writeCreatedAt(ParseObject pfObject)
        {
            writeText(pfObject.Get<DateTime>("createdAt").ToLocalTime().ToString());
        }

        void writeText(String value)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].Value2 = value;
            ++_colIndex;
        }
    }
}

