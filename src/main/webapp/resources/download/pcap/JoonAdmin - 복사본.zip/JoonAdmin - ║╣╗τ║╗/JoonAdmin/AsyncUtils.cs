﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoonAdmin
{
    static class AsyncUtils
    {
        public static async void DelayFor(this Action act, TimeSpan delay)
        {
            await Task.Delay(delay);
            act();
        }
    }
}
