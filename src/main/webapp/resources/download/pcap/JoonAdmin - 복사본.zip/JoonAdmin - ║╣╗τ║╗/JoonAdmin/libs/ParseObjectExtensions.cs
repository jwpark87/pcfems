﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parse;

namespace JoonLib
{
    public static class ParseObjectExtensions
    {
        public static void SetString(this ParseObject pfObject, string key, string text)
        {
            if (pfObject.ContainsKey(key))
            {
                pfObject[key] = text;
            }
            else
            {
                pfObject.Add(key, text);
            }
        }


        public static string GetString(this ParseObject pfObject, string key)
        {
            try
            {
                return pfObject.Get<string>(key);
            }
            catch (Exception)
            {
                return "";
            }
        }

        public static ParseObject GetObject(this ParseObject pfObject, string key)
        {
            try
            {
                return pfObject.Get<ParseObject>(key);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static int GetInt(this ParseObject pfObject, string key)
        {
            try
            {
                return pfObject.Get<int>(key);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public static double GetDouble(this ParseObject pfObject, string key)
        {
            try
            {
                return pfObject.Get<double>(key);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public static bool IsDisable(this ParseObject pfObject, string key)
        {
            try
            {
                return pfObject.Get<bool>(key);
            }
            catch (Exception)
            {
                return true;
            }
        }
    }
}
