﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    public partial class ShowLog : Form
    {
        public ShowLog(ParseObject device)
        {
            InitializeComponent();
            loadLog(device);
        }

        public async void loadLog(ParseObject device)
        {
            try
            {
                var query = ((new Parse.ParseQuery<ParseObject>("Log")).WhereEqualTo("phoneNumber", device.Get<string>("phoneNumber"))).OrderBy("createdAt");
                IEnumerable<ParseObject> logs = await query.FindAsync();
                foreach (ParseObject log in logs)
                {
                    ListViewItem lvi = new ListViewItem(log.Get<DateTime>("localTime").ToString());
                    try
                    {
                        lvi.SubItems.Add(log.Get<string>("func"));
                        lvi.SubItems.Add(log.Get<string>("message"));
                        lvi.SubItems.Add(log.Get<Dictionary<string, object>>("params").ToString());
                    }
                    catch
                    {

                    }
                    listLog.Items.Add(lvi);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "로그 가져오기 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
