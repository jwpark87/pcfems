﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;

namespace JoonAdmin
{
    public partial class FindInvalidDeviceUserForm : Form
    {
        public FindInvalidDeviceUserForm()
        {
            InitializeComponent();
        }

        private async void FindInvalidDeviceUserForm_Shown(object sender, EventArgs e)
        {
            DateTime lastDate = new DateTime(2015, 12, 1);
            List<ParseObject> users;
            do
            {
                RestQuery query = new RestQuery("_User");
                query.greatherThen("createdAt", lastDate);
                query.equalTo("type", "device");
                query.orderTo("createdAt");
                query.includeKey("device");
                users = await RestAPI.get(query);
                writeLog("query " + lastDate.ToString() + ", " + users.Count);
                if (users.Count > 0)
                {
                    foreach(ParseObject user in users)
                    {
                        ParseObject device = user.ContainsKey("device") ? user.Get<ParseObject>("device") : null;
                        if (device == null || !device.ContainsKey("phoneNumber")) {
                            writeLog(user.ObjectId + ", " + user.GetString("phoneNumber"));
                        }
                    }
                    lastDate = users[users.Count - 1].Get<DateTime>("createdAt");
                }
            } while (users.Count > 1);
        }

        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }

    }
}
