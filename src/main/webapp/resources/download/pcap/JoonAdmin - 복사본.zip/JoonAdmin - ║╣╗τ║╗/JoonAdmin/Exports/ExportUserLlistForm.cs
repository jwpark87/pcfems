﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;
using Excel = Microsoft.Office.Interop.Excel;

namespace JoonAdmin.Exports
{
    class ExportUserLlistForm : ExportToForm
    {
        int _colIndex;

        protected override string getFilePath()
        {
            return Application.StartupPath + "\\" + ServiceList.current.name + "_user_managerlist.xlsx";
        }

        protected override RestQuery getQuery()
        {
            RestQuery query = new RestQuery("_User");
            query.equalTo("type", "device");
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            query.includeKey("device");
            query.limit(1000);
            return query;
        }

        protected override void didGetParseObject(ParseObject pfObject)
        {
            _colIndex = 1;
            writeLog(pfObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + pfObject.Get<string>("phoneNumber"));
            writeCreatedAt(pfObject);
            writePhoneNumber(pfObject);

            String model = null;
            ParseObject device = pfObject.Get<ParseObject>("device");
            if (device != null)
            {
                model = device.GetString("model");
            }
            if (model == null || model.Length == 0)
                model = "joon1";
            writeText(model);
            string version = device.GetString("version");
            if (version.Length == 0)
                version = pfObject.GetString("version");
            writeText(version);
        }

        protected override async Task<int> didGetParseObjectAsync(ParseObject pfObject)
        {
            ParseObject device = pfObject.Get<ParseObject>("device");
            if (device != null)
            {
                List<ParseObject> managers = await RestAPI.get(managerQuery(device), true);
                foreach (ParseObject manager in managers)
                {
                    RestQuery query = new RestQuery("CarrierCheck");
                    query.equalTo("phoneNumber", manager.GetString("phoneNumber"));
                    int count = await RestAPI.count(query);
                    writePhoneNumber(manager);
                    writeCreatedAt(manager);
                    writeText(count > 0 ? "타사" : "SKT");
                    writeLog("count = " + count);
                }
                /*
                if (managers.Count > 0)
                {
                    List<ParseObject> carrierCheckList = await RestAPI.get(carrierQuery(managers), true);
                    foreach (ParseObject manager in managers)
                    {
                        writePhoneNumber(manager);
                        writeCreatedAt(manager);
                        writeText(getCarrierName(manager, carrierCheckList));
                    }
                }
                */
            }
            return 1;
        }

        RestQuery managerQuery(ParseObject device)
        {
            RestQuery query = new RestQuery("Manager");
            query.equalTo("device", device);
            query.orderTo("createdAt");
            return query;
        }

        RestQuery carrierQuery(List<ParseObject> managers)
        {
            List<String> managerPhoneNumbers = new List<String>();
            foreach (ParseObject manager in managers) {
                managerPhoneNumbers.Add(manager.GetString("phoneNumber"));
            }

            RestQuery query = new RestQuery("CarrierCheck");
            query.containedIn("phoneNumber", managerPhoneNumbers);
            return query;
        }

        String getCarrierName(ParseObject manager, List<ParseObject> carrierCheckList)
        {
            foreach (ParseObject carrierCheck in carrierCheckList)
            {
                if (carrierCheck.GetString("phoneNumber").Equals(manager.GetString("phoneNumber")))
                {
                    return "타사(" + carrierCheck.GetInt("result") + ")";
                }
            }
            return "SKT";
        }

        void writePhoneNumber(ParseObject pfObject)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].NumberFormat = "@";
            writeText(pfObject.GetString("phoneNumber"));
        }

        void writeCreatedAt(ParseObject pfObject)
        {
            writeText(pfObject.Get<DateTime>("createdAt").ToLocalTime().ToString());
        }

        void writeText(String value)
        {
            _xlWorkSheet.Cells[_writeRowIndex, _colIndex].Value2 = value;
            ++_colIndex;
        }
    }
}

