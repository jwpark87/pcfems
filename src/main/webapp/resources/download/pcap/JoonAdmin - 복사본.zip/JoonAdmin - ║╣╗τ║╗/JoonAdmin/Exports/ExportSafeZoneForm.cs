﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;
using Excel = Microsoft.Office.Interop.Excel;


namespace JoonAdmin.Exports
{
    class ExportSafeZoneForm : ExportToForm
    {
        string _currentDevicePhoneNumber = "";
        int _rowCount = 0;
        int _colCount;

        protected override string getFilePath()
        {
            return Application.StartupPath + "\\safezone.xlsx";
        }

        protected override RestQuery getQuery()
        {
            RestQuery query = new RestQuery("SafeZone");
            query.includeKey("device");
            query.orderTo("device");
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            query.limit(1000);
            return query;
        }

        protected override void didGetParseObject(ParseObject pfObject)
        {
            ParseObject device = (ParseObject)pfObject["device"];
            writeLog(pfObject.Get<DateTime>("createdAt").ToLocalTime() + ", " + device.Get<string>("phoneNumber"));

            if (_currentDevicePhoneNumber != device.Get<string>("phoneNumber"))
            {
                ++_rowCount;
                _currentDevicePhoneNumber = device.Get<string>("phoneNumber");
                _xlWorkSheet.Cells[_rowCount, 1].Value2 = pfObject.Get<DateTime>("createdAt").ToLocalTime().ToString();
                _xlWorkSheet.Cells[_rowCount, 2].NumberFormat = "@";
                _xlWorkSheet.Cells[_rowCount, 2].Value2 = device.Get<string>("phoneNumber");
                _colCount = 3;
            }
            _xlWorkSheet.Cells[_rowCount, _colCount++].Value2 = pfObject.IsDisable("disable") == true ? "Off" : "On";
            _xlWorkSheet.Cells[_rowCount, _colCount++].Value2 = pfObject.GetString("name");
            _xlWorkSheet.Cells[_rowCount, _colCount++].Value2 = pfObject.GetDouble("rangekm");
        }
    }
}

