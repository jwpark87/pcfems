﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
#if FEATURE_TCARE_ADMINONLY
            ServiceList.list = new ServiceServer[] {
                new ServiceServer("T-Care", "T5VLWqisXMjn6GK3dT1hkcYNseSPXBIr7cJcbAXk",
                                            "b7bwPx41N0bOtQSY4mBQ0kwjj2mYv0ON9c7Qv0dZ",
                                            "kOHJibOJ4jKkly6Xsy6ww1XaXF84unQG2JVqRMVe",
                                            "oM3HiRvJTveWI1qHxAsagq6PKIc7vyWsN5jGhMk9",

                            new RestServer("TCareLBS", "rnIPwysv2wurNPdQWPQCgpystk8r61xMF08TA1we",
                                                     "e9waj1y4h7UV2huuYNDt1cAansWcqlgF4Q0CVQtL",
                                                     "r2SDjz35mI9pm3h1ZdDroEL5N8PBtFL6P9qrnKBw",
                                                     "TLfXuHpeQskh9suoqJsWDWo9Bwycp5a9XvfS4SMH"),
                            "CareServer"),
            };
#else
            ServiceList.list = new ServiceServer[] {
                new ServiceServer("JooN", "flfSMIIXJRK5Oe7ZjTMLzcYlJZmwHV97VyHsRJZL",
                                          "CfntgEXdgTGjObNrsW8GOB2A1IyJicNgDHQB5yGG",
                                          "1mSOHI5CL1oePblrfSj94P6n4otz2Tpe86NmDvs9",
                                          "IDknIWhegy1cEN0ctsZ0VSoBnfzqvXAG4p9sQGTi",

                                        new RestServer("TMarkAdmin", "F8RFJAQVQdafTR2JRwj68KaSOWdu8cjYCFEc7eEk",
                                                               "TcVRzqoGsXM4nWIl12ccBxACvohvZYPRqXovg9hC",
                                                               "kC7UegvX09A9TfGEIn1iu3CON712oFs9TgbXqvRB",
                                                               "WbnklwgL6ICgeBJsot5nadAKwa19QOPDL1ssJ2Ir"),

                                        "Server"),

                new ServiceServer("T-Care", "T5VLWqisXMjn6GK3dT1hkcYNseSPXBIr7cJcbAXk",
                                            "b7bwPx41N0bOtQSY4mBQ0kwjj2mYv0ON9c7Qv0dZ",
                                            "kOHJibOJ4jKkly6Xsy6ww1XaXF84unQG2JVqRMVe",
                                            "oM3HiRvJTveWI1qHxAsagq6PKIc7vyWsN5jGhMk9",

                            new RestServer("TCareLBS", "rnIPwysv2wurNPdQWPQCgpystk8r61xMF08TA1we",
                                                     "e9waj1y4h7UV2huuYNDt1cAansWcqlgF4Q0CVQtL",
                                                     "r2SDjz35mI9pm3h1ZdDroEL5N8PBtFL6P9qrnKBw",
                                                     "TLfXuHpeQskh9suoqJsWDWo9Bwycp5a9XvfS4SMH"),
                            "CareServer"),

                new ServiceServer("JooNDev", "T1XctG6y8gEPTNFhHlDDpuN3K7f5frVNRy5ML40s",
                                             "d4Kr6VeBcwPO1k9lKF0vPXNHdJ3rrWPFCxtxMx97",
                                             "ihOK87krWpUDqMFgZ6OFHqHk9hwwu0QkwCDLGn9f",
                                             "XHy6fzNmF0z9wUHwpmCGhIkvQiuC3WtMycv2F2p1")
            };

#endif
            ServiceList.serverListQueryServer = new RestServer("ServerList",
                                                        "lI1fYnhjyS07nXWLe2RkbEVGNxXSSPO6VXue6yoM",
                                                        null,
                                                        "vFPvcC9XlKulXZVI0DmApWhc9wyMSxIaovYqtPpG",
                                                        null);
            Application.Run(new AdminForm());
        }
    }
}
