﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    public partial class InputTrackingCause : Form
    {
        ParseObject m_device;
        List<ParseObject> m_managers;

        class RequestUserItem
        {
            private readonly ParseObject m_user;

            public RequestUserItem(ParseObject user)
            {
                m_user = user;
            }

            public ParseObject manager { get { return m_user; } }

            public override string ToString()
            {
                return string.Format("{0}, {1}", m_user.GetString("phoneNumber").ToPhoneNumber(), m_user.GetString("nickname"));
            }
        };


        public InputTrackingCause(ParseObject device, List<ParseObject> managers)
        {
            m_device = device;
            m_managers = managers;
            InitializeComponent();
        }

        private void InputTrackingCause_Load(object sender, EventArgs e)
        {
            foreach (ParseObject manager in m_managers)
            {
                listRequestUser.Items.Add(new RequestUserItem(manager));
            }
            listRequestUser.Items.Add(new RequestUserItem(m_device));
            listRequestUser.SelectedIndex = 0;
            listReason.SelectedIndex = 0;
        }

        private async void btnOk_Click(object sender, EventArgs e)
        {
            ParseObject inquiry = new ParseObject("TrackingInquiry");
            inquiry.Add("deviceNumber", m_device.GetString("phoneNumber"));
            inquiry.Add("adminName", LoginInfo.username);
            inquiry.Add("adminIP", LoginInfo.ip);
            inquiry.Add("adminMac", LoginInfo.mac);
            inquiry.Add("requestUser", listRequestUser.Text);
            inquiry.Add("reason", listReason.Text);

            await RestAPI.createNew(inquiry, ServiceList.current.adminServer);

            TrackingList trackingList = new TrackingList(m_device, null, -100);
            trackingList.ShowDialog(this.Parent);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
