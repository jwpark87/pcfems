﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using RestSharp;
using Parse;
using System.Web.Script.Serialization;
using System.Globalization;

namespace JoonLib
{

    public class RestServer
    {
        public String name;
        public String appId;
        public String appKey;
        public String restKey;
        public String masterKey;
        public String session;

        public RestServer(String name, String appId, String appKey, String restKey, String masterKey)
        {
            this.name = name;
            this.appId = appId;
            this.appKey = appKey;
            this.restKey = restKey;
            this.masterKey = masterKey;
        }

        public RestServer(ParseObject pfObject)
        {
            this.name = pfObject.GetString("name");
            this.appId = pfObject.GetString("appId");
            this.appKey = null;
            this.restKey = pfObject.GetString("apiKey");
            this.masterKey = null;
        }
    }


    public class RestQuery
    {
        Dictionary<string, object> _equalTo = new Dictionary<string, object>();
        List<string> _orderTo = new List<string>();
        List<string> _includeKeys = new List<string>();
        string _className;
        int _limit = -1;

        public RestQuery(string className)
        {
            _className = className;
        }

        public RestQuery()
        {

        }


        public string className()
        {
            return _className;
        }

        public void orderTo(string order)
        {
            _orderTo.Add(order);
        }

        public void includeKey(string key)
        {
            _includeKeys.Add(key);
        }

        public void equalTo(string key, object value)
        {
            _equalTo.Add(key, value);
        }

        public void notEqualTo(string key, object value)
        {
            addWhereConstrains(key, "$ne", value);
        }

        public void notExists(string key)
        {
            addWhereConstrains(key, "$exists", false);
        }

        public void containedIn(string key, object value)
        {
            addWhereConstrains(key, "$in", value);
        }

        public void addWhereConstrains(string key, string constrain, object value)
        {
            Dictionary<string, object> constrains;

            try
            {
                constrains = (Dictionary<string, object>)_equalTo[key];
            }
            catch (Exception exp)
            {
                constrains = new Dictionary<string, object>();
                _equalTo[key] = constrains;
            }
            constrains.Add(constrain, value);
        }

        public void greatherThen(string key, object value)
        {
            addWhereConstrains(key, "$gt", value);
        }

        public void lessThen(string key, object value)
        {
            addWhereConstrains(key, "$lt", value);
        }


        public void limit(int count)
        {
            _limit = count;
        }

        public void relation(string key, object value)
        {
            _equalTo.Add("$relatedTo",
                new Dictionary<string, object>()
                {
                    { "object", value },
                    { "key", key },
                });
        }

        public static string valueToString(object value)
        {
            string strValue = "";
            if (value.GetType() == typeof(string))
            {
                strValue = string.Format("\"{0}\"", value);
            }
            else if (value.GetType() == typeof(DateTime))
            {
                strValue = string.Format("{{\"__type\":\"Date\", \"iso\":\"{0}\"}}", ((DateTime)value).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"));
            }
            else if (value.GetType() == typeof(ParseACL))
            {

            }
            else if (value.GetType() == typeof(ParseObject) ||
                     value.GetType() == typeof(Parse.ParseUser) ||
                     value.GetType() == typeof(JoonLib.JoonParseObject))
            {
                strValue = string.Format("{{\"__type\":\"Pointer\", \"className\":\"{0}\", \"objectId\":\"{1}\"}}", ((ParseObject)value).ClassName, ((ParseObject)value).ObjectId);
            }
            else if (value.GetType() == typeof(bool) || value.GetType() == typeof(Boolean))
            {
                strValue = ((bool)value) ? "true" : "false";
            }
            else if (value.GetType() == typeof(Dictionary<string, object>))
            {
                strValue = dictionaryToString((Dictionary<string, object>)value);
            }
            else if (value.GetType().IsArray)
            {
                strValue = arrayToString((Array)value);
            }
            else
            {
                strValue = value.ToString();
            }
            return strValue;
        }

        static string dictionaryToString(Dictionary<string, object> dic)
        {
            string statement = "{";
            int count = 0;
            foreach (KeyValuePair<string, object> value in dic)
            {
                if (count > 0)
                {
                    statement = statement + ",";
                }
                statement = statement + string.Format("\"{0}\":{1}", value.Key, valueToString(value.Value));
                ++count;
            }
            statement = statement + "}";
            return statement;
        }


        static string arrayToString(Array values)
        {
            string statement = "[";
            int count = 0;
            foreach (object value in values)
            {
                if (count > 0)
                {
                    statement = statement + ",";
                }
                statement = statement + valueToString(value);
                ++count;
            }
            statement = statement + "]";
            return statement;
        }


        public string getWhereStatement()
        {
            return dictionaryToString(_equalTo);
        }

        string getOrderStatement()
        {
            string statement = "";
            int count = 0;
            foreach (string orderObj in _orderTo)
            {
                if (count > 0)
                {
                    statement = statement + ",";
                }
                statement = statement + string.Format("{0}", orderObj);
                ++count;
            }
            return statement;
        }

        string getIncludeKeyStatement()
        {
            string statement = "";
            int count = 0;
            foreach (string orderObj in _includeKeys)
            {
                if (count > 0)
                {
                    statement = statement + ",";
                }
                statement = statement + string.Format("{0}", orderObj);
                ++count;
            }
            return statement;
        }

        public static implicit operator Dictionary<string, object>(RestQuery query)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (query._equalTo.Count > 0)
                parameters.Add("where", query.getWhereStatement());
            if (query._orderTo.Count > 0)
                parameters.Add("order", query.getOrderStatement());
            if (query._includeKeys.Count > 0)
                parameters.Add("include", query.getIncludeKeyStatement());
            if (query._limit > 0)
                parameters.Add("limit", query._limit);
            return parameters;
        }
    }



    public class RestAPI
    {
        static string _sessionToken = null;

        static RestServer getServer(RestServer server)
        {
            if (server == null)
                return ServiceList.current;
            return server;
        }

        static void setServerHeader(RestRequest request, RestServer server, bool useMasterKey)
        {
            request.AddHeader("X-Parse-Application-Id", server.appId);
            if (useMasterKey && server.masterKey != null)
                request.AddHeader("X-Parse-Master-Key", server.masterKey);
            else
                request.AddHeader("X-Parse-REST-API-Key", server.restKey);
        }


        public static Task<string> login(string txtId, string txtPassword, RestServer server = null)
        {
            server = getServer(server);

            Task<string> task = new Task<string>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest("1/login", Method.GET);
                setServerHeader(request, server, false);
                request.AddParameter("username", txtId);
                request.AddParameter("password", txtPassword);

                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string
                Dictionary<object, object> temp = JsonDeserializer.parse(content);
                _sessionToken = (string)temp["sessionToken"];
                server.session = _sessionToken;
                return _sessionToken;
            });
            task.Start();
            return task;
        }


        public static Task<ParseObject> signUp(string username, string password, RestServer server = null)
        {
            server = getServer(server);

            Task<ParseObject> task = new Task<ParseObject>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest("1/users", Method.POST);
                setServerHeader(request, server, false);
                request.AddParameter("username", username);
                request.AddParameter("password", password);

                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string
                Dictionary<object, object> temp = JsonDeserializer.parse(content);

                ParseObject userObject = ParseObject.CreateWithoutData("_User", (string)temp["objectId"]);
                userObject.Add("sessionToken", (string)temp["sessionToken"]);
                _sessionToken = (string)temp["sessionToken"];
                server.session = _sessionToken;
                return userObject;
            });
            task.Start();
            return task;
        }


        public static Task<Dictionary<object, object>> getWithUrl(string url, string action)
        {
            Task<Dictionary<object, object>> task = new Task<Dictionary<object, object>>(() =>
            {
                var client = new RestClient(url);
                var request = new RestRequest(action, Method.GET);
                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string
                Dictionary<object, object> temp = JsonDeserializer.parse(content);
                return temp;
            });

            task.Start();
            return task;
        }


        public static Task<List<ParseObject>> get(RestQuery query, bool useMasterKey = true, RestServer server = null)
        {
            return get(query.className(), query, true, useMasterKey, server);
        }

        public static Task<List<ParseObject>> get(string className, Dictionary<string, object> parameters, bool withData = true, bool useMasterKey = true, RestServer server = null)
        {
            server = getServer(server);

            Task<List<ParseObject>> task = new Task<List<ParseObject>>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest(string.Format("1/classes/{0}", className), Method.GET);
                setServerHeader(request, server, useMasterKey);

                if (parameters != null)
                {
                    foreach (KeyValuePair<string, object> parameter in parameters)
                    {
                        request.AddParameter(parameter.Key, parameter.Value, ParameterType.QueryString);
                    }
                }

                Console.WriteLine(DateTime.Now + "[RestAPI] Begin download. " + className + ", " + request.GetHashCode());
                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string
                if (content != null && content.Length > 0)
                {
                    Dictionary<object, object> temp = JsonDeserializer.parse(content);
                    if (temp != null && temp.ContainsKey("results"))
                    {
                        Array results = (Array)temp["results"];
                        List<ParseObject> parseObjects = new List<ParseObject>();
                        foreach (var device in results)
                        {
                            parseObjects.Add(jsonObjectToParseObject(className, (Dictionary<string, object>)device, withData));
                        }
                        Console.WriteLine(DateTime.Now + "[RestAPI] End download. " + className + ", " + request.GetHashCode());
                        return parseObjects;
                    }
                }
                return new List<ParseObject>();
            });

            task.Start();
            return task;
        }


        public static Task<int> count(RestQuery query, bool useMasterKey = true, RestServer server = null)
        {
            return count(query.className(), query, true, useMasterKey, server);
        }

        public static Task<int> count(string className, Dictionary<string, object> parameters, bool withData = true, bool useMasterKey = true, RestServer server = null)
        {
            server = getServer(server);

            Task<int> task = new Task<int>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest(string.Format("1/classes/{0}", className), Method.GET);
                setServerHeader(request, server, useMasterKey);

                if (parameters != null)
                {
                    foreach (KeyValuePair<string, object> parameter in parameters)
                    {
                        request.AddParameter(parameter.Key, parameter.Value, ParameterType.QueryString);
                    }
                }
                request.AddParameter("limit", 0, ParameterType.QueryString);
                request.AddParameter("count", 1, ParameterType.QueryString);

                Console.WriteLine(DateTime.Now + "[RestAPI] Begin download. " + className + ", " + request.GetHashCode());
                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string
                if (content != null && content.Length > 0)
                {
                    Dictionary<object, object> temp = JsonDeserializer.parse(content);
                    if (temp != null && temp.ContainsKey("count"))
                    {
                        long count = (long)temp["count"];
                        return (int)count;
                    }
                }
                return 0;
            });

            task.Start();
            return task;
        }


        public static Task<ParseObject> createNew(ParseObject pfObject, RestServer server = null)
        {
            server = getServer(server);

            Task<ParseObject> task = new Task<ParseObject>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest(string.Format("1/classes/{0}", pfObject.ClassName), Method.POST);
                setServerHeader(request, server, true);
                request.AddHeader("Content-Type", "application/json");
                request.RequestFormat = DataFormat.Json;
                string json = "";

                foreach (KeyValuePair<string, object> keyValue in pfObject)
                {
                    if (json.Length > 0)
                        json += ", ";
                    json += string.Format("\"{0}\":{1}", keyValue.Key, RestQuery.valueToString(keyValue.Value));
               }

                json = string.Format("{{{0}}}", json);
                request.AddParameter("text/json", json, ParameterType.RequestBody);
                
                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string

                Dictionary<object, object> temp = JsonDeserializer.parse(content);
                if (temp.ContainsKey("objectId"))
                {
                    pfObject.ObjectId = (string)temp["objectId"];
                    pfObject["createdAt"] = pfObject["updatedAt"] = temp["createdAt"].ToDateTime();
                }
                else
                {
                    throw new Exception(content);
                }

                return pfObject;
            });

            task.Start();
            return task;
        }



        public static Task<ParseObject> update(ParseObject pfObject, IEnumerable<KeyValuePair<string, object>> updateFields = null, RestServer server = null)
        {
            server = getServer(server);
            Task<ParseObject> task = new Task<ParseObject>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                string className = pfObject.ClassName;
                if (className == "_Installation")
                    className = "installations";
                else
                    className = "classes/" + className;

                var request = new RestRequest(string.Format("1/{0}/{1}", className, pfObject.ObjectId), Method.PUT);
                setServerHeader(request, server, true);
                request.AddHeader("Content-Type", "application/json");
                request.RequestFormat = DataFormat.Json;
                string json = "";

                if (updateFields == null)
                    updateFields = pfObject;
                foreach (KeyValuePair<string, object> keyValue in updateFields)
                {
                    if (updateFields != null || pfObject.IsKeyDirty(keyValue.Key))
                    {
                        if (json.Length > 0)
                            json += ", ";
                        json += string.Format("\"{0}\":{1}", keyValue.Key, RestQuery.valueToString(keyValue.Value));
                        // request.AddParameter(keyValue.Key, keyValue.Value);
                    }
                }

                json = string.Format("{{{0}}}", json);
                //request.AddBody(json);
                request.AddParameter("application/json", json, ParameterType.RequestBody);

                
                RestResponse response = (RestResponse)client.Execute(request);
                var content = response.Content; // raw content as string

                Dictionary<object, object> temp = JsonDeserializer.parse(content);
                if (temp.ContainsKey("updatedAt"))
                {
                    pfObject["updatedAt"] = temp["updatedAt"].ToDateTime();
                }
                else
                {
                    throw new Exception(content);
                }

                return pfObject;
            });

            task.Start();
            return task;
        }

        public static bool IsNumeric(object expression)
        {
            if (expression == null)
                return false;

            double number;
            return Double.TryParse(Convert.ToString(expression, CultureInfo.InvariantCulture), System.Globalization.NumberStyles.Any, NumberFormatInfo.InvariantInfo, out number);
        }

        public static Task<string> callFunctions(string functionName, Dictionary<string, object> parameters, RestServer server = null)
        {
            server = getServer(server);
            Task<string> task = new Task<string>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest(string.Format("1/functions/{0}", functionName), Method.POST);
                setServerHeader(request, server, true);
                // request.AddHeader("X-Parse-Session-Token", _sessionToken);
                foreach (KeyValuePair<string, object> parameter in parameters)
                {
                    request.AddParameter(parameter.Key, parameter.Value.ToString());
                }

                RestResponse response = (RestResponse)client.Execute(request);
                string content = response.Content; // raw content as string
                return content;
            });

            task.Start();
            return task;
        }

        public static Task<string> deleteObject(ParseObject pfObject, RestServer server =  null)
        {
            return deleteObject(pfObject.ClassName, pfObject.ObjectId, server);
        }

        public static Task<string> deleteObject(string className, string objectId, RestServer server = null)
        {
            server = getServer(server);
            Task<string> task = new Task<string>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest(string.Format("1/classes/{0}/{1}", className, objectId), Method.DELETE);
                setServerHeader(request, server, true);
                RestResponse response = (RestResponse)client.Execute(request);
                string content = response.Content; // raw content as string
                return content;
            });

            task.Start();
            return task;
        }



        static ParseObject jsonObjectToParseObject(string className, Dictionary<string, object> json, bool withData = true) {

            JoonParseObject parse = new JoonParseObject(className, (string)json["objectId"]);
            if (!withData)
                return parse;

            foreach (KeyValuePair<string, object> value in json)
            {

                var parseValue = value.Value;

                if ((string)value.Key == "objectId" || (string)value.Key == "ACL" || (string)value.Key == "className")
                    continue;

                else if ((string)value.Key == "createdAt" || (string)value.Key == "updatedAt" )
                {
                    parseValue = parseValue.ToDateTime();
                }

                else if (parseValue != null && parseValue.GetType().IsGenericType && parseValue.GetType().GetGenericTypeDefinition() == typeof(Dictionary<,>))
                {
                    Dictionary<string, object> subValue = (Dictionary<string, object>)value.Value;
                    if (subValue.ContainsKey("__type") && subValue.ContainsKey("className"))
                    {
                        if ((string)subValue["__type"] == "Pointer" || (string)subValue["__type"] == "Object")
                        {
                            parseValue = jsonObjectToParseObject((string)subValue["className"], subValue);
                        }
                        else if ((string)subValue["__type"] == "Relation")
                        {
                            parse.GetRelation<ParseObject>((string)subValue["className"]);
                            parseValue = null;
                        }
                    }
                    else if (subValue.ContainsKey("__type"))
                    {
                        if (subValue["__type"].GetType() == typeof(string) && (string)subValue["__type"] == "Date")
                        {
                            parseValue = subValue["iso"];
                            if (parseValue.GetType() == typeof(string))
                                parseValue = DateTime.Parse((string)parseValue);
                        }
                    }
                }

                if (parseValue != null &&  Type.GetTypeCode(parseValue.GetType()) == TypeCode.Decimal )
                {
                    parseValue = Convert.ToDouble(parseValue);
                }

                if (parseValue != null)
                {
                    parse.AddValue((string)value.Key, parseValue);
                }
            }

            return parse;
        }



        public static Task<string> pushWithQuery(RestQuery query, Dictionary<string, object> pushData, RestServer server)
        {
            Task<string> task = new Task<string>(() =>
            {
                var client = new RestClient("https://api.parse.com");
                var request = new RestRequest(string.Format("1/push"), Method.POST);
                setServerHeader(request, server, true);
                request.AddHeader("Content-Type", "application/json");
                request.RequestFormat = DataFormat.Json;
                string json = string.Format("\"where\":{0}, \"data\":{1}", query.getWhereStatement(), RestQuery.valueToString(pushData));
                json = string.Format("{{{0}}}", json);
                request.AddParameter("text/json", json, ParameterType.RequestBody);

                RestResponse response = (RestResponse)client.Execute(request);
                string content = response.Content; // raw content as string
                return content;
            });

            task.Start();
            return task;
        }
    }
}
