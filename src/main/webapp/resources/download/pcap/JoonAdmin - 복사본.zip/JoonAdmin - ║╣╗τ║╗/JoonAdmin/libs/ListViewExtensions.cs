﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoonLib
{
    public static class ListViewExtensions
    {
        private static string objectToPropString(object value)
        {
            string strValue;
            if (value.GetType() == typeof(DateTime))
            {
                strValue = ((DateTime)value).ToLocalTime().ToString();
            }
            else
            {
                strValue = value.ToString();
            }
            return strValue;
        }


        static public ListViewItem AddProp(this ListView listView, params object [] value)
        {
            ListViewItem item = new ListViewItem(objectToPropString(value[0]));
            item.ImageIndex = 0;
            for (int i = 1; i < value.Length; ++i)
            {
                item.SubItems.Add(new ListViewItem.ListViewSubItem(item, objectToPropString(value[i])));
            }
            listView.Items.Add(item);
            return item;
        }
    }
}
