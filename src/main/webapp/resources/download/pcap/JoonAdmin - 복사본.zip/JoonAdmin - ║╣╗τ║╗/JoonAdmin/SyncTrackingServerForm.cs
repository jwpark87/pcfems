﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;

namespace JoonAdmin
{
    public partial class SyncTrackingServerForm : Form
    {
        public SyncTrackingServerForm()
        {
            InitializeComponent();
        }

        private void SyncTrackingServerForm_Load(object sender, EventArgs e)
        {

        }

        private void SyncTrackingServerForm_Shown(object sender, EventArgs e)
        {
            syncStart();
        }

        private void syncStart()
        {
            /*
            syncTrackingServer(
                new RestServer("Tracking1", "Noc7TmqWtKzlCG6EIvSXaVAgf3LObf4lXH1CNMhJ",
                                                         "uC5cxSYLc6hycqTi9oZUmTOQYcr7B83PDrt5EYDV",
                                                         "IxjoR4LILrT0z7OQaxWrkX1vquGzP2uORu3sXe8u",
                                                         "DPNkxuAc37sB5YJcPDqEBQW9LC7tMYj3bcMJzKyz"));
            */
            syncTrackingServer(
                new RestServer("Tracking2", "eaPhbAaUShixjOfSBSB0mJsCfK4mkqkoiZuCYHOY",
                                                         "9ivBfo3PqwHDAqmz6wMDwijFn3vLykCnP5AGLV9L",
                                                         "xMQBj9R1Axd3BiL0zu6n7sQ1zgrWl1Q09F5YrW99",
                                                         "LPD9n5XOdXbby8SedoACKkg4ry7X1wuaZQmDXx9Q"));
            
        }

        private async void syncTrackingServer(RestServer trackingServer)
        {
            DateTime lastDate = DateTime.Now;
            do {
                RestQuery query = new RestQuery("Device");
                query.notExists("managers");
                query.orderTo("-createdAt");
                if (lastDate != null)
                    query.lessThen("createdAt", lastDate);
                query.limit(1000);
                List<ParseObject> devices = await RestAPI.get(query, true, trackingServer);
                foreach (ParseObject device in devices)
                {
                    writeLog("device - " + device.GetString("device") + ", " + device.Get<DateTime>("createdAt"));
                    Dictionary<string, object> dic = new Dictionary<string, object>();
                    dic.Add("deviceId", device.GetString("device"));
                    var result = await RestAPI.callFunctions("syncToTrackingServer", dic);
                    writeLog("result - " + result);
                    lastDate = device.Get<DateTime>("createdAt");
                }
            } while (lastDate.CompareTo(new DateTime(2015, 10, 1)) > 0);
            writeLog("complete");
        }

        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }
    }
}
