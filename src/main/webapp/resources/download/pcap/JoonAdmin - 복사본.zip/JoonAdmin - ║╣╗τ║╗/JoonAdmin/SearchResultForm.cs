﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;

namespace JoonAdmin
{
    public partial class SearchResultForm : Form
    {
        AdminForm m_owner;

        public SearchResultForm(List<ParseObject> users, AdminForm owner)
        {
            InitializeComponent();
            m_owner = owner;
            addUsers(users);
        }

        void addUsers(List<ParseObject> users)
        {
            listSearch.BeginUpdate();
            foreach (JoonLib.JoonParseObject user in users)
            {
                listSearch.Items.Add(listViewItemWithUser(user));
            }
            listSearch.EndUpdate();
        }

        private ListViewItem listViewItemWithUser(JoonLib.JoonParseObject user)
        {
            ListViewItem lvi = new ListViewItem(user.Get<string>("phoneNumber"));
            lvi.SubItems.Add(user.Get<string>("type"));
            lvi.SubItems.Add( user.Get<DateTime>("createdAt").ToLocalTime().ToString() );
            lvi.Tag = user;
            return lvi;
        }

        private void listSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private async void listSearch_DoubleClick(object sender, EventArgs e)
        {
            if (listSearch.SelectedItems.Count == 0)
                return;

            try
            {
                this.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;

                JoonLib.JoonParseObject user = (JoonLib.JoonParseObject)listSearch.SelectedItems[0].Tag;
                if (user.Get<string>("type") == "manager")
                {
                    IEnumerable<ParseObject> devices = await user.GetRelation<ParseObject>("devices").Query.FindAsync();
                    if (devices.Count() == 1)
                    {
                        m_owner.loadDevice(user);
                        this.Close();
                    }
                    else
                    {
                        List<ParseObject> deviceUsers = new List<ParseObject>();
                        foreach (var device in devices)
                        {
                            IEnumerable<ParseUser> findResults = await ParseUser.Query.WhereEqualTo("device", device).FindAsync();
                            foreach (var deviceUser in findResults)
                                deviceUsers.Add(deviceUser);    
                        }
                        SearchResultForm childForm = new SearchResultForm(deviceUsers, m_owner);
                        childForm.MdiParent = m_owner;
                        childForm.Show();
                        this.Close();
                    }
                }
                else
                {
                    m_owner.loadDevice(user);
                    this.Close();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Enabled = true;
                Cursor.Current = Cursors.Default;
            }
        }
    }
}
