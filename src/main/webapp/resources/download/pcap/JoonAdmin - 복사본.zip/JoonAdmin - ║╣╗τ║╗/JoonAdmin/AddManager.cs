﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using System.Web.Script.Serialization;
using JoonLib;

namespace JoonAdmin
{
    public partial class AddManager : Form
    {
        ParseObject m_device;
        AdminForm m_caller;

        public AddManager(ParseObject device, AdminForm caller)
        {
            InitializeComponent();
            m_device = device;
            m_caller = caller;
        }


        int _validCarrierCheckRetryCount = 10;
        Timer _validCarrierCheckTimer = null;
        string _validCarrierCheckId = null;

        void timer_validCarrierCheck(object sender, System.EventArgs e)
        {
            validCarrierCheck();
        }

        private async void validCarrierCheck()
        {
            _validCarrierCheckTimer.Stop();
            textLog.AppendText("SKT 가입자 확인 응답을 기다리고 있습니다.\n");
            try
            {

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                string condition = string.Format("{{\"objectId\":\"{0}\"}}", _validCarrierCheckId);
                parameters.Add("where", condition);
                List<ParseObject> results = await RestAPI.get("CheckValidManager", parameters);

                ParseObject obj = results[0];
                int result = obj.Get<int>("result");
                if (result == 2)
                {
                    textLog.AppendText("SKT 가입자 확인을 완료했습니다.\n");
                    // await obj.DeleteAsync();
                    addManager();
                    return;
                }
                else if (result != 0)
                {
                    textLog.AppendText("SKT 가입자가 아닙니다.\n");
                    _validCarrierCheckRetryCount = 30;
                }

                ++_validCarrierCheckRetryCount;
                if (_validCarrierCheckRetryCount >= 30)
                {
                    await obj.DeleteAsync();
                    MessageBox.Show("관리자 등록을 더 이상 진행 할 수 없습니다. 통신사 및 번호 확인 후 다시 시도 해 주세요.", "가입자 확인 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Enabled = true;
                }
                else
                {
                    _validCarrierCheckTimer.Start();
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show("관리자 등록을 더 이상 진행 할 수 없습니다. " + exp.Message, "가입자 확인 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Enabled = true;
            }
        }


        private async void addManager()
        {
            try
            {
                textLog.AppendText("관리자로 추가합니다.\n");
                Dictionary<string, object> dic = new Dictionary<string, object>();
                dic.Add("phoneNumber", textPhoneNumber.Text);
                dic.Add("deviceId", m_device.ObjectId);
                dic.Add("checked", true);
                // var result = await ParseCloud.CallFunctionAsync<string>("addManager", dic);
                var result = await RestAPI.callFunctions("addManager", dic);
                textLog.AppendText("관리자 추가가 완료되었습니다.\n잠시만 기다려주세요.\n");
                m_caller.reloadManager();
                this.Close();
            }
            catch (Exception exp)
            {
                MessageBox.Show("등록에 실패했습니다." + exp.Message, "관리자 등록", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Enabled = true;
            }
        }


        private async void btnOk_Click(object sender, EventArgs e)
        {
            if (textPhoneNumber.Text.Length > 0)
            {
                if (checkSKT.Checked)
                {
                    try
                    {
                        textLog.AppendText("SKT 가입자 확인 메시지를 보냅니다.\n");
                        this.Enabled = false;
                        Dictionary<string, object> dic = new Dictionary<string, object>();
                        dic.Add("managerPhoneNumber", textPhoneNumber.Text);
                        dic.Add("devicePhoneNumber", m_device.Get<string>("phoneNumber"));

                        var result = await RestAPI.callFunctions("isValidManagerNumberAsync", dic);
                        // var result = await ParseCloud.CallFunctionAsync<string>("isValidManagerNumberAsync", dic);

                        var jss = new JavaScriptSerializer();
                        Dictionary<string, string> dicResult = jss.Deserialize<Dictionary<string, string>>(result);
                        if (dicResult.ContainsKey("error"))
                        {
                            MessageBox.Show("가입확인 요청을 하지 못했습니다. Error: " + dicResult["error"], "가입자 확인 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            this.Enabled = true;
                            return;
                        }

                        if (dicResult.ContainsKey("result")) {
                            dicResult = jss.Deserialize<Dictionary<string, string>>(dicResult["result"]);
                        }

                        _validCarrierCheckRetryCount = 0;
                        _validCarrierCheckId = dicResult["id"];
                        _validCarrierCheckTimer = new Timer();
                        _validCarrierCheckTimer.Interval = 2 * 1000;
                        _validCarrierCheckTimer.Tick += new EventHandler(timer_validCarrierCheck);
                        validCarrierCheck();
                    }
                    catch (Exception exp)
                    {
                        MessageBox.Show("가입확인 요청을 하지 못했습니다. 네트워크 상태를 확인 해 주세요. " + exp.Message, "가입자 확인 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.Enabled = true;
                    }
                }
                else
                {
                    this.Enabled = false;
                    addManager();
                }
            }
            else
            {
                MessageBox.Show("번호를 넣으세요.");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
