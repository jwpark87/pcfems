﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using JoonLib;

namespace JoonAdmin
{

    public partial class DeviceAddress : Form
    {

        class GeoPoint
        {
            public double longtitude;
            public double latitude;

            public GeoPoint(double lat, double lng)
            {
                latitude = lat;
                longtitude = lng;
            }

            public GeoPoint(string value)
            {
                char[] token = { ',' };
                string[] values = value.Split(token);
                latitude = Double.Parse(values[0]);
                longtitude = Double.Parse(values[1]);
            }


            const double PI = 3.14159265358979323846;
            double deg2rad(double deg)
            {
                return (deg * PI / 180);
            }

            double rad2deg(double rad)
            {
                return (rad * 180 / PI);
            }


            public double distanceFrom(GeoPoint other)
            {
                double theta, dist;
                theta = longtitude - other.longtitude;
                dist = Math.Sin(deg2rad(latitude)) * Math.Sin(deg2rad(other.latitude)) + Math.Cos(deg2rad(latitude)) * Math.Cos(deg2rad(other.latitude)) * Math.Cos(deg2rad(theta));
                dist = Math.Acos(dist);
                dist = rad2deg(dist);
                dist = dist * 60 * 1.1515;
                dist = dist * 1.609344;
                return dist;
            }
        };


        string m_userId;
        ParseObject m_device;
        List<ParseObject> m_addressObjects;
        ParseObject m_userAddress;
        string m_encKey;

        public const int kAddressPlaceType_Home = 10;
        public const int kAddressPlaceType_HomeApply = 110;
        public const int kAddressPlaceType_School = 20;
        public const int kAddressPlaceType_SchoolApply = 120;
        public const int kAddressPlaceType_Institute = 30;
        public const int kAddressPlaceType_InstituteApply = 130;
        public const int kAddressPlaceType_Etc = 90;
        public const int kAddressPlaceType_EtcApply = 190;
        public const int kAddreerssApplyFlag = 100;

        public DeviceAddress(ParseObject device, string userId)
        {
            m_userId = userId;
            m_device = device;
            m_encKey = m_device.ObjectId.Substring(0, 8);
            m_encKey = m_encKey + m_encKey + m_encKey + m_encKey;
            InitializeComponent();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadAddress();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (m_userAddress == null)
            {
                int placeType = 0;
                switch (listCategory.SelectedIndex)
                {
                    case 0:
                        placeType = kAddressPlaceType_Home;
                        break;

                    case 1:
                        placeType = kAddressPlaceType_School;
                        break;

                    case 2:
                        placeType = kAddressPlaceType_Institute;
                        break;
                }

                m_userAddress = ParseObject.Create("JooNAddress2");
                m_userAddress.Add("device", ParseObject.CreateWithoutData("Device", m_device.ObjectId));
                m_userAddress.Add("visible", true);
                m_userAddress.Add("processType", -1);
                m_userAddress.Add("placeType", placeType);
                m_userAddress.Add("address", "");
                m_userAddress.Add("geoPointString", "");
                m_userAddress.Add("user", ParseObject.CreateWithoutData("_User", m_userId));
            }

            GeoPoint userPos = new GeoPoint(0, 0);
            if (textUserAddress.Text.Length > 0)
            {
                userPos = new GeoPoint((new AES256Cipher()).AES_decrypt(m_userAddress.Get<string>("geoPointString"), m_encKey));
            }
            MapSelectView mapView = new MapSelectView(textUserAddress.Text, userPos.latitude, userPos.longtitude, new MapSelectView.didAddressSelected(didAddressSelected));
            mapView.ShowDialog(this);
        }

        async void didAddressSelected(string address, double lat, double lng)
        {
            this.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                textUserAddress.Text = address;
                m_userAddress["geoPointString"] = (new AES256Cipher()).AES_encrypt(string.Format("{0},{1}", lat, lng), m_encKey);
                m_userAddress["address"] = (new AES256Cipher()).AES_encrypt(address, m_encKey);
                if (m_userAddress.ObjectId == null || m_userAddress.ObjectId.Length == 0)
                {
                    // await m_userAddress.SaveAsync();
                    await RestAPI.createNew(m_userAddress);
                    m_addressObjects.Add(m_userAddress);
                }
                else
                {
                    await RestAPI.update(m_userAddress, m_userAddress.Where(n => n.Key.StartsWith("geoPointString") || n.Key.StartsWith("address")));
                    /*
                    ParseObject newUserAddress = ParseObject.Create(m_userAddress.ClassName);
                    foreach (KeyValuePair<string, object> keyValue in m_userAddress)
                    {
                        newUserAddress[keyValue.Key] = m_userAddress[keyValue.Key];
                    }
                    // await m_userAddress.DeleteAsync();
                    await RestAPI.deleteObject(m_userAddress.ClassName, m_userAddress.ObjectId);
                    m_addressObjects.Remove(m_userAddress);
                    m_userAddress = newUserAddress;
                    await m_userAddress.SaveAsync();
                    m_addressObjects.Add(m_userAddress);
                     */
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Enabled = true;
            Cursor.Current = Cursors.Default;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            TrackingList trackingListForm = new TrackingList(m_device, new TrackingList.didTrackingSelected(didTrackingSelected));
            trackingListForm.Show(this);
        }

        

        async void didTrackingSelected(List<ParseObject> trackings)
        {
            this.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;

            try
            {

                GeoPoint userPos = new GeoPoint((new AES256Cipher()).AES_decrypt(m_userAddress.Get<string>("geoPointString"), m_encKey));
                int placeType = 0;
                switch (listCategory.SelectedIndex)
                {
                    case 0:
                        placeType = kAddressPlaceType_HomeApply;
                        break;

                    case 1:
                        placeType = kAddressPlaceType_SchoolApply;
                        break;

                    case 2:
                        placeType = kAddressPlaceType_InstituteApply;
                        break;
                }

                foreach (ParseObject tracking in trackings)
                {
                    ParseObject addressObject = ParseObject.Create("JooNAddress2");
                    addressObject.Add("device", ParseObject.CreateWithoutData("Device", m_device.ObjectId));
                    addressObject.Add("visible", true);
                    addressObject.Add("processType", 0);
                    addressObject.Add("placeType", placeType);
                    addressObject.Add("gpsType", tracking.Get<int>("gpsType"));
                    addressObject.Add("positionTime", tracking.Get<DateTime>("createdAt").ToUniversalTime());
                    addressObject.Add("address", m_userAddress.Get<string>("address"));
                    addressObject.Add("geoPointString", m_userAddress.Get<string>("geoPointString"));
                    addressObject.Add("user", ParseObject.CreateWithoutData("_User", m_userId));
                    addressObject.Add("orgGeoPointString", tracking.Get<string>("geoPoint"));

                    GeoPoint trackingPos = new GeoPoint((new AES256Cipher()).AES_decrypt(tracking.Get<string>("geoPoint"), "ppxr2Uh4qzkfaFzjfFEHsB1uggZWrBVq"));
                    addressObject.Add("errorKm", userPos.distanceFrom(trackingPos));
                    // await addressObject.SaveAsync();
                    await RestAPI.createNew(addressObject);
                    m_addressObjects.Add(addressObject);
                }

                listCategory_SelectedIndexChanged(null, null);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (listInvalidAddress.SelectedItems.Count == 0)
                return;

            this.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                foreach (ListViewItem i in listInvalidAddress.SelectedItems)
                {
                    ParseObject addressObject = (ParseObject)i.Tag;
                    if (addressObject.Get<int>("processType") == 0 || addressObject.Get<int>("processType") == -1)
                    {
                        await RestAPI.deleteObject("JooNAddress2", addressObject.ObjectId);
                        // await addressObject.DeleteAsync();
                        listInvalidAddress.Items.Remove(i);
                        m_addressObjects.Remove(addressObject);
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            this.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        private void listCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            unselectAll();
            if (m_addressObjects == null)
                return;

            int placeType = getPlaceTypeWithCategoryIndex(listCategory.SelectedIndex);
            textUserAddress.Text = "";
            listInvalidAddress.Items.Clear();
            m_userAddress = null;

            foreach (ParseObject addressObject in m_addressObjects)
            {
                int addressPlaceType = addressObject.Get<int>("placeType");
                if (addressPlaceType == placeType)
                {
                    m_userAddress = addressObject;
                    string userAddress = addressObject.Get<string>("address");
                    if (userAddress != null && userAddress.Length > 0) {
                        textUserAddress.Text = (new AES256Cipher()).AES_decrypt(userAddress, m_encKey);
                    }
                }
                else if (addressPlaceType == placeType + kAddreerssApplyFlag)
                {
                    string wifiAddress = addressObject.Get<string>("address");
                    if (wifiAddress != null && wifiAddress.Length > 0)
                    {
                        string posTime = addressObject.Get<DateTime>("positionTime").ToLocalTime().ToString();
                        string address = (new AES256Cipher()).AES_decrypt(wifiAddress, m_encKey);
                        double errorKm = addressObject.Get<double>("errorKm");
                        string processType = "접수대기";
                        switch (addressObject.Get<int>("processType"))
                        {
                            case 0: processType = "접수중";
                                break;
                            case 1: processType = "처리중";
                                break;
                            case 2: processType = "완료";
                                break;
                            case 3: processType = "처리불가 " + addressObject.Get<string>("processReason");
                                break;
                        }

                        ListViewItem item = new ListViewItem(posTime);
                        item.SubItems.Add(string.Format("{0:0,0.00}km", errorKm));
                        item.SubItems.Add(processType);
                        item.Tag = addressObject;
                        listInvalidAddress.Items.Add(item);
                    }
                }
                // m_userId = addressObject.Get<ParseObject>("user").ObjectId;
            }
        }

        int getPlaceTypeWithCategoryIndex(int categoryIndex)
        {
            switch (categoryIndex)
            {
                case 0:
                    return kAddressPlaceType_Home;
                case 1:
                    return kAddressPlaceType_School;
                case 2:
                    return kAddressPlaceType_Institute;
            }
            return kAddressPlaceType_Etc;
        }

        private async void loadAddress()
        {
            this.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;


            Dictionary<string, object> parameters = new Dictionary<string, object>();
            var deviceSearchField = string.Format("{{\"__type\":\"Pointer\",\"className\":\"Device\",\"objectId\":\"{0}\"}}", m_device.ObjectId);
            parameters.Add("where", string.Format("{{\"device\":{0}}}", deviceSearchField));
            m_addressObjects = await RestAPI.get("JooNAddress2", parameters);
            listCategory_SelectedIndexChanged(null, null);
            this.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        private void DeviceAddress_Shown(object sender, EventArgs e)
        {
            listCategory.SelectedIndex = 0;
            loadAddress();
        }

        private void listInvalidAddress_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDelete.Enabled = false;
            foreach (ListViewItem i in listInvalidAddress.SelectedItems)
            {
                ParseObject addressObject = (ParseObject)i.Tag;
                if (addressObject.Get<int>("processType") == 0 || addressObject.Get<int>("processType") == -1)
                {
                    btnDelete.Enabled = true;
                    break;
                }
            }
        }

        void unselectAll()
        {
            foreach (ListViewItem i in listInvalidAddress.SelectedItems)
            {
                i.Selected = false;
            }
            btnDelete.Enabled = false;
        }

        private void btnMemo_Click(object sender, EventArgs e)
        {
            DeviceAddressRequestUserForm child = new DeviceAddressRequestUserForm(m_device);
            child.ShowDialog(this);
        }
    }
}
