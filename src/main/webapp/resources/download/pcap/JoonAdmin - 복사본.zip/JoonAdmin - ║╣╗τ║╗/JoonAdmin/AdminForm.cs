﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;
using Parse;

namespace JoonAdmin
{
    public partial class AdminForm : Form
    {
        ParseObject _deviceUser;
        Dictionary<string, Array> _dataViews = new Dictionary<string, Array>();
        UserVoiceHistoryView _uvHistoryView;
        ParseObject _uvHistory;
        ParseObject _uvLog;
        public AdminForm()
        {
            InitializeComponent();
            Properties.Settings.Default.Upgrade();
            initDataView();
            tabCategory.Enabled = false;
            txtNewLog.Enabled = false;
            btnAddLog.Enabled = false;
            txtPhoneNumber.Focus();
            updateAdminLevelMenu();

#if FEATURE_TCARE_ADMINONLY
            mainMenu.Hide();
            tabCategory.TabPages.Remove(tabTalk);
            tabCategory.TabPages.Remove(tabSafezone);
            tabCategory.TabPages.Remove(tabTracking);
            tabCategory.TabPages.Remove(tabToy);
            tabCategory.TabPages.Remove(tabChangeHistory);
            tabCategory.TabPages.Remove(tabRemoteControl);
            tableLayoutMain.ColumnStyles[0].Width = 0;
            tableLayoutData.RowStyles[1].Height = 0;
            btnAddress.Hide();
#endif
        }

        public void initDataView()
        {
            _dataViews.Add("tabDevice", new DataView [] { new DeviceDataView().initWithDataView(propDevice) });
            _dataViews.Add("tabManager", new DataView [] { new ManagerDataView().initWithDataView(listManager) });
            _dataViews.Add("tabContact", new DataView [] { new ContactDataView().initWithDataView(listContact) });
            _dataViews.Add("tabTalk", new DataView [] { new RecvTalkDataView().initWithDataView(listRecvTalk),
                                                         new SendTalkDataView().initWithDataView(listSendTalk) });
            _dataViews.Add("tabSafezone", new DataView [] { new SafeZoneDataView().initWithDataView(listSafezone) });
            _dataViews.Add("tabTracking", new DataView [] { new TrackingDataView().initWithDataView(listTracking) });
            _dataViews.Add("tabToy", new DataView[] { new ToyDataView().initWithDataView(listToy) });
            _dataViews.Add("tabChangeHistory", new DataView[] { new DeviceHistoryView().initWithDataView(listDeviceHistory) });

            _uvHistoryView = (UserVoiceHistoryView)new UserVoiceHistoryView().initWithDataView(listUserVoice);
        }

        void updateAdminLevelMenu()
        {
            if (LoginInfo.user.GetString("level") == "admin")
            {
                exportToolStripMenuItem.Enabled = true;
                manageToolStripMenuItem.Enabled = true;
                btnBackupLog.Show();
            }
            else
            {
                exportToolStripMenuItem.Enabled = false;
                manageToolStripMenuItem.Enabled = false;
                btnBackupLog.Hide();
            }
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            string phoneNumber = txtPhoneNumber.Text;
            phoneNumber = phoneNumber.Replace(" ", "");
            phoneNumber = phoneNumber.Replace("-", "");
            loadDeviceFromPhoneNumber(phoneNumber);
        }


        public async void loadDeviceFromPhoneNumber(string phoneNumber)
        {
            try
            {
                ActivityIndicator.show(phoneNumber.ToPhoneNumber() + "를 검색 중입니다.");

                RestQuery query = new RestQuery("_User");
                query.equalTo("phoneNumber", phoneNumber);
                query.equalTo("type", "device");
                query.includeKey("device");
                List<ParseObject> devices = await RestAPI.get(query);

                switch (devices.Count)
                {
                    case 0:
                        MessageBox.Show("해당 단말을 찾을 수 없습니다. 번호를 다시 확인하세요.");
                        break;

                    case 1:
                        loadDevice(devices[0]);
                        break;

                    default:
                        {
                            SearchResultForm child = new SearchResultForm(devices, this);
                            child.ShowDialog(this);
                        }
                        break;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "검색 도중 오류가 발생하였습니다.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ActivityIndicator.hide();
            }
        }


        public async void loadDevice(ParseObject deviceUser, ParseObject uvHistory = null)
        {
            ParseObject device = deviceUser.GetObject("device");
            if (uvHistory == null) { 
                uvHistory = new ParseObject("UVHistory");
                uvHistory["searchNumber"] = deviceUser.GetString("phoneNumber");
                if (device != null)
                    uvHistory["device"] = device;
                uvHistory.Increment("count");
                _uvHistory = await RestAPI.createNew(uvHistory, ServiceList.current.adminServer);
            }
            else
            {
                _uvHistory = uvHistory;
                _uvHistory.Increment("count");
                await RestAPI.update(_uvHistory, new Dictionary<string, object> { { "count", _uvHistory.GetInt("count") } }.ToList(), ServiceList.current.adminServer);
            }
            
            _uvHistoryView.reload(null, this);

            ParseObject uvLog = new ParseObject("UVLog");
            uvLog["admin"] = LoginInfo.user;
            uvLog["mac"] = LoginInfo.mac;
            uvLog["ip"] = LoginInfo.ip;
            uvLog["history"] = uvHistory;
            _uvLog = await RestAPI.createNew(uvLog, ServiceList.current.adminServer);

            tabCategory.Enabled = true;
            txtNewLog.Enabled = true;
            btnAddLog.Enabled = true;

            txtNewLog.Text = "";
            txtOldLog.Text = "";

            RestQuery query = new RestQuery("UVComment");
            query.equalTo("history", _uvHistory);
            query.orderTo("-createdAt");
            List<ParseObject> comments = await RestAPI.get(query, true, ServiceList.current.adminServer);
            foreach(ParseObject comment in comments)
            {
                addLog(comment);
            }

            foreach(KeyValuePair<string, Array> dataViews in _dataViews) 
            {
                foreach (DataView subDataView in dataViews.Value)
                {
                    subDataView.clear();
                }
            }
            _deviceUser = deviceUser;
            if (tabCategory.SelectedIndex != 0)
                tabCategory.SelectedIndex = 0;
            else
                ((DataView)getDataViews("tabDevice").GetValue(0)).viewDidAppear(_deviceUser, this);
        }


        private Array getDataViews(string tabName)
        {
            if ( _dataViews.ContainsKey(tabName) )
            {
                return _dataViews[tabName];
            }
            return new DataView[] {};
        }

        private void tabCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_deviceUser == null)
                return;

            foreach (DataView subDataView in getDataViews(tabCategory.SelectedTab.Name))
            {
                subDataView.viewDidAppear(_deviceUser, this);
            }
        }


        private void btnAddManager_Click(object sender, EventArgs e)
        {
            AddManager childForm = new AddManager(_deviceUser.Get<ParseObject>("device"), this);
            childForm.ShowDialog(this);
        }

        private async void btnDelManager_Click(object sender, EventArgs e)
        {
            if (listManager.CheckedItems.Count == 0)
                return;

            this.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                foreach (ListViewItem lvi in listManager.CheckedItems)
                {
                    ParseObject manager = (ParseObject)lvi.Tag;
                    Dictionary<string, object> dic = new Dictionary<string, object>();
                    dic.Add("managerId", manager.ObjectId);
                    var result = await RestAPI.callFunctions("removeManager", dic);
                    listManager.Items.Remove(lvi);
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "삭제에 실패하였습니다.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Enabled = true;
                Cursor.Current = Cursors.Default;
            }
        }

        public void reloadManager()
        {
            foreach(DataView dataView in getDataViews("tabManager"))
            {
                dataView.reload(_deviceUser, this);
            }
        }

        private async void btnReset_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("단말에 리셋 메시지를 보냅니다. 사용자 단말에 리셋 메시지가 표시되고 자동 리셋 됩니다.", "단말 리셋", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                try
                {
                    Dictionary<string, object> dic = new Dictionary<string, object>();
                    dic.Add("action", "reset");
                    dic.Add("phoneNumber", _deviceUser.GetString("phoneNumber"));
                    await RestAPI.callFunctions("adminFunc", dic);
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    this.Enabled = true;
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            foreach (DataView dataView in getDataViews(tabCategory.SelectedTab.Name))
            {
                dataView.reload(_deviceUser, this);
            }
        }

        private void btnAddress_Click_1(object sender, EventArgs e)
        {
            if (listManager.Items.Count == 0)
            {
                MessageBox.Show("한명이상의 등록된 관리자가 필요합니다.");
                return;
            }

            ParseObject manager = (ParseObject)listManager.Items[0].Tag;
            DeviceAddress addressForm = new DeviceAddress(_deviceUser.Get<ParseObject>("device"), manager.ObjectId);
            addressForm.ShowDialog(this);
        }

        private void AdminForm_Shown(object sender, EventArgs e)
        {
            Login login = new Login();
            login.loginEventHandlers = new Login.didLogin(this.didLogin);
            login.ShowDialog();
        }

        private void txtPhoneNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                btnSearch_Click(null, null);
            }
        }

        private void listToy_MouseDoubleClick(object sender, MouseEventArgs e)
        {
        }

        private void didLogin()
        {
            _uvHistoryView.reload(null, this);
            updateAdminLevelMenu();
        }

        private void menuCopy_Click(object sender, EventArgs e)
        {
            bool isSelectOnly = false;
            foreach (DataView dataView in _dataViews[tabCategory.SelectedTab.Name])
            {
                ListView listView = dataView.getListView();
                if (listView.SelectedItems.Count > 0)
                {
                    isSelectOnly = true;
                    break;
                }
            }


            foreach (DataView dataView in _dataViews[tabCategory.SelectedTab.Name])
            {
                ListView listView = dataView.getListView();
                string copyText = "";
                IEnumerable<ListViewItem> items;
                if (isSelectOnly)
                    items = listView.SelectedItems.Cast<ListViewItem>();
                else
                    items = listView.Items.Cast<ListViewItem>();

                foreach(ListViewItem item in items)
                {
                    foreach(ListViewItem.ListViewSubItem subItem in item.SubItems)
                    {
                        copyText += subItem.Text;
                        copyText += ",";
                    }
                    copyText += "\n";
                }
                if (copyText.Length > 0)
                    Clipboard.SetText(copyText);
            }
        }

        private async void listUserVoice_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListViewItem curItem = listUserVoice.GetItemAt(e.Location.X, e.Location.Y);
            if (curItem != null && curItem.Tag != null)
            {
                ParseObject userVoice = ((ParseObject)curItem.Tag);
                txtPhoneNumber.Text = userVoice.GetString("searchNumber");
                if (userVoice.ContainsKey("device"))
                {
                    RestQuery query = new RestQuery("_User");
                    query.equalTo("device", userVoice["device"]);
                    query.includeKey("device");
                    List<ParseObject> devices = await RestAPI.get(query);
                    if (devices.Count > 0)
                        loadDevice(devices[0], userVoice);
                    else
                        btnSearch_Click(null, null);
                }

                else
                {
                    btnSearch_Click(null, null);
                }
            }
        }


        private async void btnBackupLog_Click(object sender, EventArgs e)
        {
            await RestAPI.callFunctions("backupLog", new Dictionary<string, object> { { "phoneNumber", _deviceUser.GetString("phoneNumber") } });
        }




        private void talklResend_Click(object sender, EventArgs e)
        {
            
        }

        private async void wpsFixRequest_Click(object sender, EventArgs e)
        {
            if (_deviceUser == null)
                return;

            DataView managerView = (DataView)(getDataViews("tabManager").GetValue(0));
            if (!managerView.isLoaded())
            {
                await managerView.loadData(_deviceUser, this);
            }


            if (managerView.getListView().Items.Count == 0)
            {
                MessageBox.Show("한명이상의 등록된 관리자가 필요합니다.");
                return;
            }

            ParseObject manager = (ParseObject)managerView.getListView().Items[0].Tag;
            DeviceAddress addressForm = new DeviceAddress(_deviceUser.Get<ParseObject>("device"), manager.ObjectId);
            addressForm.ShowDialog(this);
        }

        private void exportAddress_Click(object sender, EventArgs e)
        {
            Exports.ExportAddressForm child = new Exports.ExportAddressForm();
            child.ShowDialog(this);
        }

        private void exportSafeZone_Click(object sender, EventArgs e)
        {
            Exports.ExportSafeZoneForm child = new Exports.ExportSafeZoneForm();
            child.ShowDialog(this);
        }

        private void listSendTalk_DoubleClick(object sender, EventArgs e)
        {
            ParseObject session = (ParseObject)listSendTalk.SelectedItems[0].Tag;
            CheckTalkSessionForm child = new CheckTalkSessionForm(_deviceUser.GetString("phoneNumber"), session);
            child.ShowDialog(this);
        }

        private void exportUserList_Click(object sender, EventArgs e)
        {
            Exports.ExportUserLlistForm child = new Exports.ExportUserLlistForm();
            child.ShowDialog(this);
        }

        private async void btnAddLog_Click(object sender, EventArgs e)
        {
            if (txtNewLog.Text.Length > 0)
            {
                ParseObject uvComment = new ParseObject("UVComment");
                uvComment["log"] = _uvLog;
                uvComment["history"] = _uvHistory;
                uvComment["comment"] = txtNewLog.Text;
                await RestAPI.createNew(uvComment, ServiceList.current.adminServer);
                addLog(uvComment);
                txtNewLog.Text = "";
            }
        }

        void addLog(ParseObject uvComment)
        {
            txtOldLog.AppendText(DateTime.Now.ToLocalTime().ToString());
            txtOldLog.AppendText("\n");
            txtOldLog.AppendText(uvComment.GetString("comment"));
            txtOldLog.AppendText("\n\n");
            txtOldLog.SelectionStart = txtOldLog.Text.Length;
            txtOldLog.ScrollToCaret();
        }

        private void propDevice_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (propDevice.SelectedItems.Count > 0)
            {
                string key = propDevice.SelectedItems[0].SubItems[0].Text;
                string value = propDevice.SelectedItems[0].SubItems[1].Text;
                if (key == "IMEI")
                    value = value.Replace("-", "");
                Clipboard.SetText(value);
                MessageBox.Show(key + "가 복사되었습니다.\n" + value);
            }
        }

        private void listDeviceHistory_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if ( listDeviceHistory.SelectedItems.Count > 0 )
            {
                string imei = (((ParseObject)listDeviceHistory.SelectedItems[0].Tag).GetString("imei")).Replace("-", "");
                Clipboard.SetText( imei );
                MessageBox.Show("IMEI가 복사되었습니다.\n" + imei);
            }
        }

        private void itemShopAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ItemShopAddForm child = new ItemShopAddForm();
            child.ShowDialog(this);
        }

        private void exportAddressWithAutoPosReport_Click(object sender, EventArgs e)
        {
            Exports.ExportAddressWithAutoPosReportForm child = new Exports.ExportAddressWithAutoPosReportForm();
            child.ShowDialog(this);
        }

        private void menuSyncTrackingServer_Click(object sender, EventArgs e)
        {
            SyncTrackingServerForm child = new SyncTrackingServerForm();
            child.ShowDialog(this);
        }

        private void menuSendEventPush_Click(object sender, EventArgs e)
        {
            RegisterPushEventForm child = new RegisterPushEventForm();
            child.ShowDialog(this);
        }

        private void menuTrackingStatics_Click(object sender, EventArgs e)
        {
            TrackingStaticsForm child = new TrackingStaticsForm();
            child.ShowDialog(this);
        }

        private void menuFindInvalidDeviceUser_Click(object sender, EventArgs e)
        {
            FindInvalidDeviceUserForm child = new FindInvalidDeviceUserForm();
            child.ShowDialog(this);
        }

        private void resetDeviceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetDeviceForm child = new ResetDeviceForm();
            child.ShowDialog(this);

        }

        private void exportDeviceList_Click(object sender, EventArgs e)
        {
            Exports.ExportDeviceListForm child = new Exports.ExportDeviceListForm();
            child.ShowDialog(this);
        }

        private void installation정리ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InstallationFixForm child = new InstallationFixForm();
            child.ShowDialog(this);
        }

        private void 가입자PushOff통계ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exports.ExportPushOffUserList child = new Exports.ExportPushOffUserList();
            child.ShowDialog(this);
        }

        private void 관리자추가이벤트통계ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DateTimeSelectForm picker = new DateTimeSelectForm();
            if (DialogResult.OK == picker.ShowDialog())
            {
                Exports.ExportEventManagerList child = new Exports.ExportEventManagerList();
                child.setQueryDate(picker.StartTimeValue, picker.EndTimeValue);
                child.ShowDialog(this);
            }
        }

        private async void btnClearCache_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("단말에 캐시 삭제 메시지를 보냅니다. 사용자 단말에 리셋 메시지가 표시되고 자동 리셋 됩니다.", "캐시 삭제", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                try
                {
                    Dictionary<string, object> dic = new Dictionary<string, object>();
                    dic.Add("action", "clearCache");
                    dic.Add("phoneNumber", _deviceUser.GetString("phoneNumber"));
                    await RestAPI.callFunctions("adminFunc", dic);
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    this.Enabled = true;
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private async void btnSyncTrackingServer_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("deviceId", _deviceUser.Get<ParseObject>("device").ObjectId);
            var result = await RestAPI.callFunctions("syncToTrackingServer", dic);
            System.Console.WriteLine(result);
        }
    }
}
