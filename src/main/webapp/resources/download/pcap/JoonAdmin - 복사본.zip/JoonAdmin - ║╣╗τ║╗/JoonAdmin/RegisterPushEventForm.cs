﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Parse;
using JoonLib;
using System.IO;

namespace JoonAdmin
{
    public partial class RegisterPushEventForm : Form
    {
        public RegisterPushEventForm()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == openFileDialog.ShowDialog())
            {
                txtFileName.Text = openFileDialog.FileName;
            }
        }


        protected Excel.Application _xlApp = null;
        protected Excel.Workbook _xlWorkBook = null;
        protected Excel.Worksheet _xlWorkSheet = null;
        protected Excel.Range _range = null;

        private async void btnRegister_Click(object sender, EventArgs e)
        {
            btnRegister.Enabled = false;
            try
            {
                IEnumerable<KeyValuePair<string, object>> updateFields = new Dictionary<string, object> { { "eventCode", txtEventCode.Text } }.ToList();

                _xlApp = new Excel.Application();
                _xlWorkBook = _xlApp.Workbooks.Open(txtFileName.Text);
                _xlWorkSheet = (Excel.Worksheet)_xlWorkBook.Worksheets.get_Item(1);
                _xlWorkSheet.Columns.ClearFormats();
                _xlWorkSheet.Rows.ClearFormats();
                _range = _xlWorkSheet.UsedRange;

                for (int row = 1; row <= _range.Rows.Count; ++row)
                {
                    string phoneNumber = Convert.ChangeType((_range.Cells[row, 1] as Excel.Range).Value2, typeof(string));
                    writeLog(phoneNumber);

                    RestQuery query = new RestQuery("_User");
                    query.equalTo("phoneNumber", phoneNumber);
                    query.equalTo("type", "manager");
                    List<ParseObject> users = await RestAPI.get(query);
                    if (users.Count > 0)
                    {
                        writeLog("user find:" + users[0].ObjectId);
                        RestQuery installationQuery = new RestQuery("_Installation");
                        installationQuery.equalTo("user", users[0]);
                        List<ParseObject> installationList = await RestAPI.get(installationQuery);
                        if (installationList.Count > 0)
                        {
                            await RestAPI.update(installationList[0], updateFields);
                            writeLog("installation update." + installationList[0].ObjectId);
                        }
                        else
                        {
                            writeLog("installation not found.");
                        }
                    }
                    else
                    {
                        writeLog("user not found");
                    }
                }
                writeLog("Complete.");
            } catch (Exception exp)
            {
                writeLog(exp.Message);
            }
            btnRegister.Enabled = true;
        }

        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }
    }
}
