﻿namespace JoonAdmin
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.위치ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wpsFixRequest = new System.Windows.Forms.ToolStripMenuItem();
            this.단말정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.새로고침ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportAddressWithAutoPosReport = new System.Windows.Forms.ToolStripMenuItem();
            this.exportAddress = new System.Windows.Forms.ToolStripMenuItem();
            this.exportSafeZone = new System.Windows.Forms.ToolStripMenuItem();
            this.exportUserList = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTrackingStatics = new System.Windows.Forms.ToolStripMenuItem();
            this.exportDeviceList = new System.Windows.Forms.ToolStripMenuItem();
            this.가입자PushOff통계ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.관리자추가이벤트통계ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSendEventPush = new System.Windows.Forms.ToolStripMenuItem();
            this.installation정리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemShopAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSyncTrackingServer = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFindInvalidDeviceUser = new System.Windows.Forms.ToolStripMenuItem();
            this.resetDeviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tableLayoutMain = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutData = new System.Windows.Forms.TableLayoutPanel();
            this.tabCategory = new System.Windows.Forms.TabControl();
            this.tabDevice = new System.Windows.Forms.TabPage();
            this.propDevice = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabManager = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAddress = new System.Windows.Forms.Button();
            this.btnAddManager = new System.Windows.Forms.Button();
            this.btnDelManager = new System.Windows.Forms.Button();
            this.listManager = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabContact = new System.Windows.Forms.TabPage();
            this.listContact = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabTalk = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.listRecvTalk = new System.Windows.Forms.ListView();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader43 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader44 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listSendTalk = new System.Windows.Forms.ListView();
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader42 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.talkContext = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.talklResend = new System.Windows.Forms.ToolStripMenuItem();
            this.tabSafezone = new System.Windows.Forms.TabPage();
            this.listSafezone = new System.Windows.Forms.ListView();
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabTracking = new System.Windows.Forms.TabPage();
            this.listTracking = new System.Windows.Forms.ListView();
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabToy = new System.Windows.Forms.TabPage();
            this.listToy = new System.Windows.Forms.ListView();
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabChangeHistory = new System.Windows.Forms.TabPage();
            this.listDeviceHistory = new System.Windows.Forms.ListView();
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader40 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader38 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabRemoteControl = new System.Windows.Forms.TabPage();
            this.btnClearCache = new System.Windows.Forms.Button();
            this.btnBackupLog = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.txtOldLog = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.txtNewLog = new System.Windows.Forms.TextBox();
            this.btnAddLog = new System.Windows.Forms.Button();
            this.tableLayoutSearch = new System.Windows.Forms.TableLayoutPanel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtPhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listUserVoice = new System.Windows.Forms.ListView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.mainMenu.SuspendLayout();
            this.tableLayoutMain.SuspendLayout();
            this.tableLayoutData.SuspendLayout();
            this.tabCategory.SuspendLayout();
            this.tabDevice.SuspendLayout();
            this.tabManager.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabContact.SuspendLayout();
            this.tabTalk.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.talkContext.SuspendLayout();
            this.tabSafezone.SuspendLayout();
            this.tabTracking.SuspendLayout();
            this.tabToy.SuspendLayout();
            this.tabChangeHistory.SuspendLayout();
            this.tabRemoteControl.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutSearch.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.위치ToolStripMenuItem,
            this.단말정보ToolStripMenuItem,
            this.exportToolStripMenuItem,
            this.manageToolStripMenuItem});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(1208, 24);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "menuStrip1";
            // 
            // 위치ToolStripMenuItem
            // 
            this.위치ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wpsFixRequest});
            this.위치ToolStripMenuItem.Name = "위치ToolStripMenuItem";
            this.위치ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.위치ToolStripMenuItem.Text = "위치";
            // 
            // wpsFixRequest
            // 
            this.wpsFixRequest.Name = "wpsFixRequest";
            this.wpsFixRequest.Size = new System.Drawing.Size(190, 22);
            this.wpsFixRequest.Text = "WiFi 위치 보정 신청...";
            this.wpsFixRequest.Click += new System.EventHandler(this.wpsFixRequest_Click);
            // 
            // 단말정보ToolStripMenuItem
            // 
            this.단말정보ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.새로고침ToolStripMenuItem,
            this.menuCopy});
            this.단말정보ToolStripMenuItem.Name = "단말정보ToolStripMenuItem";
            this.단말정보ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.단말정보ToolStripMenuItem.Text = "보기";
            // 
            // 새로고침ToolStripMenuItem
            // 
            this.새로고침ToolStripMenuItem.Name = "새로고침ToolStripMenuItem";
            this.새로고침ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.새로고침ToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.새로고침ToolStripMenuItem.Text = "새로 고침";
            // 
            // menuCopy
            // 
            this.menuCopy.Name = "menuCopy";
            this.menuCopy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.menuCopy.Size = new System.Drawing.Size(224, 22);
            this.menuCopy.Text = "현재 화면 내용 복사";
            this.menuCopy.Click += new System.EventHandler(this.menuCopy_Click);
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportAddressWithAutoPosReport,
            this.exportAddress,
            this.exportSafeZone,
            this.exportUserList,
            this.menuTrackingStatics,
            this.exportDeviceList,
            this.가입자PushOff통계ToolStripMenuItem,
            this.관리자추가이벤트통계ToolStripMenuItem});
            this.exportToolStripMenuItem.Enabled = false;
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.exportToolStripMenuItem.Text = "Export";
            // 
            // exportAddressWithAutoPosReport
            // 
            this.exportAddressWithAutoPosReport.Name = "exportAddressWithAutoPosReport";
            this.exportAddressWithAutoPosReport.Size = new System.Drawing.Size(230, 22);
            this.exportAddressWithAutoPosReport.Text = "사용자 등록 주소 + 자동측위";
            this.exportAddressWithAutoPosReport.Click += new System.EventHandler(this.exportAddressWithAutoPosReport_Click);
            // 
            // exportAddress
            // 
            this.exportAddress.Name = "exportAddress";
            this.exportAddress.Size = new System.Drawing.Size(230, 22);
            this.exportAddress.Text = "사용자 등록 주소";
            this.exportAddress.Click += new System.EventHandler(this.exportAddress_Click);
            // 
            // exportSafeZone
            // 
            this.exportSafeZone.Name = "exportSafeZone";
            this.exportSafeZone.Size = new System.Drawing.Size(230, 22);
            this.exportSafeZone.Text = "안심존 등록 정보";
            this.exportSafeZone.Click += new System.EventHandler(this.exportSafeZone_Click);
            // 
            // exportUserList
            // 
            this.exportUserList.Name = "exportUserList";
            this.exportUserList.Size = new System.Drawing.Size(230, 22);
            this.exportUserList.Text = "가입자 정보";
            this.exportUserList.Click += new System.EventHandler(this.exportUserList_Click);
            // 
            // menuTrackingStatics
            // 
            this.menuTrackingStatics.Name = "menuTrackingStatics";
            this.menuTrackingStatics.Size = new System.Drawing.Size(230, 22);
            this.menuTrackingStatics.Text = "위치 통계...";
            this.menuTrackingStatics.Click += new System.EventHandler(this.menuTrackingStatics_Click);
            // 
            // exportDeviceList
            // 
            this.exportDeviceList.Name = "exportDeviceList";
            this.exportDeviceList.Size = new System.Drawing.Size(230, 22);
            this.exportDeviceList.Text = "단말 통계...";
            this.exportDeviceList.Click += new System.EventHandler(this.exportDeviceList_Click);
            // 
            // 가입자PushOff통계ToolStripMenuItem
            // 
            this.가입자PushOff통계ToolStripMenuItem.Name = "가입자PushOff통계ToolStripMenuItem";
            this.가입자PushOff통계ToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.가입자PushOff통계ToolStripMenuItem.Text = "가입자 + Push Off 통계...";
            this.가입자PushOff통계ToolStripMenuItem.Click += new System.EventHandler(this.가입자PushOff통계ToolStripMenuItem_Click);
            // 
            // 관리자추가이벤트통계ToolStripMenuItem
            // 
            this.관리자추가이벤트통계ToolStripMenuItem.Name = "관리자추가이벤트통계ToolStripMenuItem";
            this.관리자추가이벤트통계ToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.관리자추가이벤트통계ToolStripMenuItem.Text = "관리자 추가 이벤트 통계...";
            this.관리자추가이벤트통계ToolStripMenuItem.Click += new System.EventHandler(this.관리자추가이벤트통계ToolStripMenuItem_Click);
            // 
            // manageToolStripMenuItem
            // 
            this.manageToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuSendEventPush,
            this.installation정리ToolStripMenuItem,
            this.itemShopAddToolStripMenuItem,
            this.menuSyncTrackingServer,
            this.menuFindInvalidDeviceUser,
            this.resetDeviceToolStripMenuItem});
            this.manageToolStripMenuItem.Enabled = false;
            this.manageToolStripMenuItem.Name = "manageToolStripMenuItem";
            this.manageToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.manageToolStripMenuItem.Text = "관리";
            // 
            // menuSendEventPush
            // 
            this.menuSendEventPush.Name = "menuSendEventPush";
            this.menuSendEventPush.Size = new System.Drawing.Size(212, 22);
            this.menuSendEventPush.Text = "Event Push 등록...";
            this.menuSendEventPush.Click += new System.EventHandler(this.menuSendEventPush_Click);
            // 
            // installation정리ToolStripMenuItem
            // 
            this.installation정리ToolStripMenuItem.Name = "installation정리ToolStripMenuItem";
            this.installation정리ToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.installation정리ToolStripMenuItem.Text = "Installation 정리...";
            this.installation정리ToolStripMenuItem.Click += new System.EventHandler(this.installation정리ToolStripMenuItem_Click);
            // 
            // itemShopAddToolStripMenuItem
            // 
            this.itemShopAddToolStripMenuItem.Name = "itemShopAddToolStripMenuItem";
            this.itemShopAddToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.itemShopAddToolStripMenuItem.Text = "아이템 샵 아이템 추가...";
            this.itemShopAddToolStripMenuItem.Click += new System.EventHandler(this.itemShopAddToolStripMenuItem_Click);
            // 
            // menuSyncTrackingServer
            // 
            this.menuSyncTrackingServer.Name = "menuSyncTrackingServer";
            this.menuSyncTrackingServer.Size = new System.Drawing.Size(212, 22);
            this.menuSyncTrackingServer.Text = "Tracking Server 동기화...";
            this.menuSyncTrackingServer.Click += new System.EventHandler(this.menuSyncTrackingServer_Click);
            // 
            // menuFindInvalidDeviceUser
            // 
            this.menuFindInvalidDeviceUser.Name = "menuFindInvalidDeviceUser";
            this.menuFindInvalidDeviceUser.Size = new System.Drawing.Size(212, 22);
            this.menuFindInvalidDeviceUser.Text = "Find Invalid Device User...";
            this.menuFindInvalidDeviceUser.Click += new System.EventHandler(this.menuFindInvalidDeviceUser_Click);
            // 
            // resetDeviceToolStripMenuItem
            // 
            this.resetDeviceToolStripMenuItem.Name = "resetDeviceToolStripMenuItem";
            this.resetDeviceToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.resetDeviceToolStripMenuItem.Text = "Reset Device...";
            this.resetDeviceToolStripMenuItem.Click += new System.EventHandler(this.resetDeviceToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 671);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1208, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tableLayoutMain
            // 
            this.tableLayoutMain.ColumnCount = 2;
            this.tableLayoutMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutMain.Controls.Add(this.tableLayoutData, 1, 1);
            this.tableLayoutMain.Controls.Add(this.tableLayoutSearch, 1, 0);
            this.tableLayoutMain.Controls.Add(this.listUserVoice, 0, 1);
            this.tableLayoutMain.Controls.Add(this.label1, 0, 0);
            this.tableLayoutMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutMain.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutMain.Name = "tableLayoutMain";
            this.tableLayoutMain.RowCount = 2;
            this.tableLayoutMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutMain.Size = new System.Drawing.Size(1208, 647);
            this.tableLayoutMain.TabIndex = 2;
            // 
            // tableLayoutData
            // 
            this.tableLayoutData.ColumnCount = 1;
            this.tableLayoutData.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutData.Controls.Add(this.tabCategory, 0, 0);
            this.tableLayoutData.Controls.Add(this.tableLayoutPanel5, 0, 1);
            this.tableLayoutData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutData.Location = new System.Drawing.Point(253, 43);
            this.tableLayoutData.Name = "tableLayoutData";
            this.tableLayoutData.RowCount = 2;
            this.tableLayoutData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutData.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 176F));
            this.tableLayoutData.Size = new System.Drawing.Size(952, 601);
            this.tableLayoutData.TabIndex = 0;
            // 
            // tabCategory
            // 
            this.tabCategory.Controls.Add(this.tabDevice);
            this.tabCategory.Controls.Add(this.tabManager);
            this.tabCategory.Controls.Add(this.tabContact);
            this.tabCategory.Controls.Add(this.tabTalk);
            this.tabCategory.Controls.Add(this.tabSafezone);
            this.tabCategory.Controls.Add(this.tabTracking);
            this.tabCategory.Controls.Add(this.tabToy);
            this.tabCategory.Controls.Add(this.tabChangeHistory);
            this.tabCategory.Controls.Add(this.tabRemoteControl);
            this.tabCategory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCategory.Location = new System.Drawing.Point(3, 3);
            this.tabCategory.Name = "tabCategory";
            this.tabCategory.SelectedIndex = 0;
            this.tabCategory.Size = new System.Drawing.Size(946, 419);
            this.tabCategory.TabIndex = 1;
            this.tabCategory.SelectedIndexChanged += new System.EventHandler(this.tabCategory_SelectedIndexChanged);
            // 
            // tabDevice
            // 
            this.tabDevice.Controls.Add(this.tableLayoutPanel1);
            this.tabDevice.Location = new System.Drawing.Point(4, 22);
            this.tabDevice.Name = "tabDevice";
            this.tabDevice.Size = new System.Drawing.Size(938, 393);
            this.tabDevice.TabIndex = 0;
            this.tabDevice.Text = "단말";
            this.tabDevice.UseVisualStyleBackColor = true;
            // 
            // propDevice
            // 
            this.propDevice.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.propDevice.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propDevice.FullRowSelect = true;
            this.propDevice.GridLines = true;
            this.propDevice.Location = new System.Drawing.Point(3, 3);
            this.propDevice.Name = "propDevice";
            this.propDevice.Size = new System.Drawing.Size(932, 387);
            this.propDevice.TabIndex = 0;
            this.propDevice.UseCompatibleStateImageBehavior = false;
            this.propDevice.View = System.Windows.Forms.View.Details;
            this.propDevice.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.propDevice_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "항목";
            this.columnHeader1.Width = 219;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "";
            this.columnHeader2.Width = 296;
            // 
            // tabManager
            // 
            this.tabManager.Controls.Add(this.tableLayoutPanel6);
            this.tabManager.Location = new System.Drawing.Point(4, 22);
            this.tabManager.Name = "tabManager";
            this.tabManager.Padding = new System.Windows.Forms.Padding(3);
            this.tabManager.Size = new System.Drawing.Size(938, 393);
            this.tabManager.TabIndex = 1;
            this.tabManager.Text = "보호자";
            this.tabManager.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.listManager, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(932, 387);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.btnAddress);
            this.panel1.Controls.Add(this.btnAddManager);
            this.panel1.Controls.Add(this.btnDelManager);
            this.panel1.Location = new System.Drawing.Point(417, 350);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(512, 34);
            this.panel1.TabIndex = 3;
            // 
            // btnAddress
            // 
            this.btnAddress.Location = new System.Drawing.Point(141, 0);
            this.btnAddress.Name = "btnAddress";
            this.btnAddress.Size = new System.Drawing.Size(96, 34);
            this.btnAddress.TabIndex = 2;
            this.btnAddress.Text = "주소등록";
            this.btnAddress.UseVisualStyleBackColor = true;
            this.btnAddress.Click += new System.EventHandler(this.btnAddress_Click_1);
            // 
            // btnAddManager
            // 
            this.btnAddManager.Location = new System.Drawing.Point(412, 0);
            this.btnAddManager.Name = "btnAddManager";
            this.btnAddManager.Size = new System.Drawing.Size(92, 34);
            this.btnAddManager.TabIndex = 1;
            this.btnAddManager.Text = "관리자 추가";
            this.btnAddManager.UseVisualStyleBackColor = true;
            this.btnAddManager.Click += new System.EventHandler(this.btnAddManager_Click);
            // 
            // btnDelManager
            // 
            this.btnDelManager.Location = new System.Drawing.Point(310, 0);
            this.btnDelManager.Name = "btnDelManager";
            this.btnDelManager.Size = new System.Drawing.Size(96, 34);
            this.btnDelManager.TabIndex = 0;
            this.btnDelManager.Text = "관리자 삭제";
            this.btnDelManager.UseVisualStyleBackColor = true;
            this.btnDelManager.Click += new System.EventHandler(this.btnDelManager_Click);
            // 
            // listManager
            // 
            this.listManager.CheckBoxes = true;
            this.listManager.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listManager.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listManager.FullRowSelect = true;
            this.listManager.GridLines = true;
            this.listManager.Location = new System.Drawing.Point(0, 0);
            this.listManager.Margin = new System.Windows.Forms.Padding(0);
            this.listManager.Name = "listManager";
            this.listManager.Size = new System.Drawing.Size(932, 347);
            this.listManager.TabIndex = 2;
            this.listManager.UseCompatibleStateImageBehavior = false;
            this.listManager.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "이름";
            this.columnHeader3.Width = 219;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "전화번호";
            this.columnHeader4.Width = 248;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "생성일";
            this.columnHeader5.Width = 113;
            // 
            // tabContact
            // 
            this.tabContact.Controls.Add(this.tableLayoutPanel2);
            this.tabContact.Location = new System.Drawing.Point(4, 22);
            this.tabContact.Name = "tabContact";
            this.tabContact.Size = new System.Drawing.Size(938, 393);
            this.tabContact.TabIndex = 2;
            this.tabContact.Text = "연락처";
            this.tabContact.UseVisualStyleBackColor = true;
            // 
            // listContact
            // 
            this.listContact.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.listContact.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listContact.FullRowSelect = true;
            this.listContact.GridLines = true;
            this.listContact.Location = new System.Drawing.Point(3, 3);
            this.listContact.Name = "listContact";
            this.listContact.Size = new System.Drawing.Size(932, 387);
            this.listContact.TabIndex = 2;
            this.listContact.UseCompatibleStateImageBehavior = false;
            this.listContact.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "이름";
            this.columnHeader6.Width = 219;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "전화번호";
            this.columnHeader7.Width = 245;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "준 친구";
            this.columnHeader8.Width = 83;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "생성일";
            this.columnHeader9.Width = 113;
            // 
            // tabTalk
            // 
            this.tabTalk.Controls.Add(this.tableLayoutPanel4);
            this.tabTalk.Location = new System.Drawing.Point(4, 22);
            this.tabTalk.Name = "tabTalk";
            this.tabTalk.Size = new System.Drawing.Size(938, 393);
            this.tabTalk.TabIndex = 3;
            this.tabTalk.Text = "준톡";
            this.tabTalk.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.listRecvTalk, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.listSendTalk, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(938, 393);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // listRecvTalk
            // 
            this.listRecvTalk.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader31,
            this.columnHeader43,
            this.columnHeader44});
            this.listRecvTalk.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listRecvTalk.FullRowSelect = true;
            this.listRecvTalk.GridLines = true;
            this.listRecvTalk.Location = new System.Drawing.Point(3, 199);
            this.listRecvTalk.Name = "listRecvTalk";
            this.listRecvTalk.Size = new System.Drawing.Size(932, 191);
            this.listRecvTalk.Sorting = System.Windows.Forms.SortOrder.Descending;
            this.listRecvTalk.TabIndex = 4;
            this.listRecvTalk.UseCompatibleStateImageBehavior = false;
            this.listRecvTalk.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "받은 시간";
            this.columnHeader10.Width = 145;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "보낸 사람";
            this.columnHeader11.Width = 191;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "세션 타입";
            this.columnHeader12.Width = 112;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "톡 타입";
            this.columnHeader31.Width = 99;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "세션ID";
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "TalkServer";
            // 
            // listSendTalk
            // 
            this.listSendTalk.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader30,
            this.columnHeader23,
            this.columnHeader32,
            this.columnHeader41,
            this.columnHeader42});
            this.listSendTalk.ContextMenuStrip = this.talkContext;
            this.listSendTalk.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listSendTalk.FullRowSelect = true;
            this.listSendTalk.GridLines = true;
            this.listSendTalk.Location = new System.Drawing.Point(3, 3);
            this.listSendTalk.MultiSelect = false;
            this.listSendTalk.Name = "listSendTalk";
            this.listSendTalk.Size = new System.Drawing.Size(932, 190);
            this.listSendTalk.Sorting = System.Windows.Forms.SortOrder.Descending;
            this.listSendTalk.TabIndex = 3;
            this.listSendTalk.UseCompatibleStateImageBehavior = false;
            this.listSendTalk.View = System.Windows.Forms.View.Details;
            this.listSendTalk.DoubleClick += new System.EventHandler(this.listSendTalk_DoubleClick);
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "보낸 시간";
            this.columnHeader18.Width = 145;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "받는 사람";
            this.columnHeader19.Width = 191;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "세션 타입";
            this.columnHeader20.Width = 111;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "톡 타입";
            this.columnHeader30.Width = 99;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "전송타입";
            this.columnHeader23.Width = 121;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "세션오류";
            this.columnHeader32.Width = 78;
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "세션ID";
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "TalkServer";
            this.columnHeader42.Width = 78;
            // 
            // talkContext
            // 
            this.talkContext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.talklResend});
            this.talkContext.Name = "talkContext";
            this.talkContext.Size = new System.Drawing.Size(120, 26);
            // 
            // talklResend
            // 
            this.talklResend.Name = "talklResend";
            this.talklResend.Size = new System.Drawing.Size(119, 22);
            this.talklResend.Text = "재전송...";
            this.talklResend.Click += new System.EventHandler(this.talklResend_Click);
            // 
            // tabSafezone
            // 
            this.tabSafezone.Controls.Add(this.listSafezone);
            this.tabSafezone.Location = new System.Drawing.Point(4, 22);
            this.tabSafezone.Name = "tabSafezone";
            this.tabSafezone.Padding = new System.Windows.Forms.Padding(3);
            this.tabSafezone.Size = new System.Drawing.Size(938, 393);
            this.tabSafezone.TabIndex = 5;
            this.tabSafezone.Text = "안심존";
            this.tabSafezone.UseVisualStyleBackColor = true;
            // 
            // listSafezone
            // 
            this.listSafezone.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader22});
            this.listSafezone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listSafezone.FullRowSelect = true;
            this.listSafezone.GridLines = true;
            this.listSafezone.Location = new System.Drawing.Point(3, 3);
            this.listSafezone.Name = "listSafezone";
            this.listSafezone.Size = new System.Drawing.Size(932, 387);
            this.listSafezone.TabIndex = 1;
            this.listSafezone.UseCompatibleStateImageBehavior = false;
            this.listSafezone.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "이름";
            this.columnHeader14.Width = 219;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "On";
            this.columnHeader15.Width = 115;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "반경";
            this.columnHeader22.Width = 130;
            // 
            // tabTracking
            // 
            this.tabTracking.Controls.Add(this.listTracking);
            this.tabTracking.Location = new System.Drawing.Point(4, 22);
            this.tabTracking.Name = "tabTracking";
            this.tabTracking.Size = new System.Drawing.Size(938, 393);
            this.tabTracking.TabIndex = 4;
            this.tabTracking.Text = "위치";
            this.tabTracking.UseVisualStyleBackColor = true;
            // 
            // listTracking
            // 
            this.listTracking.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader21,
            this.columnHeader13,
            this.columnHeader29});
            this.listTracking.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listTracking.FullRowSelect = true;
            this.listTracking.GridLines = true;
            this.listTracking.Location = new System.Drawing.Point(0, 0);
            this.listTracking.Name = "listTracking";
            this.listTracking.Size = new System.Drawing.Size(938, 393);
            this.listTracking.TabIndex = 4;
            this.listTracking.UseCompatibleStateImageBehavior = false;
            this.listTracking.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "시간";
            this.columnHeader16.Width = 189;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "측위방식";
            this.columnHeader17.Width = 176;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "측위사유";
            this.columnHeader21.Width = 144;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "안심존 알림";
            this.columnHeader13.Width = 95;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "좌표";
            this.columnHeader29.Width = 149;
            // 
            // tabToy
            // 
            this.tabToy.Controls.Add(this.listToy);
            this.tabToy.Location = new System.Drawing.Point(4, 22);
            this.tabToy.Name = "tabToy";
            this.tabToy.Size = new System.Drawing.Size(938, 393);
            this.tabToy.TabIndex = 7;
            this.tabToy.Text = "준토이";
            this.tabToy.UseVisualStyleBackColor = true;
            // 
            // listToy
            // 
            this.listToy.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader24,
            this.columnHeader25});
            this.listToy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listToy.FullRowSelect = true;
            this.listToy.GridLines = true;
            this.listToy.Location = new System.Drawing.Point(0, 0);
            this.listToy.Name = "listToy";
            this.listToy.Size = new System.Drawing.Size(938, 393);
            this.listToy.TabIndex = 1;
            this.listToy.UseCompatibleStateImageBehavior = false;
            this.listToy.View = System.Windows.Forms.View.Details;
            this.listToy.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listToy_MouseDoubleClick);
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "항목";
            this.columnHeader24.Width = 219;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "";
            this.columnHeader25.Width = 296;
            // 
            // tabChangeHistory
            // 
            this.tabChangeHistory.Controls.Add(this.listDeviceHistory);
            this.tabChangeHistory.Location = new System.Drawing.Point(4, 22);
            this.tabChangeHistory.Name = "tabChangeHistory";
            this.tabChangeHistory.Padding = new System.Windows.Forms.Padding(3);
            this.tabChangeHistory.Size = new System.Drawing.Size(938, 393);
            this.tabChangeHistory.TabIndex = 8;
            this.tabChangeHistory.Text = "변경이력";
            this.tabChangeHistory.UseVisualStyleBackColor = true;
            // 
            // listDeviceHistory
            // 
            this.listDeviceHistory.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader34,
            this.columnHeader27,
            this.columnHeader33,
            this.columnHeader35,
            this.columnHeader40,
            this.columnHeader36,
            this.columnHeader38,
            this.columnHeader37,
            this.columnHeader39});
            this.listDeviceHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listDeviceHistory.FullRowSelect = true;
            this.listDeviceHistory.GridLines = true;
            this.listDeviceHistory.Location = new System.Drawing.Point(3, 3);
            this.listDeviceHistory.Name = "listDeviceHistory";
            this.listDeviceHistory.Size = new System.Drawing.Size(932, 387);
            this.listDeviceHistory.TabIndex = 2;
            this.listDeviceHistory.UseCompatibleStateImageBehavior = false;
            this.listDeviceHistory.View = System.Windows.Forms.View.Details;
            this.listDeviceHistory.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listDeviceHistory_MouseDoubleClick);
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "상태";
            this.columnHeader34.Width = 61;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "생성일";
            this.columnHeader27.Width = 145;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "변경일";
            this.columnHeader33.Width = 156;
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "IMEI";
            this.columnHeader35.Width = 180;
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "시리얼번호";
            this.columnHeader40.Width = 91;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "등록모델";
            this.columnHeader36.Width = 62;
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "현재모델";
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "등록버전";
            this.columnHeader37.Width = 88;
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "현재버전";
            this.columnHeader39.Width = 94;
            // 
            // tabRemoteControl
            // 
            this.tabRemoteControl.Controls.Add(this.btnClearCache);
            this.tabRemoteControl.Controls.Add(this.btnBackupLog);
            this.tabRemoteControl.Controls.Add(this.btnReset);
            this.tabRemoteControl.Location = new System.Drawing.Point(4, 22);
            this.tabRemoteControl.Name = "tabRemoteControl";
            this.tabRemoteControl.Padding = new System.Windows.Forms.Padding(3);
            this.tabRemoteControl.Size = new System.Drawing.Size(938, 393);
            this.tabRemoteControl.TabIndex = 6;
            this.tabRemoteControl.Text = "기타";
            this.tabRemoteControl.UseVisualStyleBackColor = true;
            // 
            // btnClearCache
            // 
            this.btnClearCache.Location = new System.Drawing.Point(6, 48);
            this.btnClearCache.Name = "btnClearCache";
            this.btnClearCache.Size = new System.Drawing.Size(112, 36);
            this.btnClearCache.TabIndex = 2;
            this.btnClearCache.Text = "캐시 초기화";
            this.btnClearCache.UseVisualStyleBackColor = true;
            this.btnClearCache.Click += new System.EventHandler(this.btnClearCache_Click);
            // 
            // btnBackupLog
            // 
            this.btnBackupLog.Location = new System.Drawing.Point(6, 92);
            this.btnBackupLog.Name = "btnBackupLog";
            this.btnBackupLog.Size = new System.Drawing.Size(112, 36);
            this.btnBackupLog.TabIndex = 1;
            this.btnBackupLog.Text = "로그 백업";
            this.btnBackupLog.UseVisualStyleBackColor = true;
            this.btnBackupLog.Click += new System.EventHandler(this.btnBackupLog_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(6, 6);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(112, 36);
            this.btnReset.TabIndex = 0;
            this.btnReset.Text = "리셋";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.txtOldLog, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel7, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 428);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 62.35294F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.64706F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(946, 170);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // txtOldLog
            // 
            this.txtOldLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtOldLog.Location = new System.Drawing.Point(5, 3);
            this.txtOldLog.Margin = new System.Windows.Forms.Padding(5, 3, 3, 3);
            this.txtOldLog.Multiline = true;
            this.txtOldLog.Name = "txtOldLog";
            this.txtOldLog.ReadOnly = true;
            this.txtOldLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOldLog.Size = new System.Drawing.Size(938, 99);
            this.txtOldLog.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.34164F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.65836F));
            this.tableLayoutPanel7.Controls.Add(this.txtNewLog, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.btnAddLog, 1, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 108);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(940, 59);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // txtNewLog
            // 
            this.txtNewLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNewLog.Location = new System.Drawing.Point(3, 3);
            this.txtNewLog.Multiline = true;
            this.txtNewLog.Name = "txtNewLog";
            this.txtNewLog.Size = new System.Drawing.Size(786, 53);
            this.txtNewLog.TabIndex = 0;
            // 
            // btnAddLog
            // 
            this.btnAddLog.Location = new System.Drawing.Point(795, 3);
            this.btnAddLog.Name = "btnAddLog";
            this.btnAddLog.Size = new System.Drawing.Size(127, 34);
            this.btnAddLog.TabIndex = 1;
            this.btnAddLog.Text = "상담내용 추가";
            this.btnAddLog.UseVisualStyleBackColor = true;
            this.btnAddLog.Click += new System.EventHandler(this.btnAddLog_Click);
            // 
            // tableLayoutSearch
            // 
            this.tableLayoutSearch.ColumnCount = 3;
            this.tableLayoutSearch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutSearch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutSearch.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutSearch.Controls.Add(this.btnSearch, 2, 0);
            this.tableLayoutSearch.Controls.Add(this.txtPhoneNumber, 1, 0);
            this.tableLayoutSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutSearch.Location = new System.Drawing.Point(253, 3);
            this.tableLayoutSearch.Name = "tableLayoutSearch";
            this.tableLayoutSearch.RowCount = 1;
            this.tableLayoutSearch.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutSearch.Size = new System.Drawing.Size(952, 34);
            this.tableLayoutSearch.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.Location = new System.Drawing.Point(839, 3);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(110, 28);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "검색";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.txtPhoneNumber.Location = new System.Drawing.Point(646, 6);
            this.txtPhoneNumber.Mask = "000-9000-0000";
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(183, 21);
            this.txtPhoneNumber.TabIndex = 3;
            this.txtPhoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNumber_KeyPress);
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList.ImageSize = new System.Drawing.Size(1, 44);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "상담내역";
            // 
            // listUserVoice
            // 
            this.listUserVoice.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader26,
            this.columnHeader28});
            this.listUserVoice.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listUserVoice.FullRowSelect = true;
            this.listUserVoice.GridLines = true;
            this.listUserVoice.LargeImageList = this.imageList;
            this.listUserVoice.Location = new System.Drawing.Point(3, 43);
            this.listUserVoice.Name = "listUserVoice";
            this.listUserVoice.Size = new System.Drawing.Size(244, 601);
            this.listUserVoice.SmallImageList = this.imageList;
            this.listUserVoice.TabIndex = 2;
            this.listUserVoice.UseCompatibleStateImageBehavior = false;
            this.listUserVoice.View = System.Windows.Forms.View.Tile;
            this.listUserVoice.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listUserVoice_MouseDoubleClick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.propDevice, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(938, 393);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.listContact, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(938, 393);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 693);
            this.Controls.Add(this.tableLayoutMain);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.mainMenu);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "JooN Admin";
            this.Shown += new System.EventHandler(this.AdminForm_Shown);
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.tableLayoutMain.ResumeLayout(false);
            this.tableLayoutMain.PerformLayout();
            this.tableLayoutData.ResumeLayout(false);
            this.tabCategory.ResumeLayout(false);
            this.tabDevice.ResumeLayout(false);
            this.tabManager.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabContact.ResumeLayout(false);
            this.tabTalk.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.talkContext.ResumeLayout(false);
            this.tabSafezone.ResumeLayout(false);
            this.tabTracking.ResumeLayout(false);
            this.tabToy.ResumeLayout(false);
            this.tabChangeHistory.ResumeLayout(false);
            this.tabRemoteControl.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutSearch.ResumeLayout(false);
            this.tableLayoutSearch.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutMain;
        private System.Windows.Forms.TableLayoutPanel tableLayoutData;
        private System.Windows.Forms.TabControl tabCategory;
        private System.Windows.Forms.TabPage tabDevice;
        private System.Windows.Forms.ListView propDevice;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.TabPage tabManager;
        private System.Windows.Forms.TabPage tabContact;
        private System.Windows.Forms.ListView listContact;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.TabPage tabTalk;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.ListView listRecvTalk;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ListView listSendTalk;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.TabPage tabSafezone;
        private System.Windows.Forms.ListView listSafezone;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.TabPage tabTracking;
        private System.Windows.Forms.ListView listTracking;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.ListView listManager;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAddManager;
        private System.Windows.Forms.Button btnDelManager;
        private System.Windows.Forms.TabPage tabRemoteControl;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnAddress;
        private System.Windows.Forms.TabPage tabToy;
        private System.Windows.Forms.ListView listToy;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ToolStripMenuItem 단말정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 새로고침ToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.MaskedTextBox txtPhoneNumber;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ToolStripMenuItem menuCopy;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.Button btnBackupLog;
        private System.Windows.Forms.ContextMenuStrip talkContext;
        private System.Windows.Forms.ToolStripMenuItem talklResend;
        private System.Windows.Forms.ToolStripMenuItem 위치ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wpsFixRequest;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportAddress;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ToolStripMenuItem exportSafeZone;
        private System.Windows.Forms.ToolStripMenuItem exportUserList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TextBox txtOldLog;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox txtNewLog;
        private System.Windows.Forms.Button btnAddLog;
        private System.Windows.Forms.TabPage tabChangeHistory;
        private System.Windows.Forms.ListView listDeviceHistory;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.ColumnHeader columnHeader38;
        private System.Windows.Forms.ToolStripMenuItem manageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemShopAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportAddressWithAutoPosReport;
        private System.Windows.Forms.ToolStripMenuItem menuSyncTrackingServer;
        private System.Windows.Forms.ToolStripMenuItem menuSendEventPush;
        private System.Windows.Forms.ToolStripMenuItem menuTrackingStatics;
        private System.Windows.Forms.ToolStripMenuItem menuFindInvalidDeviceUser;
        private System.Windows.Forms.ToolStripMenuItem resetDeviceToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ToolStripMenuItem exportDeviceList;
        private System.Windows.Forms.ToolStripMenuItem installation정리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 가입자PushOff통계ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 관리자추가이벤트통계ToolStripMenuItem;
        private System.Windows.Forms.Button btnClearCache;
        private System.Windows.Forms.ListView listUserVoice;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    }
}