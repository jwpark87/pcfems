﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoonAdmin
{
    public partial class DateTimeSelectForm : Form
    {
        public DateTime StartTimeValue
        {
            get
            {
                return convertZeroTimeDate(startTime.Value);
            }
        }

        public DateTime EndTimeValue
        {
            get
            {
                return convertZeroTimeDate(endTime.Value);
            }
        }

        DateTime convertZeroTimeDate(DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, dateTime.Day);
        }


        public DateTimeSelectForm()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Close();
            DialogResult = DialogResult.OK;
        }

        private void startTime_ValueChanged(object sender, EventArgs e)
        {
            endTime.Value = startTime.Value;
        }
    }
}
