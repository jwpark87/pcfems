﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;

namespace JoonAdmin
{
    public partial class TrackingStaticsForm : Form
    {
        public TrackingStaticsForm()
        {
            InitializeComponent();
        }

        private DateTime trimDateTime(DateTime value)
        {
            DateTime time = new DateTime(value.Year,
                    value.Month,
                    value.Day,
                    value.Hour,
                    value.Minute,
                    0, DateTimeKind.Local);
            return time;
        }

        private async void btnQuery_Click(object sender, EventArgs e)
        {
            int[] validGpsType = new int[] { 1, 7, 8, 9 };
            Dictionary<int, int> trackingCount = new Dictionary<int, int>();
            foreach (int gpsType in validGpsType)
            {
                trackingCount[gpsType] = 0;
            }

            List<RestServer> trackingServers = await ServiceList.getServerWithType("tracking");
            trackingServers.Add(ServiceList.current);

            foreach (RestServer server in trackingServers)
            {
                foreach (int gpsType in validGpsType)
                {
                    RestQuery query = new RestQuery("Tracking");
                    query.greatherThen("createdAt", trimDateTime(startDateTimePicker.Value));
                    query.lessThen("createdAt", trimDateTime(endDateTimePicker.Value));
                    query.equalTo("gpsType", gpsType);
                    int count = await RestAPI.count(query, true, server);
                    writeLog("[" + gpsType + "] count:" + count);
                    trackingCount[gpsType] = trackingCount[gpsType] + count;
                }
            }

            writeLog("complete");
            foreach (int gpsType in validGpsType)
            {
                writeLog("[" + gpsType + "] count:" + trackingCount[gpsType]);
            }
        }

        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }
    }
}
