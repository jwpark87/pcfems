﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;

namespace JoonAdmin
{
    public partial class ResetDeviceForm : Form
    {
        public ResetDeviceForm()
        {
            InitializeComponent();
        }

        private async void btnReset_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("단말에 리셋 메시지를 보냅니다. 사용자 단말에 리셋 메시지가 표시되고 자동 리셋 됩니다.", "단말 리셋", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Enabled = false;
                Cursor.Current = Cursors.WaitCursor;
                try
                {
                    Dictionary<string, object> dic = new Dictionary<string, object>();
                    dic.Add("action", "reset");
                    dic.Add("phoneNumber", txtPhoneNumber.Text);
                    await RestAPI.callFunctions("adminFunc", dic);
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    this.Enabled = true;
                    Cursor.Current = Cursors.Default;
                }
            }
        }
    }
}
