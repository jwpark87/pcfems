﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using JoonLib;
using Parse;
namespace JoonAdmin
{
    public partial class PushEventForm : Form
    {
        protected DateTime _lastDate;
        protected string _lastObjectId;
        protected Dictionary<string, object> _pushData;
        protected RestServer _server;
        protected bool _isStop;

        public PushEventForm()
        {
            InitializeComponent();
            listDeviceType.Text = "All";
            listTextType.Text = "Text";
            _server = ServiceList.current;
            // _server = new RestServer("dev", "T1XctG6y8gEPTNFhHlDDpuN3K7f5frVNRy5ML40s", "d4Kr6VeBcwPO1k9lKF0vPXNHdJ3rrWPFCxtxMx97", "ihOK87krWpUDqMFgZ6OFHqHk9hwwu0QkwCDLGn9f", "XHy6fzNmF0z9wUHwpmCGhIkvQiuC3WtMycv2F2p1");
            readLastDate();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _isStop = true;
        }

        async private void btnStart_Click(object sender, EventArgs e)
        {
            _isStop = false;
            btnStart.Enabled = false;
            if (listTextType.Text == "Text")
            {
                _pushData = new Dictionary<string, object>();
                _pushData.Add("alert", textPushData.Text);
            }
            else
            {
                Dictionary<object, object> json = JsonDeserializer.parse(textPushData.Text);
                _pushData = new Dictionary<string, object>();
                foreach(KeyValuePair<object, object> keyValue in json)
                {
                    _pushData.Add(keyValue.Key.ToString(), keyValue.Value);
                }
            }
            while (!_isStop)
            {
                writeLog("user query - " + _lastDate);
                writeLog(DateTime.Now.ToLongTimeString());
                RestQuery query = nextUserQuery();
                List<ParseObject> userList = await RestAPI.get(query, true, _server);
                writeLog("user list - " + userList.Count);
                if (userList.Count > 0)
                {
                    writeLastDate(userList.Last());
                }
                else
                {
                    break;
                }
                List<ParseObject> sendObjects = new List<ParseObject>();
                foreach (ParseObject user in userList)
                {
                    List<ParseObject> installations = await RestAPI.get(userInstallationQuery(user), true, _server);
                    writeLog("installation query - " + installations.Count);
                    if (installations.Count > 0)
                    {
                        sendObjects.Add(installations[0]);
                    }
                    if (_isStop)
                        break;
                }
                writeLog("send push " + sendObjects.Count);
                writeLog(DateTime.Now.ToLongTimeString());
                sendPushWithInstallations(sendObjects);
            }
            _isStop = true;
            btnStart.Enabled = true;
        }


        void readLastDate()
        {
            string textLastDate = "";
            try {
                textLastDate = File.ReadAllText("push_lastdate.txt");
            } catch (Exception exp)
            {

            }
            string[] components = textLastDate.Split(',');
            if (components.Length == 2)
            {
                _lastDate = new DateTime(long.Parse(components[0]));
                _lastObjectId = components[1];
            }
            else
            {
                _lastDate = new DateTime(2014, 1, 1);
                _lastObjectId = null;
            }
        }


        void writeLastDate(ParseObject lastObject)
        {
            _lastDate = lastObject.Get<DateTime>("createdAt");
            _lastObjectId = lastObject.ObjectId;
            File.WriteAllText("push_lastdate.txt", "" + _lastDate.Ticks + "," + _lastObjectId);
        }

        RestQuery nextUserQuery() {
            RestQuery query = new RestQuery("_User");
            query.equalTo("type", "manager");
            if (textPhoneNumbers.Text.Length > 0)
                query.containedIn("phoneNumber", textPhoneNumbers.Text.Split(','));
            query.orderTo("createdAt");
            query.greatherThen("createdAt", _lastDate);
            if (_lastObjectId != null)
                query.notEqualTo("objectId", _lastObjectId);
            query.limit(100);
            return query;
        }

        RestQuery userInstallationQuery(ParseObject user)
        {
            List<Dictionary<string, object>> orQueries = new List<Dictionary<string, object>>();
            RestQuery query = new RestQuery("_Installation");
            query.equalTo("user", user);
            query.notEqualTo("disablePush", true);
            query.orderTo("-createdAt");
            query.limit(1);
            if (listDeviceType.Text != "All")
                query.equalTo("deviceType", listDeviceType.Text);
            return query;
        }


        RestQuery userListInstallationQuery(List<ParseObject> users)
        {
            RestQuery query = new RestQuery("_Installation");
            query.equalTo("$or", users.ToArray());
            //query.containedIn("user", users.ToArray());
            //query.orderTo("user,-createdAt");
            query.limit(1000);
            if (listDeviceType.Text != "All")
                query.equalTo("deviceType", listDeviceType.Text);
            return query;
        }

        async void sendPushWithInstallations(List<ParseObject> installations)
        {
            if (installations.Count == 0)
                return;
            List<String> installationIds = new List<String>();
            foreach (ParseObject installationObj in installations)
            {
                installationIds.Add(installationObj.ObjectId);
            }

            RestQuery query = new RestQuery();
            query.containedIn("objectId", installationIds.ToArray());
            await RestAPI.pushWithQuery(query, _pushData, _server);
        }

        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _lastDate = new DateTime(2014, 1, 1);
            _lastObjectId = null;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
