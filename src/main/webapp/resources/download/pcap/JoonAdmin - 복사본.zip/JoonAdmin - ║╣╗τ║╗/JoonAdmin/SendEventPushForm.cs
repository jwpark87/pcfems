﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JoonLib;

namespace JoonAdmin
{
    public partial class SendEventPushForm : Form
    {
        public SendEventPushForm()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            sendPush();
        }

        protected async void sendPush()
        {
            string result = await RestAPI.callFunctions("sendPush", new Dictionary<string, object> { { "message", txtMessage.Text } }, ServiceList.getServerWithName("JooN"));
            writeLog(result);
            try
            {
                Dictionary<object, object> dicContent = JsonDeserializer.parse(result);
                Dictionary<string, object> dicResult = (Dictionary < string, object>)dicContent["result"];
                if ((long)dicResult["count"] == 0)
                {
                    writeLog("complete");
                }
                else
                {
                    AsyncUtils.DelayFor(sendPush, TimeSpan.FromMilliseconds(100));
                }

            }
            catch (Exception exp)
            {
                writeLog(exp.ToString());
            }
        }


        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }
    }
}
