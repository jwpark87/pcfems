﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;
using System.Xml.Linq;
using System.Web.Script.Serialization;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Permissions;



namespace JoonAdmin
{
    [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
    [System.Runtime.InteropServices.ComVisibleAttribute(true)]

    public partial class MapSelectView : Form
    {
        string m_address;
        double m_lat;
        double m_lng;

        public delegate void didAddressSelected(string address, double lat, double lng);

        didAddressSelected m_delegate;

        public MapSelectView(string address, double lat, double lng, didAddressSelected receiver)
        {
            m_address = address;
            m_lat = lat;
            m_lng = lng;
            m_delegate = receiver;
            InitializeComponent();
        }

        private void MapSelectView_Load(object sender, EventArgs e)
        {
            try
            {
                string url = "http://tmarkadminconsole.parseapp.com/selectmap.html";
                this.webBrowser.Navigate(url);
                webBrowser.ObjectForScripting = this;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public static Task<string> searchAddress(string query)
        {
            Task<string> task = new Task<string>(() =>
            {
                var client = new RestClient("http://apis.daum.net");
                var request = new RestRequest(string.Format("local/geo/addr2coord?apikey=e8fcd253d08186481f10dbe8bf8f10716d0fa689&output=json&q={0}", query), Method.GET);
                RestResponse response = (RestResponse)client.Execute(request);
                string content = response.Content; // raw content as string
                return content;
            });
            task.Start();
            return task;
        }

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string content = await searchAddress(textAddress.Text);
                var jss = new JavaScriptSerializer();
                Dictionary<string, object> temp = jss.Deserialize<Dictionary<string, object>>(content);
                temp = (Dictionary<string, object>)temp["channel"];
                listSearch.Items.Clear();
                if (Int32.Parse((string)temp["result"]) > 0)
                {
                    System.Collections.ArrayList results = (System.Collections.ArrayList)temp["item"];
                    foreach (Dictionary<string, object> address in results)
                    {
                        ListViewItem item = new ListViewItem((string)address["title"]);
                        item.Tag = address;
                        listSearch.Items.Add(item);
                    }
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(null, null);
            }
        }

        private void listSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listSearch.SelectedItems.Count > 0)
            {
                Dictionary<string, object> address = (Dictionary<string, object>)listSearch.SelectedItems[0].Tag;
                var lat = address["lat"];
                var lng = address["lng"];
                try
                {
                    webBrowser.Document.InvokeScript("moveToCenter", new Object[]{lat, lng});
                    m_lat = decimal.ToDouble((decimal)lat);
                    m_lng = decimal.ToDouble((decimal)lng);
                    textCoord.Text = string.Format("{0}, {1}", m_lat, m_lng);
                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }
            }
        }

        public void didPositionChanged(object lat, object lng)
        {
            textCoord.Text = string.Format("{0}, {1}", lat, lng);
            m_lat = (double)lat;
            m_lng = (double)lng;
        }

        private void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            textCoord.Text = string.Format("{0}, {1}", m_lat, m_lng);
            textAddress.Text = m_address;
            if (m_lat != 0.0 && m_lng != 0.0)
            {
                webBrowser.Document.InvokeScript("moveToCenter", new Object[] { m_lat, m_lng });
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            m_delegate(textAddress.Text, m_lat, m_lng);
            this.Close();
        }
    }
}
