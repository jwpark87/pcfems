﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    class UserVoice
    {
        public List<ParseObject> list;

        public async Task<ParseObject> add(string searchNumber)
        {
            ParseObject voiceObj = new ParseObject("UserVoice");
            voiceObj.Add("searchNumber", searchNumber);
            voiceObj.Add("ip", LoginInfo.ip);
            voiceObj.Add("mac", LoginInfo.mac);
            voiceObj.Add("adminname", LoginInfo.username);
            voiceObj = await RestAPI.createNew(voiceObj, ServiceList.current.adminServer);
            list.Insert(0, voiceObj);
            return voiceObj;
        }


        public async void refresh()
        {
            RestQuery query = new RestQuery();
            query.equalTo("adminname", LoginInfo.username);
            query.orderTo("-createdAt");
            list = await RestAPI.get("UserVoice", query, true, true, ServiceList.current.adminServer);
        }


        public async void addComment(ParseObject userVoice, string comment)
        {
            userVoice["comment"] = comment;
            await RestAPI.update(userVoice, null, ServiceList.current.adminServer);
        }
    }
}



