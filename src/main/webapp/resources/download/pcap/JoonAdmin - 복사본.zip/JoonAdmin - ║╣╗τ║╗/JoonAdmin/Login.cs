﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using Parse;
using JoonLib;


namespace JoonAdmin
{
    public partial class Login : Form
    {
        bool m_login = false;
        ParseObject m_adminUserObj = null;

        public delegate void didLogin();
        public didLogin loginEventHandlers;

        class ParseServiceItem
        {
            private readonly ServiceServer m_service;

            public ParseServiceItem(ServiceServer _service)
            {
                m_service = _service;
            }

            public ServiceServer service { get { return m_service; } }

            public override string ToString()
            {
                return m_service.name;
            }
        };


        public Login()
        {
            InitializeComponent();
        }
        

        private void Login_Load(object sender, EventArgs e)
        {
            serviceList.Items.Clear();
            foreach (ServiceServer service in ServiceList.list)
            {
                serviceList.Items.Add(new ParseServiceItem(service));                
            }
            serviceList.SelectedIndex = 0;
            checkAutoLogin.Checked = Properties.Settings.Default.autoLogin;
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            var oldCursor = this.Cursor;
            this.Cursor = Cursors.WaitCursor;
            this.Enabled = false;
            ServiceList.current = ((ParseServiceItem)serviceList.SelectedItem).service;
            Application.OpenForms[0].Text = ServiceList.current.name;
            try
            {
                //string sessionToken = await RestAPI.login(textEmail.Text, textPassword.Text);
                //await ParseUser.BecomeAsync(sessionToken);

                ParseClient.Initialize(ServiceList.current.adminServer.appId, ServiceList.current.adminServer.appKey);
                if (!await checkLoginAccessCount(textEmail.Text))
                {
                    return;
                }

                await ParseUser.LogInAsync(textEmail.Text, textPassword.Text);
                if (checkAutoLogin.Checked)
                {
                    Properties.Settings.Default.service = SecureUserString.EncryptString(SecureUserString.ToSecureString(serviceList.Text));
                    Properties.Settings.Default.email = SecureUserString.EncryptString(SecureUserString.ToSecureString(textEmail.Text));
                    Properties.Settings.Default.password = SecureUserString.EncryptString(SecureUserString.ToSecureString(textPassword.Text));
                }
                Properties.Settings.Default.autoLogin = checkAutoLogin.Checked;
                Properties.Settings.Default.Save();
                m_login = true;
                updateLoginInfo(textEmail.Text, true);
                this.Close();
            }
            catch (Exception exp)
            {
                MessageBox.Show("로그인에 실패 하였습니다. 이메일 혹은 비밀번호를 확인 해주세요.\n" + exp.Message, "실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
                updateLoginInfo(textEmail.Text, false);
            }
            finally {
                this.Cursor = oldCursor;
                this.Enabled = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Login_Shown(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.autoLogin)
            {
                serviceList.Text = SecureUserString.ToInsecureString(SecureUserString.DecryptString(Properties.Settings.Default.service));
                textEmail.Text = SecureUserString.ToInsecureString(SecureUserString.DecryptString(Properties.Settings.Default.email));
                textPassword.Text = SecureUserString.ToInsecureString(SecureUserString.DecryptString(Properties.Settings.Default.password));
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!m_login)
                Application.Exit();
        }



        async void updateLoginInfo(string username, Boolean success)
        {
            string ip = "";
            Dictionary<object, object> dicIp = await RestAPI.getWithUrl("http://smobileremoteip.appspot.com", "/");
            if (dicIp != null)
            {
                ip = (string)dicIp["host"];
            }
            ParseObject log = ParseObject.Create("AdminLog");
            log.Add("name", username);
            log.Add("mac", GetMACAddress());
            log.Add("ip", ip);
            log.Add("success", success);
            await RestAPI.createNew(log, ServiceList.current.adminServer);

            LoginInfo.username = log.GetString("name");
            LoginInfo.ip = log.GetString("ip");
            LoginInfo.mac = log.GetString("mac");
            
            LoginInfo.user = m_adminUserObj;

            int failedCount = 0;
            if (m_adminUserObj.ContainsKey("failedCount"))
                failedCount = m_adminUserObj.Get<int>("failedCount");
            if (success)
            {
                failedCount = 0;
                if (loginEventHandlers != null)
                    loginEventHandlers();   
            }
            else
            {
                ++failedCount;
            }
            m_adminUserObj["failedCount"] = failedCount;
            await RestAPI.update(m_adminUserObj, new Dictionary<string, object> { { "failedCount", failedCount } }.ToList(), ServiceList.current.adminServer);
        }


        async Task<bool> checkLoginAccessCount(string username)
        {
            m_adminUserObj = await getLoginUser(username);
            if (m_adminUserObj == null)
            {
                MessageBox.Show("등록되지 않은 사용자 입니다. 정보관리책임자에게 문의하세요.");
                return false;
            }

            int failedCount = 0;
            if (m_adminUserObj.ContainsKey("failedCount"))
                failedCount = m_adminUserObj.Get<int>("failedCount");

            if (failedCount < 3)
                return true;

            MessageBox.Show("비밀번호를 3회 이상 잘못 입력하셨습니다. 정보관리책임자에게 문의하세요.");
            return false;
        }


        async Task<ParseObject> getLoginUser(string username)
        {
            RestQuery query = new RestQuery();
            query.equalTo("username", username);
            List<ParseObject> findResults = await RestAPI.get("_User", query, true, true, ServiceList.current.adminServer);
            if (findResults == null || findResults.Count == 0)
            {
                return null;
            }
            else
            {
                return findResults[0];
            }
        }


        static string GetMACAddress()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            String sMacAddress = string.Empty;
            foreach (NetworkInterface adapter in nics)
            {
                if (sMacAddress == String.Empty)// only return MAC Address from first card  
                {
                    //IPInterfaceProperties properties = adapter.GetIPProperties(); Line is not required
                    sMacAddress = adapter.GetPhysicalAddress().ToString();
                }
            } return sMacAddress;
        }

        private void Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt && e.KeyCode == Keys.F4)
                e.Handled = true;
        }
    }

    public class LoginInfo
    {
        public static string username;
        public static string ip;
        public static string mac;
        public static ParseObject user;
    }

}
