﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace JoonLib
{
    public static class StringExtensions
    {
        public static string ToPhoneNumber(this string value)
        {
            try
            {
                if (value.Length == 0)
                    return "번호없음";
                return string.Format("{0:000-0000-0000}", Int64.Parse(value));
            }
            catch(Exception exp)
            {
                return value;
            }
        }

        public static string ToIMEI(this string value)
        {
            try {
                if (value.Length == 0)
                    return "번호없음";
                return string.Format("{0:0000-0000-0000-000}", Int64.Parse(value));
            }
            catch (Exception exp)
            {
                return value;
            }
        }
    }
}
