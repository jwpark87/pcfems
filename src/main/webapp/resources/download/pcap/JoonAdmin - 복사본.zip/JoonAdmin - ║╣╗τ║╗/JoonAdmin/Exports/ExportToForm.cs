﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Parse;
using JoonLib;
using System.IO;

namespace JoonAdmin.Exports
{
    public abstract partial class ExportToForm : Form
    {
        public ExportToForm()
        {
            InitializeComponent();
        }


        protected Excel.Application _xlApp = null;
        protected Excel.Workbook _xlWorkBook = null;
        protected Excel.Worksheet _xlWorkSheet = null;
        protected Excel.Range _range = null;
        protected int _writeRowIndex;
        protected string _lastObjectId;
        protected bool _bStop;
        protected DateTime _lastDate;
        protected bool _isNewExcelFile;

        private async void startExport()
        {
            try
            {
                string filePath = getFilePath();
                _xlApp = new Excel.Application();
                if (File.Exists(filePath))
                {
                    _xlWorkBook = _xlApp.Workbooks.Open(filePath);
                    _isNewExcelFile = false;
                }
                else
                {
                    _xlWorkBook = _xlApp.Workbooks.Add();
                    _isNewExcelFile = true;
                }
                _xlWorkSheet = (Excel.Worksheet)_xlWorkBook.Worksheets.get_Item(1);
                _xlWorkSheet.Columns.ClearFormats();
                _xlWorkSheet.Rows.ClearFormats();
                _range = _xlWorkSheet.UsedRange;
                
                int startRow = _range.Rows.Count - 1;
                if (startRow < 1)
                {
                    startRow = 0;
                    _lastDate = new DateTime(2014, 7, 10);
                }
                else
                {
                    _lastDate = Convert.ChangeType((_range.Cells[startRow, 1] as Excel.Range).Value2, typeof(DateTime));
                }
                writeLog("start query " + _lastDate.ToString());
                _writeRowIndex = startRow + 1;
                _lastObjectId = "";
                _bStop = false;
                didStartExport();
                do
                {
                    if (!await doExport())
                        break;

                } while (!_bStop);
                didEndExport();
            }
            catch (Exception exp)
            {
                writeLog(exp.Message);
            }
            finally
            {
                stopExport();
            }
        }

        protected virtual void didStartExport()
        {

        }

        protected abstract string getFilePath();
        protected abstract RestQuery getQuery();
        protected abstract void didGetParseObject(ParseObject pfObject);
        protected async virtual Task<int> didGetParseObjectAsync(ParseObject pfObject)
        {
            return 1;
        }


        protected virtual bool shouldInsertNewObject(ParseObject pfObject)
        {
            return true;
        }


        protected async Task<bool> doExport()
        {
            RestQuery query = getQuery();
            List<ParseObject> results = await RestAPI.get(query);
            if (results.Count == 0 || results.Last().ObjectId == _lastObjectId)
                return false;

            writeLog("query count " + results.Count());
            writeLog("query date " + results.ElementAt(0).CreatedAt);

            foreach (ParseObject pfObject in results)
            {
                try
                {
                    if (!shouldInsertNewObject(pfObject))
                        continue;
                    insertNewRow();
                    didGetParseObject(pfObject);
                    await didGetParseObjectAsync(pfObject);
                }
                catch (Exception e)
                {
                    writeLog("Exception " + e.Message);
                }
                ++_writeRowIndex;
                if (_bStop)
                    break;
            }
            _lastObjectId = results.Last().ObjectId;
            _lastDate = results.Last().Get<DateTime>("createdAt");
            return true;
        }


        protected void insertNewRow()
        {
            if (_xlWorkSheet.Cells.Rows.Count <= _writeRowIndex)
            {
                _xlWorkSheet.Cells.Insert();
            }
        }

        
        private void didEndExport()
        {
            string filePath = getFilePath();
            if (!_isNewExcelFile)
                _xlWorkBook.Save();
            else
                _xlWorkBook.SaveAs(filePath);

            writeLog("complete");
            MessageBox.Show("야호~ 완료 되었습니다.");
        }
        
        private void stopExport()
        {
            if (_xlWorkBook != null)
            {
                try
                {
                    _xlWorkBook.Close(!_isNewExcelFile, null, null);
                } catch (Exception exp)
                {

                }
                _xlWorkBook = null;
            }
            if (_xlApp != null)
                _xlApp.Quit();

            releaseObject(_xlWorkSheet);
            releaseObject(_xlWorkBook);
            releaseObject(_xlApp);
        }


        static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }

        void complete()
        {
            writeLog("complete");
            //_fs.Close();
        }

        protected void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            _bStop = true;
        }

        private void ExportToForm_Shown(object sender, EventArgs e)
        {
            startExport();
        }
    }
}
