﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoonLib
{
    public static class ObjectExtensions
    {
        public static DateTime ToDateTime(this object obj)
        {
            if (obj.GetType() == typeof(string))
                return DateTime.Parse((string)obj);
            return (DateTime)obj;
        }
    }
}
