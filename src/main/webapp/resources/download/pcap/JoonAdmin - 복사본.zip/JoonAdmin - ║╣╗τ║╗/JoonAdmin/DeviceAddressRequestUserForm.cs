﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using JoonLib;


namespace JoonAdmin
{
    public partial class DeviceAddressRequestUserForm : Form
    {
        ParseObject _device;
        ParseObject _memo;

        public DeviceAddressRequestUserForm(ParseObject device)
        {
            _device = device;
            InitializeComponent();
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            try {
                ActivityIndicator.show("저장중입니다.", this);
                this.Enabled = false;
                bool isNewObject = false;
                if (_memo == null)
                {
                    _memo = new ParseObject("JoonAddressMemo");
                    // _memo.ACL = new ParseACL();
                    isNewObject = true;
                    _memo.Add("device", _device);
                    _memo.Add("devicePhoneNumber", _device.GetString("phoneNumber"));
                }
                _memo.SetString("name", txtName.Text);
                _memo.SetString("phoneNumber", txtPhoneNumber.Text);
                _memo.SetString("memo", txtMemo.Text);
                if (isNewObject)
                {
                    await RestAPI.createNew(_memo);
                }
                else
                {
                    await RestAPI.update(_memo);
                }
                this.Close();
            }
            catch (Exception exp)
            {
                MessageBox.Show("저장에 실패하였습니다. " + exp.Message, "저장 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ActivityIndicator.hide();
                this.Enabled = true;
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void DeviceAddressRequestUserForm_Shown(object sender, EventArgs e)
        {
            _memo = null;
            txtName.Text = "";
            txtPhoneNumber.Text = "";
            txtMemo.Text = "";
            RestQuery query = new RestQuery("JoonAddressMemo");
            query.equalTo("device", _device);
            List<ParseObject> memos = await RestAPI.get(query);
            if (memos.Count > 0)
            {
                _memo = memos[0];
                txtName.Text = _memo.GetString("name");
                txtPhoneNumber.Text = _memo.GetString("phoneNumber");
                txtMemo.Text = _memo.GetString("memo");
            }
        }
    }
}
