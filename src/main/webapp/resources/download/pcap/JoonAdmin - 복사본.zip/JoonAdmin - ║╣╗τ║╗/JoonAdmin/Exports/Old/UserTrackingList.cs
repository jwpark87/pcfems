﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    public partial class UserTrackingList : Form
    {
        bool m_bStop = false;

        public UserTrackingList()
        {
            InitializeComponent();
        }

        private void UserTrackingList_Load_1(object sender, EventArgs e)
        {
            AsyncUtils.DelayFor(queryDevices, TimeSpan.FromMilliseconds(500));
            writeLog("open database");
        }

        private async void queryDevices()
        {

            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            Excel.Range range = null;

            int[] trackingTypes = new int[] { 3, 4, 5 };

            try
            {
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Open(Application.StartupPath + @"/tracking.xlsx");
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Columns.ClearFormats();
                xlWorkSheet.Rows.ClearFormats();
                range = xlWorkSheet.UsedRange;



                Excel.Worksheet[] trackingWorkSheet = new Excel.Worksheet[trackingTypes.Length];
                for (int i = 0; i < trackingTypes.Length; ++i)
                {
                    trackingWorkSheet[i] = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(i + 1);
                    trackingWorkSheet[i].Columns.ClearFormats();
                    trackingWorkSheet[i].Rows.ClearFormats();
                }


                DateTime lastDate;
                int startRow = range.Rows.Count - 1;
                startRow -= 10;
                if (startRow < 1)
                {
                    startRow = 0;
                    lastDate = new DateTime(2014, 7, 10);
                }
                else
                {
                    lastDate = Convert.ChangeType((range.Cells[startRow, 1] as Excel.Range).Value2, typeof(DateTime));
                }
                writeLog("start query " + lastDate.ToString());

                string lastObjectId = "";
                int writeRowIndex = startRow + 1;
                int writeCount = 0;
                do
                {
                    Dictionary<string, object> parameters = new Dictionary<string, object>();
                    string conditionFormat = "{{\"type\":\"device\", \"createdAt\":{{\"$gt\":{{\"__type\":\"Date\", \"iso\":\"{0}\"}}}}}}";
                    parameters.Add("where", string.Format(conditionFormat, lastDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")));
                    parameters.Add("order", "createdAt");
                    parameters.Add("limit", 1000);

                    List<ParseObject> deviceResults = await RestAPI.get("_User", parameters);
                    if (deviceResults.Count == 0 || deviceResults.Last().ObjectId == lastObjectId)
                        break;

                    writeLog("devices count " + deviceResults.Count());
                    writeLog("query date " + deviceResults.ElementAt(0).CreatedAt);

                    foreach (ParseObject device in deviceResults)
                    {
                        writeLog(device.Get<DateTime>("createdAt").ToLocalTime() + ", " + device.Get<string>("phoneNumber"));

                        for (int i = 0; i < trackingTypes.Length; ++i)
                        {
                            if (trackingWorkSheet[i].Cells.Rows.Count <= writeRowIndex)
                            {
                                trackingWorkSheet[i].Cells.Insert();
                            }
                            trackingWorkSheet[i].Cells[writeRowIndex, 1].Value2 = device.Get<DateTime>("createdAt").ToLocalTime().ToString();
                            trackingWorkSheet[i].Cells[writeRowIndex, 2].NumberFormat = "@";
                            trackingWorkSheet[i].Cells[writeRowIndex, 2].Value2 = device.Get<string>("phoneNumber");
                        }
                        
                        {

                            RestServer trackingServer = ServiceList.current;
                            if (device.ContainsKey("trackingServer"))
                            {
                                Dictionary<string, object> dicTrackingServer = device.Get<Dictionary<string, object>>("trackingServer");
                                if (dicTrackingServer != null)
                                {
                                    string serverId = getSafeString(dicTrackingServer, "serverId");
                                    if (serverId.Length > 0)
                                    {
                                        trackingServer = await ServiceList.getServerWithId(serverId);   
                                    }
                                    else
                                    {
                                        trackingServer = new RestServer(null, (string)dicTrackingServer["id"], null, (string)dicTrackingServer["key"], null);
                                    }
                                }
                            }

                            DateTime startDate = new DateTime(2015, 6, 1);
                            DateTime endDate = new DateTime(2015, 6, 30);

                            int sheetIndex = 0;
                            ParseObject deviceObject = device.Get<ParseObject>("device");
                            if (deviceObject != null)
                            {
                                foreach (int trackingType in trackingTypes)
                                {
                                    Dictionary<string, object> searchParameters = new Dictionary<string, object>();
                                    var deviceSearchField = string.Format("{{\"__type\":\"Pointer\",\"className\":\"Device\",\"objectId\":\"{0}\"}}", deviceObject.ObjectId);
                                    searchParameters.Add("limit", "1000");
                                    searchParameters.Add("order", "createdAt");
                                    searchParameters.Add("where", string.Format("{{\"device\":{0}, \"type\":{2}, \"createdAt\":{{\"$gte\":{{\"__type\":\"Date\", \"iso\":\"{1}\"}}, \"$lt\":{{\"__type\":\"Date\", \"iso\":\"{3}\"}} }} }}", deviceSearchField,
                                        startDate.ToString("yyyy-MM-ddTHH:mm:ssZ"), trackingType,
                                        endDate.ToString("yyyy-MM-ddTHH:mm:ssZ")));
                                    IEnumerable<ParseObject> trackingList;
                                    trackingList = await RestAPI.get("Tracking", searchParameters, true, true, trackingServer);
                                    trackingWorkSheet[sheetIndex].Cells[writeRowIndex, 3].Value2 = trackingList.Count();
                                    int colIndex = 4;
                                    foreach (ParseObject tracking in trackingList)
                                    {
                                        trackingWorkSheet[sheetIndex].Cells[writeRowIndex, colIndex++].Value2 = tracking.Get<DateTime>("createdAt").ToLocalTime().ToString();
                                    }
                                    ++sheetIndex;
                                }
                            }
                        }
                        ++writeRowIndex;
                        ++writeCount;
                        if (writeCount % 100 == 0)
                        {
                            xlWorkBook.Save();
                        }
                        if (m_bStop)
                            break;
                    }
                    lastObjectId = deviceResults.Last().ObjectId;
                    lastDate = deviceResults.Last().Get<DateTime>("createdAt");
                } while (!m_bStop);
                xlWorkBook.Save();
                writeLog("complete");
                this.Close();
                MessageBox.Show("완료 되었습니다.");
            }
            catch (Exception exp)
            {
                writeLog(exp.Message);
            }
            finally
            {

                if (xlWorkBook != null)
                {
                    xlWorkBook.Save();
                    xlWorkBook.Close(true, null, null);
                }
                if (xlApp != null)
                    xlApp.Quit();

                releaseObject(xlWorkSheet);
                releaseObject(xlWorkBook);
                releaseObject(xlApp);
            }
        }



        static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }

        void complete()
        {
            writeLog("complete");
            //_fs.Close();
        }

        void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }

          private string getSafeString(Dictionary<string, object> obj, string key)
        {
            try
            {
                return (string)obj[key];
            }
            catch (Exception)
            {
                return "";
            }
        }

        private void btnStop_Click_1(object sender, EventArgs e)
        {
            m_bStop = true;
        }

    }
}

