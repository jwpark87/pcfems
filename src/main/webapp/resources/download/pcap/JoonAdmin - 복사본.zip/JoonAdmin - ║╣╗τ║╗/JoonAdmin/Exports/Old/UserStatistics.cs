﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Parse;
using JoonLib;

namespace JoonAdmin
{
    public partial class UserStatistics : Form
    {
        public UserStatistics()
        {
            InitializeComponent();
        }

        private void UserStatistics_Load(object sender, EventArgs e)
        {
            AsyncUtils.DelayFor(queryDevices, TimeSpan.FromMilliseconds(500));
            writeLog("open database");
        }


        private async void queryDevices() {
            
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            Excel.Range range = null;

            try
            {
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Open(Application.StartupPath + @"/users.xlsx");
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Columns.ClearFormats();
                xlWorkSheet.Rows.ClearFormats();
                range = xlWorkSheet.UsedRange;

                DateTime lastDate;
                int startRow = range.Rows.Count - 1;
                startRow -= 10;
                if (startRow < 1)
                {
                    startRow = 0;
                    lastDate = new DateTime(2014, 7, 10);
                }
                else
                {
                    lastDate = Convert.ChangeType((range.Cells[startRow, 1] as Excel.Range).Value2, typeof(DateTime));
                }
                writeLog("start query " + lastDate.ToString());

                string lastObjectId = "";
                int writeRowIndex = startRow + 1;
                do
                {
                    Dictionary<string, object> parameters = new Dictionary<string, object>();
                    string conditionFormat = "{{\"type\":\"device\", \"createdAt\":{{\"$gt\":{{\"__type\":\"Date\", \"iso\":\"{0}\"}}}}}}";
                    parameters.Add("where", string.Format(conditionFormat, lastDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")));
                    parameters.Add("order", "createdAt");
                    parameters.Add("limit", 1000);

                    List<ParseObject> deviceResults = await RestAPI.get("_User", parameters);
                    if (deviceResults.Count == 0 || deviceResults.Last().ObjectId == lastObjectId)
                        break;

                    writeLog("devices count " + deviceResults.Count());
                    writeLog("query date " + deviceResults.ElementAt(0).CreatedAt);

                    foreach (ParseObject device in deviceResults)
                    {
                        writeLog(device.Get<DateTime>("createdAt").ToLocalTime() + ", " + device.Get<string>("phoneNumber"));
                        if (xlWorkSheet.Cells.Rows.Count <= writeRowIndex)
                        {
                            xlWorkSheet.Cells.Insert();
                        }

                        xlWorkSheet.Cells[writeRowIndex, 1].Value2 = device.Get<DateTime>("createdAt").ToLocalTime().ToString();
                        xlWorkSheet.Cells[writeRowIndex, 2].NumberFormat = "@";
                        xlWorkSheet.Cells[writeRowIndex, 2].Value2 = device.Get<string>("phoneNumber");
                        
                        if (device.ContainsKey("managers"))
                        {
                            object[] managers = (object[])device["managers"];
                            if (managers != null)
                            {
                                int colIndex = 3;
                                foreach (string manager in managers)
                                {
                                    xlWorkSheet.Cells[writeRowIndex, colIndex].NumberFormat = "@";
                                    xlWorkSheet.Cells[writeRowIndex, colIndex].Value2 = manager;
                                    ++colIndex;
                                }
                            }
                        }
                        if (device.ContainsKey("model"))
                            xlWorkSheet.Cells[writeRowIndex, 7].Value2 = device.Get<string>("model");
                        else
                            xlWorkSheet.Cells[writeRowIndex, 7].Value2 = "joon1";
                        ++writeRowIndex;
                    }
                    lastObjectId = deviceResults.Last().ObjectId;
                    lastDate = deviceResults.Last().Get<DateTime>("createdAt");
                } while (true);
                xlWorkBook.Save();
                writeLog("complete");
                this.Close();
                MessageBox.Show("김부장님. 완료 되었습니다.");
            }
            catch (Exception exp)
            {
                writeLog(exp.Message);
            }
            finally
            {
                if (xlWorkBook != null)
                    xlWorkBook.Close(true, null, null);
                if (xlApp != null)
                    xlApp.Quit();

                releaseObject(xlWorkSheet);
                releaseObject(xlWorkBook);
                releaseObject(xlApp);
            }
        }

        static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        } 

        void complete()
        {
            writeLog("complete");
            //_fs.Close();
        }

        void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }
    }
}
