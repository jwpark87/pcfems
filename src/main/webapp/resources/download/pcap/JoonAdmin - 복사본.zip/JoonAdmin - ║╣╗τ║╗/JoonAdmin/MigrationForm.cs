﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;
using System.IO;
using JoonLib;

namespace JoonAdmin
{
    public partial class MigrationForm : Form
    {
        List<string> m_phoeNumbers = new List<string>();
        int m_processIndex = 0;

        public enum MigrationMode
        {
            CradleEvent,
            JooNManagers,
        };
        MigrationMode m_mode;

        public MigrationForm(MigrationMode mode = MigrationMode.CradleEvent)
        {
            m_mode = mode;
            InitializeComponent();
        }

        private void MigrationForm_Load(object sender, EventArgs e)
        {

        }

        private void MigrationForm_Shown(object sender, EventArgs e)
        {
            if (m_mode == MigrationMode.CradleEvent)
            {
                /*
                StreamReader sr = new StreamReader(@"D:\shared\cradleevent.txt", Encoding.UTF8);
                int i = 1;
                while (!sr.EndOfStream)
                {
                    string s = sr.ReadLine();
                    s = s.Replace("-", "");
                    s = s.Replace(" ", "");
                    m_phoeNumbers.Add(s);
                }
                m_processIndex = 0;
                cradleUserEventUpdate();
                 */
                getCradleAcceptUserList();
            }

            else if (m_mode == MigrationMode.JooNManagers)
            {
                getDeviceUserWithJoonContact();
            }
        }



        private async void getCradleAcceptUserList()
        {
            DateTime lastDate = new DateTime(2014, 7, 1);

            while (true)
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                string conditionFormat = "{{\"cradleEvent\":true, \"createdAt\":{{\"$gte\":{{\"__type\":\"Date\", \"iso\":\"{0}\"}}}}}}";
                parameters.Add("where", string.Format(conditionFormat, lastDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")));
                parameters.Add("order", "createdAt");
                parameters.Add("include", "device");
                parameters.Add("limit", 1000);
                List<ParseObject> list = await RestAPI.get("DeviceData", parameters);
                if (list.Count <= 1)
                    break;
                foreach (ParseObject deviceData in list)
                {
                    if (!deviceData.ContainsKey("device"))
                        continue;
                    ParseObject device = deviceData.Get<ParseObject>("device");
                    m_phoeNumbers.Add(device.Get<string>("phoneNumber"));
                }
                lastDate = list.Last().Get<DateTime>("createdAt");
            }

            m_processIndex = 0;
            cradleUserEventUpdate();
        }


        class ManagerWithJoonDevice
        {
            Dictionary<string, Dictionary<string, List<ParseObject>>> m_list = new Dictionary<string, Dictionary<string, List<ParseObject>>>();
            System.IO.StreamWriter _fs = new System.IO.StreamWriter(@"D:\shared\joonmanagers.csv", true);

            public void addDevice(List<ParseObject> managers, ParseObject device)
            {
                if (managers.Count == 0)
                    return;

                Dictionary<string, List<ParseObject>> managerItem = getManagerItem(managers);
                foreach (ParseObject manager in managers)
                {
                    addUnique(managerItem["managers"], manager);
                }
                addUnique(managerItem["devices"], device);

                
            }

            Dictionary<string, List<ParseObject>> getManagerItem(List<ParseObject> managers)
            {
                string phoneNumber;
                foreach (ParseObject manager in managers)
                {
                    phoneNumber = (string)manager["phoneNumber"];
                    if (m_list.ContainsKey(phoneNumber))
                        return m_list[phoneNumber];
                }

                phoneNumber = (string)managers[0]["phoneNumber"];
                Dictionary<string, List<ParseObject>> managerItem = new Dictionary<string, List<ParseObject>> ();
                managerItem.Add("managers", new List<ParseObject>());
                managerItem.Add("devices", new List<ParseObject>());
                m_list.Add(phoneNumber, managerItem);
                return managerItem;
            }

            void addUnique(List<ParseObject> list, ParseObject obj)
            {
                foreach (ParseObject oldObj in list)
                {
                    if (oldObj.ObjectId == obj.ObjectId)
                        return;
                }
                list.Add(obj);
            }

            public void dump()
            {
                foreach (KeyValuePair<string, Dictionary<string, List<ParseObject>>> keyValue in m_list)
                {
                    List<ParseObject> managers = keyValue.Value["managers"];
                    List<ParseObject> devices = keyValue.Value["devices"];
                    
                    foreach (ParseObject manager in managers)
                    {
                        _fs.Write(manager.Get<string>("phoneNumber"));
                        _fs.Write(", ");
                    }

                    for (int i = managers.Count; i < 4; ++i)
                    {
                        _fs.Write(", ");
                    }

                    foreach (ParseObject device in devices)
                    {
                        _fs.Write(device.Get<string>("phoneNumber"));
                        _fs.Write(", ");
                    }
                    _fs.WriteLine();
                }
                _fs.Close();
            }
        }



        async void getDeviceUserWithJoonContact()
        {
            ManagerWithJoonDevice findList = new ManagerWithJoonDevice();
            DateTime lastDate = new DateTime(2014, 7, 1);
            int readCount = 0;

            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                string conditionFormat = "{{\"joon\":true, \"createdAt\":{{\"$gte\":{{\"__type\":\"Date\", \"iso\":\"{0}\"}}}}}}";
                parameters.Add("where", string.Format(conditionFormat, lastDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")));
                parameters.Add("order", "createdAt");
                parameters.Add("limit", 1000);
                while (true)
                {
                    List<ParseObject> contacts = await RestAPI.get("Contact", parameters);
                    if (contacts.Count == 0)
                        break;

                    foreach (ParseObject contact in contacts)
                    {
                        lastDate = contact.Get<DateTime>("createdAt");
                        if (!contact.ContainsKey("device"))
                            continue;
                        ParseObject device = (ParseObject)contact["device"];
                        ParseObject deviceUser = await getDeviceUserWithId(device.ObjectId);
                        if (deviceUser != null)
                        {
                            List<ParseObject> managerUsers = await getManagerUsers(deviceUser);
                            managerUsers.Sort(delegate(ParseObject a, ParseObject b)
                            {
                                string phoneNumberA = (string)a["phoneNumber"];
                                string phoneNumberB = (string)b["phoneNumber"];
                                return phoneNumberA.CompareTo(phoneNumberB);
                            });

                            findList.addDevice(managerUsers, deviceUser);
                            ++readCount;
                            textLog.AppendText(string.Format("[{0}, {1}]", readCount, lastDate) + (string)deviceUser["phoneNumber"] + "\n");
                        }
                    }
                    parameters["where"] = string.Format(conditionFormat, lastDate.ToString("yyyy-MM-ddTHH:mm:ssZ"));
                    textLog.AppendText("Next\n");
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                textLog.AppendText("Start Dump...\n");
                findList.dump();
                textLog.AppendText("Complete\n");
            }
        }


        async Task<ParseObject> getDeviceUser(string phoneNumber)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            string condition = string.Format("{{\"type\":\"device\", \"phoneNumber\":\"{0}\"}}", phoneNumber);
            parameters.Add("where", condition);
            parameters.Add("order", "-createdAt");
            List<ParseObject> users = await RestAPI.get("_User", parameters);
            if (users.Count > 0)
                return users[0];
            return null;
        }


        async Task<ParseObject> getDeviceUserWithId(string deviceId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            var deviceSearchField = string.Format("{{\"__type\":\"Pointer\",\"className\":\"Device\",\"objectId\":\"{0}\"}}", deviceId);
            parameters.Add("where", string.Format("{{\"device\":{0}}}", deviceSearchField));
            List<ParseObject> findResults = await RestAPI.get("_User", parameters);
            if (findResults.Count > 0)
                return findResults[0];
            return null;
        }


        async Task<ParseObject> getDeviceData(string deviceId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            var deviceSearchField = string.Format("{{\"__type\":\"Pointer\",\"className\":\"Device\",\"objectId\":\"{0}\"}}", deviceId);
            parameters.Add("where", string.Format("{{\"device\":{0}}}", deviceSearchField));
            parameters.Add("order", "-createdAt");
            List<ParseObject> findResults = await RestAPI.get("DeviceData", parameters);
            if (findResults.Count > 0)
                return findResults[0];

            textLog.AppendText("Create Device Data:" + deviceId + "\n");
            ParseObject pfObject = ParseObject.Create("DeviceData");
            pfObject["device"] = ParseObject.CreateWithoutData("Device", deviceId);

            ParseACL acl = new ParseACL();
            acl.PublicReadAccess = acl.PublicWriteAccess = true;
            pfObject.ACL = acl;

            await pfObject.SaveAsync();
            return pfObject;
        }


        async Task<List<ParseObject>> getManagerUsers(ParseObject deviceUser)
        {
            string findConditions = "[";
            if (deviceUser.ContainsKey("managers"))
            {
                object[] managerNumbers = (object[])deviceUser["managers"];
                if (managerNumbers != null && managerNumbers.Length > 0)
                {
                    foreach (string managerNumber in managerNumbers)
                    {
                        if (managerNumbers[0] != managerNumber)
                            findConditions += ", ";
                        findConditions += string.Format("{{\"phoneNumber\":\"{0}\"}}", managerNumber);
                    }
                    findConditions += "]";

                    Dictionary<string, object> parameters = new Dictionary<string, object>();
                    string condition = string.Format("{{\"type\":\"manager\", \"$or\":{0}}}", findConditions);
                    parameters.Add("where", condition);
                    parameters.Add("order", "-createdAt");
                    return await RestAPI.get("_User", parameters);
                }
            }
            return new List<ParseObject>();
        }


        async Task<List<ParseObject>> getInstallations(List<ParseObject> managers)
        {
            if (managers.Count > 0)
            {
                string findConditions = "[";
                foreach (ParseObject manager in managers)
                {
                    if (managers.IndexOf(manager) > 0)
                        findConditions += ", ";
                    var userSearchField = string.Format("{{\"__type\":\"Pointer\",\"className\":\"_User\",\"objectId\":\"{0}\"}}", manager.ObjectId);
                    findConditions += string.Format("{{\"user\":{0}}}", userSearchField);
                }
                findConditions += "]";

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                string condition = string.Format("{{\"$or\":{0}}}", findConditions);
                parameters.Add("where", condition);
                parameters.Add("order", "-createdAt");
                return await RestAPI.get("_Installation", parameters, false);
            }
            return new List<ParseObject>();
        }


        // cradle 교체 사용자 상태 업데이트
        private async void cradleUserEventUpdate()
        {
            try {
                string phoneNumber = m_phoeNumbers[m_processIndex];

                ParseObject deviceUser = await getDeviceUser(phoneNumber);
                if (deviceUser != null)
                {
                    ParseObject deviceData = await getDeviceData(deviceUser.Get<ParseObject>("device").ObjectId);
                    deviceData["cradleEvent"] = true;
                    if (deviceData.ObjectId != null && deviceData.ObjectId.Length > 0)
                    {
                        deviceData = ParseObject.CreateWithoutData("DeviceData", deviceData.ObjectId);
                        deviceData["cradleEvent"] = true;
                        await RestAPI.update(deviceData);
                    }
                    else
                    {
                        await deviceData.SaveAsync();
                    }
                    List<ParseObject> managerUsers = await getManagerUsers(deviceUser);
                    List<ParseObject> installations = await getInstallations(managerUsers);
                    foreach (ParseObject installObject in installations)
                    {
                        ParseObject newInstallObject = ParseObject.CreateWithoutData("_Installation", installObject.ObjectId);
                        newInstallObject["eventFlag"] = 1;
                        await RestAPI.update(newInstallObject);
                    }
                    textLog.AppendText(phoneNumber);
                    textLog.AppendText("\n");
                }
                else
                {
                    textLog.AppendText(phoneNumber + ":invalid");
                    textLog.AppendText("\n");
                }
            }
            catch(Exception e) {
                MessageBox.Show(e.Message);
            }
            finally
            {
                ++m_processIndex;
                if (m_processIndex < m_phoeNumbers.Count)
                {
                    AsyncUtils.DelayFor(cradleUserEventUpdate, TimeSpan.FromMilliseconds(100));
                }
                else
                {
                    textLog.AppendText("Complete\n");
                }
            }
        }
    }
}


