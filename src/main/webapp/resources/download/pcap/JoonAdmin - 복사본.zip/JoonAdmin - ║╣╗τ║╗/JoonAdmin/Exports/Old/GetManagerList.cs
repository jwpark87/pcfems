﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parse;

namespace JoonAdmin
{
    public partial class GetManagerList : Form
    {
        DateTime? _lastDate = null;
        System.IO.StreamWriter _fs = new System.IO.StreamWriter(@"D:\shared\managers.csv", true);

        public GetManagerList()
        {
            InitializeComponent();
        }

        private void GetManagerList_Load(object sender, EventArgs e)
        {
            getManagerList();
        }


        private async void getManagerList()
        {
            try
            {
                writeLog("start query ");
                var query = ParseUser.Query;
                query = query.WhereEqualTo("type", "manager");
                query = query.OrderBy("createdAt");
                query = query.Limit(100);
                if (_lastDate != null)
                    query = query.WhereGreaterThan("createdAt", _lastDate);
                IEnumerable<ParseObject> managers = await query.FindAsync();
                if (managers.Count() == 0)
                {
                    complete();
                    return;
                }
                writeLog("first date " + managers.ElementAt(0).CreatedAt);

                foreach (ParseObject manager in managers)
                {
                    _fs.Write(DateTime.Parse(manager.CreatedAt.ToString()).ToLocalTime().ToString());
                    _fs.Write(", ");
                    _fs.Write(manager.Get<string>("phoneNumber"));
                    _fs.Write(", ");
                    _fs.WriteLine();

                    writeLog(manager.Get<string>("phoneNumber"));
                }
                _lastDate = managers.Last().CreatedAt;
                writeLog("next date " + _lastDate);
                _fs.Flush();
                AsyncUtils.DelayFor(getManagerList, TimeSpan.FromMilliseconds(100));
            }
            catch (Exception exp)
            {
                writeLog(exp.Message);
                AsyncUtils.DelayFor(getManagerList, TimeSpan.FromMilliseconds(100));
            }
            finally
            {
            }
        }

        void complete()
        {
            writeLog("complete");
            _fs.Close();
        }

        void writeLog(string s)
        {
            textLog.AppendText(s);
            textLog.AppendText("\n");
        }
    }
}
