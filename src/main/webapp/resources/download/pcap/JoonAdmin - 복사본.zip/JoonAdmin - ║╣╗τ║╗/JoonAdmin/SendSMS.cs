﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Web;

namespace JoonAdmin
{
    public partial class SendSMS : Form
    {
        int _sendIndex = 0;
        int _messageIndex = 0;
        int kSendDelay = 100;
        System.IO.StreamWriter _fs = new System.IO.StreamWriter(@"D:\shared\sendindex.txt", true);

        public SendSMS()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            _sendIndex = 236;
            for (int i = 0; i < _sendIndex; ++i)
            {
                ListViewItem item = phoneNumberList.Items[i];
                item.SubItems[2].Text = "Send";
            }
            sendNotifyMessage();
        }

        void sendNotifyMessage()
        {
            try
            {
                ListViewItem item = phoneNumberList.Items[_sendIndex];

                string[] messages = {
                    "JooN 키즈폰을 이용해 주셔서 감사드립니다 더 좋은 서비스를 위해 노력하겠습니다.",
                    "JooN A/S처리는 준서비스센터(http://goingnow.co.kr)의 온라인 접수를 활용해 주시고",
                    "악세사리 구입 및 문의는 준마켓(http://joonphone.com)을 이용하여 주시기 바랍니다.",
                    };

                string phoneNumber = item.SubItems[1].Text;
                sendSms("0000", phoneNumber, messages[_messageIndex]);
                item.EnsureVisible();

                ++_messageIndex;
                if (_messageIndex >= 3)
                {
                    item.SubItems[2].Text = "Send";
                    _messageIndex = 0;
                    ++_sendIndex;
                    if (_sendIndex < phoneNumberList.Items.Count)
                    {
                        AsyncUtils.DelayFor(sendNotifyMessage, TimeSpan.FromMilliseconds(kSendDelay));
                    }
                    else
                    {
                        MessageBox.Show("Complete", "메시지 보내기", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        _fs.Write(_sendIndex.ToString());
                        _fs.Close();
                    }
                }
                else
                {
                    item.SubItems[2].Text = _messageIndex.ToString();
                    AsyncUtils.DelayFor(sendNotifyMessage, TimeSpan.FromMilliseconds(kSendDelay));
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error : " + e.Message, "메시지 보내기", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _fs.Write(_sendIndex.ToString());
                _fs.Close();
            }
        }

        private void sendSms(string from, string to, string message)
        {
            Console.WriteLine(to + ":" + message);
            WebRequest request = WebRequest.Create("http://58.180.81.11/newskt/NotiRegist.php");
            request.Method = "POST";
            string postData = "api_key=0mp267NOw3&api_secret=7F1lRzhSuk&from=0000&phone_num=" + to + "&resFlag=2&req_type=0&send_msg=" + message;
            //postData = HttpUtility.UrlEncode(postData);
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = byteArray.Length;
            Stream dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            // Get the response.
            WebResponse response = request.GetResponse();
            Console.WriteLine(((HttpWebResponse)response).StatusDescription);
            dataStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(dataStream);
            string responseFromServer = reader.ReadToEnd();
            Console.WriteLine(responseFromServer);
            reader.Close();
            dataStream.Close();
            response.Close();
        }

        private void SendSMS_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(@"D:\shared\managers.csv", Encoding.UTF8);
            int i=1;
            while (!sr.EndOfStream)
            {
                string s = sr.ReadLine();
                string[] temp = s.Split(',');        // Split() 메서드를 이용하여 ',' 구분하여 잘라냄
                string[] items = { i.ToString(), temp[1], "" };
                phoneNumberList.Items.Add(new ListViewItem(items));
                ++i;
            }
        }
    }
}
