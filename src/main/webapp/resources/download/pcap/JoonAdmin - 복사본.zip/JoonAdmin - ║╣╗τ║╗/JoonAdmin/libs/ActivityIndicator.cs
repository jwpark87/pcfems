﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoonLib
{
    class ActivityIndicator
    {
        static int _refCount;
        static ToastPopup _popup;

        static public void show(string message, Control parent = null)
        {
            if (_refCount == 0)
            {
                _popup = new ToastPopup();
                _popup.Show(Application.OpenForms[0]);
                _popup.Text = Application.OpenForms[0].Text;
                _popup.Location = new System.Drawing.Point(Application.OpenForms[0].Location.X + Application.OpenForms[0].Width / 2 - _popup.Width / 2,
                                                           Application.OpenForms[0].Location.Y + Application.OpenForms[0].Height / 2 - _popup.Height / 2);
            }
            _popup.setMessage(message);
            ++_refCount;
        }

        static public void hide()
        {
            if (_refCount == 0)
                return;
            --_refCount;
            if (_refCount <= 0)
            {
                _refCount = 0;
                _popup.Hide();
            }
        }
    }
}
